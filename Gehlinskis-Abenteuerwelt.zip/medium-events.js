window.mediumEventDatabase = [
    {
        "title": "Bartolomeu Dias umrundet die Südspitze Afrikas",
        "year": 1488,
        "desc": "Der portugiesische Seefahrer erreicht das Kap der Guten Hoffnung."
    },
    {
        "title": "Vasco da Gama erreicht Indien auf dem Seeweg",
        "year": 1498,
        "desc": "Die portugiesische Flotte findet einen Seeweg von Europa nach Indien."
    },
    {
        "title": "Magellans Expedition startet ihre Weltumsegelung",
        "year": 1519,
        "desc": "Die spanische Expedition soll einen westlichen Seeweg zu den Gewürzinseln finden."
    },
    {
        "title": "Die Spanier erobern Tenochtitlan",
        "year": 1521,
        "desc": "Die Hauptstadt des Aztekenreichs fällt an die Truppen Hernán Cortés'."
    },
    {
        "title": "Kopernikus veröffentlicht sein Weltbild",
        "year": 1543,
        "desc": "Ein Buch beschreibt, dass die Erde sich um die Sonne bewegt."
    },
    {
        "title": "Der gregorianische Kalender wird eingeführt",
        "year": 1582,
        "desc": "Papst Gregor XIII. führt eine Kalenderreform ein, die bis heute genutzt wird."
    },
    {
        "title": "Die Britische Ostindien-Kompanie wird gegründet",
        "year": 1600,
        "desc": "Eine Handelsgesellschaft erhält weitreichende Rechte für den Handel mit Asien."
    },
    {
        "title": "Der Dreißigjährige Krieg beginnt",
        "year": 1618,
        "desc": "Ein Konflikt im Heiligen Römischen Reich weitet sich zum europäischen Krieg aus."
    },
    {
        "title": "Der Westfälische Frieden beendet einen langen Krieg",
        "year": 1648,
        "desc": "Mehrere Verträge beenden den Dreißigjährigen Krieg."
    },
    {
        "title": "Die Osmanen belagern Wien",
        "year": 1683,
        "desc": "Ein Entsatzheer beendet die zweite osmanische Belagerung der Stadt."
    },
    {
        "title": "Preußen wird zum Königreich erhoben",
        "year": 1701,
        "desc": "Kurfürst Friedrich III. krönt sich in Königsberg zum König."
    },
    {
        "title": "Ein Erdbeben zerstört große Teile Lissabons",
        "year": 1755,
        "desc": "Beben, Feuer und Flutwellen verwüsten die portugiesische Hauptstadt."
    },
    {
        "title": "James Watt verbessert die Dampfmaschine",
        "year": 1769,
        "desc": "Seine technische Verbesserung macht Dampfmaschinen deutlich effizienter."
    },
    {
        "title": "Die Boston Tea Party",
        "year": 1773,
        "desc": "Kolonisten protestieren gegen britische Steuern, indem sie Tee ins Hafenbecken werfen."
    },
    {
        "title": "Die britische Armee kapituliert bei Yorktown",
        "year": 1781,
        "desc": "Der Sieg der amerikanischen Truppen führt zum Ende des Unabhängigkeitskriegs."
    },
    {
        "title": "Ein Sklavenaufstand beginnt in Haiti",
        "year": 1791,
        "desc": "Der Aufstand führt zur Haitianischen Revolution und schließlich zur Unabhängigkeit."
    },
    {
        "title": "Großbritannien verbietet den Sklavenhandel",
        "year": 1807,
        "desc": "Ein Gesetz untersagt den britischen Handel mit versklavten Menschen."
    },
    {
        "title": "Die erste öffentliche Eisenbahn für Fahrgäste eröffnet",
        "year": 1825,
        "desc": "Die Bahn zwischen Stockton und Darlington transportiert Passagiere und Güter."
    },
    {
        "title": "Die Fotografie wird öffentlich vorgestellt",
        "year": 1839,
        "desc": "Das Verfahren der Daguerreotypie macht dauerhafte Fotografien möglich."
    },
    {
        "title": "Der kalifornische Goldrausch beginnt",
        "year": 1848,
        "desc": "Die Entdeckung von Gold lockt zahlreiche Menschen nach Kalifornien."
    },
    {
        "title": "Darwin veröffentlicht seine Evolutionstheorie",
        "year": 1859,
        "desc": "Ein Buch erklärt die Entwicklung der Arten durch natürliche Selektion."
    },
    {
        "title": "Lincoln verkündet die Befreiung versklavter Menschen",
        "year": 1863,
        "desc": "Die Emanzipationserklärung gilt für die aufständischen Südstaaten der USA."
    },
    {
        "title": "Das Deutsche Kaiserreich wird gegründet",
        "year": 1871,
        "desc": "Die deutschen Staaten schließen sich unter preußischer Führung zusammen."
    },
    {
        "title": "Alexander Graham Bell erhält ein Telefonpatent",
        "year": 1876,
        "desc": "Die Erfindung ermöglicht die Übertragung von Sprache über elektrische Leitungen."
    },
    {
        "title": "Die Berliner Konferenz beginnt",
        "year": 1884,
        "desc": "Europäische Mächte beraten über ihre Ansprüche auf Gebiete in Afrika."
    },
    {
        "title": "Röntgen entdeckt eine neue Art von Strahlung",
        "year": 1895,
        "desc": "Die später nach ihm benannten Strahlen machen Bilder vom Inneren des Körpers möglich."
    },
    {
        "title": "Einstein stellt seine spezielle Relativitätstheorie vor",
        "year": 1905,
        "desc": "Die Theorie verändert das Verständnis von Raum, Zeit und Bewegung."
    },
    {
        "title": "Der Vertrag von Versailles wird unterzeichnet",
        "year": 1919,
        "desc": "Der Vertrag legt die Friedensbedingungen nach dem Ersten Weltkrieg fest."
    },
    {
        "title": "Tutanchamuns Grab wird entdeckt",
        "year": 1922,
        "desc": "Archäologen finden im Tal der Könige ein weitgehend unberührtes Pharaonengrab."
    },
    {
        "title": "Der erste abendfüllende Tonfilm kommt ins Kino",
        "year": 1927,
        "desc": "Der Jazzsänger wird zum frühen großen Erfolg des Tonfilms."
    },
    {
        "title": "Der Spanische Bürgerkrieg beginnt",
        "year": 1936,
        "desc": "Der Konflikt zwischen Republikanern und Nationalisten dauert bis zum Ende des Jahrzehnts."
    },
    {
        "title": "Die Landung der Alliierten in der Normandie",
        "year": 1944,
        "desc": "Eine große Invasion eröffnet eine Westfront gegen das nationalsozialistische Deutschland."
    },
    {
        "title": "Der Staat Israel wird gegründet",
        "year": 1948,
        "desc": "Die Unabhängigkeitserklärung führt zur Gründung des Staates Israel."
    },
    {
        "title": "Die Beatles treten erstmals im US-Fernsehen auf",
        "year": 1964,
        "desc": "Ihr Auftritt in einer beliebten Fernsehsendung löst Begeisterung bei jungen Fans aus."
    },
    {
        "title": "Rosa Parks weigert sich, ihren Sitzplatz abzugeben",
        "year": 1955,
        "desc": "Ihr Protest wird zu einem wichtigen Moment der US-amerikanischen Bürgerrechtsbewegung."
    },
    {
        "title": "Die kubanische Revolution siegt",
        "year": 1959,
        "desc": "Die Regierung von Fulgencio Batista wird gestürzt."
    },
    {
        "title": "Die Kubakrise bringt die Welt an den Rand eines Atomkriegs",
        "year": 1962,
        "desc": "Die USA und die Sowjetunion stehen wegen sowjetischer Raketen auf Kuba im Konflikt."
    },
    {
        "title": "Der Prager Frühling wird niedergeschlagen",
        "year": 1968,
        "desc": "Truppen des Warschauer Pakts beenden die Reformbewegung in der Tschechoslowakei."
    },
    {
        "title": "Der Watergate-Skandal beginnt",
        "year": 1972,
        "desc": "Ein Einbruch in das Hauptquartier der Demokratischen Partei führt zu einem politischen Skandal."
    },
    {
        "title": "Die Islamische Revolution im Iran",
        "year": 1979,
        "desc": "Die Monarchie wird gestürzt und eine neue Staatsordnung entsteht."
    },
    {
        "title": "Ein Reaktorunglück erschüttert Tschernobyl",
        "year": 1986,
        "desc": "Ein schwerer Unfall in einem Kernkraftwerk setzt große Mengen Radioaktivität frei."
    },
    {
        "title": "Deutschland wird wiedervereinigt",
        "year": 1990,
        "desc": "Die Deutsche Demokratische Republik tritt der Bundesrepublik Deutschland bei."
    },
    {
        "title": "Nelson Mandela wird Präsident Südafrikas",
        "year": 1994,
        "desc": "Nach dem Ende der Apartheid wird Mandela zum ersten schwarzen Präsidenten des Landes gewählt."
    },
    {
        "title": "Das Klonschaf Dolly wird vorgestellt",
        "year": 1997,
        "desc": "Dolly ist das erste Säugetier, das aus einer erwachsenen Körperzelle geklont wurde."
    },
    {
        "title": "Facebook wird gegründet",
        "year": 2004,
        "desc": "Das soziale Netzwerk startet zunächst für Studierende in den USA."
    },
    {
        "title": "Ein Tsunami löst die Nuklearkatastrophe von Fukushima aus",
        "year": 2011,
        "desc": "Nach einem Erdbeben und Tsunami kommt es in Japan zu einem schweren Reaktorunfall."
    },
    {
        "title": "Das Pariser Klimaabkommen wird beschlossen",
        "year": 2015,
        "desc": "Staaten vereinbaren gemeinsame Ziele zur Begrenzung der Erderwärmung."
    },
    {
        "title": "Das erste Bild eines Schwarzen Lochs wird veröffentlicht",
        "year": 2019,
        "desc": "Ein weltweites Netzwerk aus Teleskopen bildet ein Schwarzes Loch ab."
    },
    {
        "title": "Das James-Webb-Teleskop zeigt seine ersten Bilder",
        "year": 2022,
        "desc": "Ein Weltraumteleskop veröffentlicht neue Aufnahmen ferner Galaxien."
    },
    {
        "title": "Indien landet nahe dem Südpol des Mondes",
        "year": 2023,
        "desc": "Die Mondsonde Chandrayaan-3 erreicht erfolgreich die Mondoberfläche."
    },
    {
        "title": "Zerstörung von Ninive",
        "year": -61,
        "desc": "Antikes historisches Ereignis"
    },
    {
        "title": "Der tote Zhuge verscheucht den lebenden Zhongda",
        "year": 234,
        "desc": "Veranstaltung in den Drei Königreichen Chinas"
    },
    {
        "title": "Bekehrung des Heiligen Augustinus",
        "year": 386,
        "desc": "Historisches Ereignis aus dem Jahr 386."
    },
    {
        "title": "Der Vorfall bei Inmestar",
        "year": 415,
        "desc": "Historisches Ereignis aus dem Jahr 415."
    },
    {
        "title": "Tod Mohammeds",
        "year": 632,
        "desc": "Historisches Ereignis aus dem Jahr 632."
    },
    {
        "title": "ʻĀm al-ramādah",
        "year": 639,
        "desc": "Historisches Ereignis aus dem Jahr 639."
    },
    {
        "title": "Judenverfolgung im westgotischen Hispanien",
        "year": 700,
        "desc": "Historisches Ereignis aus dem Jahr 700."
    },
    {
        "title": "Niu-Li-Fraktionskämpfe (900; Niu-Li Factional Struggles)",
        "year": 900,
        "desc": "Auseinandersetzung in der  Tang-Dynastie"
    },
    {
        "title": "Shōtai-Vorfall",
        "year": 901,
        "desc": "Historisches Ereignis aus dem Jahr 901."
    },
    {
        "title": "Plünderung von St. Davids durch die Wikinger (933; sacking of St Davids by Vikings)",
        "year": 933,
        "desc": "historisches Ereignis in Wales im Jahr 933"
    },
    {
        "title": "Crow Terrace Poetry Trial",
        "year": 1079,
        "desc": "Hochverratsprozess gegen Su Shi und andere im Jahr 1079"
    },
    {
        "title": "Belagerung von Nakło",
        "year": 1090,
        "desc": "1090 Vorkommen"
    },
    {
        "title": "Gründung der Reading Abbey",
        "year": 1121,
        "desc": "Historisches Ereignis aus dem Jahr 1121."
    },
    {
        "title": "Fragmentierung der Kiewer Rus (1200; Fragmentation of Kievan Rus)",
        "year": 1200,
        "desc": "Politische Zersplitterung Mitte des 12. Jahrhunderts"
    },
    {
        "title": "Luzerner Mordnacht",
        "year": 1343,
        "desc": "event in 1343"
    },
    {
        "title": "Timurs Rückkehr in den persischen Irak",
        "year": 1393,
        "desc": "Historisches Ereignis aus dem Jahr 1393."
    },
    {
        "title": "Timurs Rückkehr nach Samarkand",
        "year": 1396,
        "desc": "Historisches Ereignis aus dem Jahr 1396."
    },
    {
        "title": "Timurs Reise durch Schirwan und Aserbaidschan",
        "year": 1396,
        "desc": "Historisches Ereignis aus dem Jahr 1396."
    },
    {
        "title": "Kolumbus kehrt 1493 nach La Navidad zurück",
        "year": 1493,
        "desc": "Kolumbus kehrt zurück und findet La Navidad zerstört vor"
    },
    {
        "title": "Einführung des Luntenschlosses in Japan",
        "year": 1543,
        "desc": "Historisches Ereignis aus dem Jahr 1543."
    },
    {
        "title": "Der Wandschreibvorfall am Yangjae-Bahnhof (1547; The Yangjae Station Wall Writing Incident)",
        "year": 1547,
        "desc": "1547 politische Säuberung in Korea (Joseon)"
    },
    {
        "title": "Magdeburger Bekenntnis (1550; Magdeburg Confession)",
        "year": 1550,
        "desc": "1550 Lutherisches Glaubensbekenntnis"
    },
    {
        "title": "vorübergehende schwedische Pflichten im Öresund 1565",
        "year": 1565,
        "desc": "Episode im Siebenjährigen Krieg"
    },
    {
        "title": "Auflösung der Reading Abbey",
        "year": 1583,
        "desc": "Historisches Ereignis aus dem Jahr 1583."
    },
    {
        "title": "Mehltag",
        "year": 1591,
        "desc": "Historisches Ereignis aus dem Jahr 1591."
    },
    {
        "title": "Geonjeo-Problem (1591; Geonjeo Issue)",
        "year": 1591,
        "desc": "politischer Vorfall (1591) in der Geschichte von Joseon"
    },
    {
        "title": "Åbo Blutbad (1599; Åbo Bloodbath)",
        "year": 1599,
        "desc": "1599 öffentliche Hinrichtung in Turku (Åbo), Finnland"
    },
    {
        "title": "Eine private Unterhaltung des Königs und der Königin am 1. Mai",
        "year": 1604,
        "desc": "1604 Maske von Ben Jonson"
    },
    {
        "title": "Gyechuk Oksa",
        "year": 1613,
        "desc": "Vorfall im Jahr 1613"
    },
    {
        "title": "Einnahme von Salvador (1624; Capture of Salvador)",
        "year": 1624,
        "desc": "1624 militärischer Konflikt"
    },
    {
        "title": "Rückeroberung Salvadors (1625; Recapture of Salvador)",
        "year": 1625,
        "desc": "1625 Schlacht im Achtzigjährigen Krieg"
    },
    {
        "title": "Übergabe von Quebec (1628; Surrender of Quebec)",
        "year": 1628,
        "desc": "die Einnahme von Quebec (ohne Schlacht) im Jahr 1629 durch englische Freibeuter unter der Führung von David Kirke während des Dreißigjährigen Krieges"
    },
    {
        "title": "Belagerung von Salvador (1638; Siege of Salvador)",
        "year": 1638,
        "desc": "1638 holländische Belagerung von Salvador, Bahia"
    },
    {
        "title": "Das große Gewitter (1638; The Great Thunderstorm)",
        "year": 1638,
        "desc": "1638 Wetterereignis in Dartmoor, England"
    },
    {
        "title": "Plünderungszeit (1644; Plundering Time)",
        "year": 1644,
        "desc": "Zeit der Gesetzlosigkeit im kolonialen Maryland (1644–1646)"
    },
    {
        "title": "Westliche Protestanz (1650; Western Remonstrance)",
        "year": 1650,
        "desc": "Schottisches historisches Ereignis"
    },
    {
        "title": "Krönung Karls II. von England (1661; Coronation of Charles II of England)",
        "year": 1661,
        "desc": "Ereignis am 23. April 1661, Westminster Abbey"
    },
    {
        "title": "Toller Auswurf (1662; Great Ejection)",
        "year": 1662,
        "desc": "folgte dem Act of Uniformity 1662 in England"
    },
    {
        "title": "Die Vernichtung der Türken",
        "year": 1702,
        "desc": "Historisches Ereignis aus dem Jahr 1702."
    },
    {
        "title": "Musin-Aufstand (1728; Musin Revolt)",
        "year": 1728,
        "desc": "1728 Aufstand in Korea"
    },
    {
        "title": "1754 Vorfall am Hōreki-Fluss",
        "year": 1754,
        "desc": "Historisches Ereignis aus dem Jahr 1754."
    },
    {
        "title": "Paul Reveres Midnight Ride",
        "year": 1755,
        "desc": "Alarmierung der amerikanischen Kolonialmiliz im Jahr 1775"
    },
    {
        "title": "Vertreibung der Jesuiten aus Portugal, 1759",
        "year": 1759,
        "desc": "Ereignis, das 1759 in Portugal stattfand"
    },
    {
        "title": "Mirakel des Hauses Brandenburg",
        "year": 1762,
        "desc": "Ereignis während des Siebenjährigen Krieges"
    },
    {
        "title": "Der Tod von Peter III. von Russland",
        "year": 1762,
        "desc": "Historisches Ereignis aus dem Jahr 1762."
    },
    {
        "title": "Friedensfest in Jena 1763",
        "year": 1763,
        "desc": "Friedensfest am 2. Mai 1763 aus Anlass des Hubertusburger Friedens"
    },
    {
        "title": "Vertreibung der Jesuiten aus Frankreich (1763)",
        "year": 1763,
        "desc": "Ereignis, das 1763 in Frankreich stattfand"
    },
    {
        "title": "Belagerung von Warwick Lane (1767; Siege of Warwick Lane)",
        "year": 1767,
        "desc": "1767 Protest in London"
    },
    {
        "title": "Vertreibung der Jesuiten aus Spanien im Jahr 1767",
        "year": 1767,
        "desc": "Ereignis, das 1767 in Spanien stattfand"
    },
    {
        "title": "Gründung der ersten jüdischen Gemeinde in Wales (1768; founding of the first Jewish community in Wales)",
        "year": 1768,
        "desc": "Gründung einer jüdischen Gemeinde in Swansea im Jahr 1768"
    },
    {
        "title": "Gefangennahme und Rettung von Jemima Boone (1776; Capture and rescue of Jemima Boone)",
        "year": 1776,
        "desc": "Vorfall in der Kolonialgeschichte von Kentucky"
    },
    {
        "title": "McCollochs Sprung (1777; McColloch's Leap)",
        "year": 1777,
        "desc": "Ein berittener US-Kavallerist springt von einer Klippe und überlebt"
    },
    {
        "title": "George Washingtons Abschied von seinen Offizieren (1783; George Washington's farewell to his officers)",
        "year": 1783,
        "desc": "historisches Ereignis am Ende des Amerikanischen Unabhängigkeitskrieges"
    },
    {
        "title": "Rücktritt von George Washington als Oberbefehlshaber (1783; George Washington's resignation as commander-in-chief)",
        "year": 1783,
        "desc": "George Washington tritt am 23. Dezember 1783 als Oberbefehlshaber der Kontinentalarmee zurück"
    },
    {
        "title": "Journée des bricoles",
        "year": 1789,
        "desc": "Historisches Ereignis aus dem Jahr 1789."
    },
    {
        "title": "Empfang von George Washington in Trenton (1789; George Washington's reception at Trenton)",
        "year": 1789,
        "desc": "Empfang des designierten Präsidenten George Washington am 21. April 1789 in Trenton, New Jersey"
    },
    {
        "title": "9. Thermidor",
        "year": 1794,
        "desc": "Sturz Robespierres"
    },
    {
        "title": "Fries's Rebellion",
        "year": 1799,
        "desc": "Bewaffneter Steueraufstand unter niederländischen Bauern in Pennsylvania zwischen 1799 und 1800"
    },
    {
        "title": "Royalistischer Aufstand im Toulousain (1799)",
        "year": 1799,
        "desc": "Historisches Ereignis aus dem Jahr 1799."
    },
    {
        "title": "Stadtbrand von Linz 1808",
        "year": 1800,
        "desc": "Brand in der oberösterreichischen Landeshauptstadt Linz"
    },
    {
        "title": "Brand im Stift Melk 1805",
        "year": 1805,
        "desc": "Brandkatastrophe im Jahr 1805"
    },
    {
        "title": "Landung des Prinzen (1813; Landing of the Prince)",
        "year": 1813,
        "desc": "Rückkehr von Prinz William in die Niederlande im Jahr 1813"
    },
    {
        "title": "Jackson-Benton-Schlägerei von 1813",
        "year": 1813,
        "desc": "Amerikanischer Waffen- und Messerkampf"
    },
    {
        "title": "Erste Schlacht von Talca (1814; First Battle of Talca)",
        "year": 1814,
        "desc": "Die Schlacht ereignete sich im chilenischen Unabhängigkeitskrieg"
    },
    {
        "title": "Breslauer Turnfehde",
        "year": 1819,
        "desc": "Historisches Ereignis aus dem Jahr 1819."
    },
    {
        "title": "Aufstand irischer und deutscher Söldner (1828; Irish and German Mercenary Soldiers' Revolt)",
        "year": 1828,
        "desc": "1828 Militäraufstand in Brasilien durch irische und deutsche Söldner"
    },
    {
        "title": "Konische Abschnitte Rebellion",
        "year": 1830,
        "desc": "Bildungsveranstaltung gegen Prüfungspolitik"
    },
    {
        "title": "Mort des époux Pattison",
        "year": 1832,
        "desc": "Historisches Ereignis aus dem Jahr 1832."
    },
    {
        "title": "Auflösung der Klöster in Portugal",
        "year": 1834,
        "desc": "Historisches Ereignis aus dem Jahr 1834."
    },
    {
        "title": "Einnahme von Porto Alegre",
        "year": 1835,
        "desc": "1835 Vorkommnis"
    },
    {
        "title": "Paks-Konferenz",
        "year": 1844,
        "desc": "Historisches Ereignis aus dem Jahr 1844."
    },
    {
        "title": "Cockstock-Vorfall",
        "year": 1844,
        "desc": "Historische Auseinandersetzung auf dem Territorium Oregons im 19. Jahrhundert."
    },
    {
        "title": "Rückzug der badischen Revolutionsarmee in die Schweiz",
        "year": 1849,
        "desc": "Historisches Ereignis aus dem Jahr 1849."
    },
    {
        "title": "Fußspuren des Teufels",
        "year": 1855,
        "desc": "Phänomen"
    },
    {
        "title": "Hungersnot der Firma Obleukhov (1856; Starvation of the Obleukhov company)",
        "year": 1856,
        "desc": "1856 Hungersnot während der russischen Kolonisierung von Amur"
    },
    {
        "title": "1860 Großer Meteor",
        "year": 1860,
        "desc": "Meteoritenprozession, die die Erde streift und in den gesamten Vereinigten Staaten beobachtet wird"
    },
    {
        "title": "Sosta di Talamone",
        "year": 1860,
        "desc": "Historisches Ereignis aus dem Jahr 1860."
    },
    {
        "title": "Abfahrt von Quarto",
        "year": 1860,
        "desc": "Historisches Ereignis aus dem Jahr 1860."
    },
    {
        "title": "Jinju-Rebellion",
        "year": 1862,
        "desc": "Joseon-Aufstand (1862)"
    },
    {
        "title": "Iksan-Bauernaufstand",
        "year": 1862,
        "desc": "Koreanischer Aufstand (1862)"
    },
    {
        "title": "Versteigerung der Sammlung Schönborn-Wiesentheit 1865 (Montmorillon)",
        "year": 1865,
        "desc": "deutsche Auktion"
    },
    {
        "title": "Einnahme von Anhambai",
        "year": 1865,
        "desc": "Historisches Ereignis aus dem Jahr 1865."
    },
    {
        "title": "Die ersten walisischen Siedler segeln auf der Mimosa nach Patagonien (1865; first Welsh settlers sail to Patagonia on the Mimosa)",
        "year": 1865,
        "desc": "Kolonisierungsereignis im Jahr 1865"
    },
    {
        "title": "Durbar von 1870",
        "year": 1870,
        "desc": "Regierungsveranstaltung in Britisch-Indien"
    },
    {
        "title": "Aufstand der Muckers (1874; Revolt of the Muckers)",
        "year": 1874,
        "desc": "Konflikt zwischen zwei Gruppen in Südbrasilien in den Jahren 1873 und 1874"
    },
    {
        "title": "Louis-Mailloux-Affäre (1875; Louis Mailloux Affair)",
        "year": 1875,
        "desc": "gewalttätige Ereignisse in New Brunswick, Kanada im Jahr 1875"
    },
    {
        "title": "1878 Kanak-Aufstand",
        "year": 1878,
        "desc": "Historisches Ereignis aus dem Jahr 1878."
    },
    {
        "title": "Dumojin-Haekwan-Vorfall (1878; Dumojin Haekwan Incident)",
        "year": 1878,
        "desc": "Zusammenstoß zwischen koreanischen und japanischen Kaufleuten in Busan"
    },
    {
        "title": "Jarao-Protest",
        "year": 1879,
        "desc": "Historisches Ereignis"
    },
    {
        "title": "Vertreibung der Jesuiten aus Frankreich (1880)",
        "year": 1880,
        "desc": "Ereignis, das 1880 in Frankreich stattfand"
    },
    {
        "title": "Die Weltreise von König Kalākaua (1881; King Kalākaua's world tour)",
        "year": 1881,
        "desc": "Tour durch König Kalākaua vom hawaiianischen Königreich"
    },
    {
        "title": "Earp Vendetta Ride",
        "year": 1882,
        "desc": "Suche des stellvertretenden US-Marschalls Wyatt Earp nach Outlaw Cowboys"
    },
    {
        "title": "Most-Grottkau-Debatte (1884; Most–Grottkau debate)",
        "year": 1884,
        "desc": "1884 politische Debatte"
    },
    {
        "title": "Badeunfall am Seebad Reinickendorf am 28. Juli 1888",
        "year": 1888,
        "desc": "Ereignis in Reinickendorf"
    },
    {
        "title": "Jahr der Schüsse",
        "year": 1888,
        "desc": "Historisches Ereignis aus dem Jahr 1888."
    },
    {
        "title": "Schlacht von Cimarron (1889; Battle of Cimarron)",
        "year": 1889,
        "desc": "1889 Schießerei in Gray County, Kansas, USA"
    },
    {
        "title": "Verschüttung in den Granatenbergen in Reinickendorf, 1890",
        "year": 1890,
        "desc": "Ereignis in Reinickendorf im Jahr 1890"
    },
    {
        "title": "Selbstmord am Charlottenburger Weg in Reinickendorf / Pankow, 1891",
        "year": 1891,
        "desc": "Ereignis"
    },
    {
        "title": "Sammlung 3 Exemplar von Chelodina McCordy von Dr. Ten Kate auf Roti Island",
        "year": 1891,
        "desc": "Historisches Ereignis aus dem Jahr 1891."
    },
    {
        "title": "Verunglückung eines Passanten auf der Baustelle in der Gesellschaftstraße, 1892",
        "year": 1892,
        "desc": "Ereignis in Reinickendorf"
    },
    {
        "title": "Vorfall mit dem Vampir Mercy Brown (1892; Mercy Brown vampire incident)",
        "year": 1892,
        "desc": "Ereignis in Rhode Island, USA (1892)"
    },
    {
        "title": "Chunsaengmun-Vorfall",
        "year": 1895,
        "desc": "Ereignis"
    },
    {
        "title": "Yaqui-Aufstand (1896; Yaqui Uprising)",
        "year": 1896,
        "desc": "bewaffneter Konflikt in Sonora und Arizona"
    },
    {
        "title": "Angriff gegen Porfirio Díaz von 1897",
        "year": 1897,
        "desc": "Versuch, den mexikanischen Präsidenten zu töten"
    },
    {
        "title": "Schrei von Santa Barbara (1898; Cry of Santa Barbara)",
        "year": 1898,
        "desc": "Ereignis während der philippinischen Revolution"
    },
    {
        "title": "Untergang der SS La Bourgogne (1898; Sinking of the SS La Bourgogne)",
        "year": 1898,
        "desc": "1898 Seekatastrophe"
    },
    {
        "title": "Vorfall im Padre Canyon",
        "year": 1899,
        "desc": "1899 Gefecht zwischen Navajo-Jägern und Gesetzeshütern aus Arizona"
    },
    {
        "title": "Vertreibung der Jesuiten aus Frankreich (1902)",
        "year": 1902,
        "desc": "Ereignis, das 1902 in Frankreich stattfand"
    },
    {
        "title": "Internationale Ausstellung (1906)",
        "year": 1906,
        "desc": "Weltausstellung 1906/07 in Christchurch, Neuseeland"
    },
    {
        "title": "Eisenbahnkatastrophe von Riudecanyes im Jahr 1907",
        "year": 1907,
        "desc": "Historisches Ereignis aus dem Jahr 1907."
    },
    {
        "title": "5. Nationaler Eucharistischer Kongress",
        "year": 1911,
        "desc": "1911 Katholische Veranstaltung in Cincinnati, Ohio"
    },
    {
        "title": "Die Jagdreise von Georg V. in Nepal im Jahr 1911",
        "year": 1911,
        "desc": "1911 Jagdreise in Nepal"
    },
    {
        "title": "höchste auf der Erde gemessene Temperatur (1913; highest temperature recorded on Earth)",
        "year": 1913,
        "desc": "die weltweit höchste jemals gemessene Temperatur"
    },
    {
        "title": "Rumäniens Eintritt in den Ersten Weltkrieg",
        "year": 1916,
        "desc": "Historisches Ereignis aus dem Jahr 1916."
    },
    {
        "title": "Erster feministischer Kongress von Yucatán (1916; First Feminist Congress of Yucatán)",
        "year": 1916,
        "desc": "Erster feministischer Kongress in Yucatán, Mexiko"
    },
    {
        "title": "Amerikas erster Artillerieschuss im Ersten Weltkrieg",
        "year": 1917,
        "desc": "Historisches Ereignis aus dem Jahr 1917."
    },
    {
        "title": "9. Januar 1917 Sitzung des Deutschen Kronrates",
        "year": 1917,
        "desc": "Historisches Ereignis aus dem Jahr 1917."
    },
    {
        "title": "Rückeroberung des tschechischen Grenzgebiets (1918)",
        "year": 1918,
        "desc": "Rückeroberung des tschechischen Grenzgebiets durch die tschechoslowakische Armee im November und Dezember 1918"
    },
    {
        "title": "Große Volksversammlung der Serben, Bunjevci und anderen Slawen im Banat, Bačka und Baranja...... (1918; Great People's Assembly of Serbs, Bunjevci and other Slavs in Banat, Bačka and Baranja......)",
        "year": 1918,
        "desc": "eine Versammlung, die am 25. November 1918 in Novi Sad stattfand"
    },
    {
        "title": "1919 Aufruf von Coatesville zu den Waffen",
        "year": 1919,
        "desc": "Historisches Ereignis aus dem Jahr 1919."
    },
    {
        "title": "Mustafa Kemals Landung in Samsun",
        "year": 1919,
        "desc": "Historisches Ereignis aus dem Jahr 1919."
    },
    {
        "title": "Bayer wird Teil von I G Farben",
        "year": 1925,
        "desc": "Ereignis in Deutschland im Jahr 1925"
    },
    {
        "title": "Tod und Beerdigung von Königin Alexandra (1925; Death and funeral of Queen Alexandra)",
        "year": 1925,
        "desc": "1925 Tod und Beerdigung der Königinmutter des Vereinigten Königreichs"
    },
    {
        "title": "Île Saint-Paul vergessene Menschen",
        "year": 1931,
        "desc": "Historisches Ereignis aus dem Jahr 1931."
    },
    {
        "title": "Ausrufung der Zweiten Spanischen Republik",
        "year": 1931,
        "desc": "Historisches Ereignis aus dem Jahr 1931."
    },
    {
        "title": "Revolution von Trujillo, 1932",
        "year": 1932,
        "desc": "1932 Aufstand in Peru"
    },
    {
        "title": "Eucharistischer Kongress von Dublin (1932; Eucharistic Congress of Dublin)",
        "year": 1932,
        "desc": "1932 christliche Veranstaltung in Dublin, Irland"
    },
    {
        "title": "crociera aerea del Decennale",
        "year": 1933,
        "desc": "Transatlantikflug im Jahr 1933"
    },
    {
        "title": "2. Dezember 1933 Das Berliner Gericht verbietet den Oppenheimern jegliche Rechtsgeschäfte für die Margraf-Gruppe",
        "year": 1933,
        "desc": "bedeutendes Ereignis (Teil des Holocaust)"
    },
    {
        "title": "erster Tag der Fernsehprogramme (1936; first day of television programmes)",
        "year": 1936,
        "desc": "erstes geplantes hochauflösendes Fernsehprogramm auf einem speziellen Kanal"
    },
    {
        "title": "Estnische Operation des NKWD (1937; Estonian Operation of the NKVD)",
        "year": 1937,
        "desc": "Massenverhaftungen und Hinrichtungen von Esten in der UdSSR"
    },
    {
        "title": "abgebrochene Krönung von Edward VIII (1937; abandoned coronation of Edward VIII)",
        "year": 1937,
        "desc": "abgesagte Krönung im Vereinigten Königreich"
    },
    {
        "title": "1937 Aufstand der Hinterbänkler der Sozialkredite",
        "year": 1937,
        "desc": "Parlamentsrevolte in Kanada"
    },
    {
        "title": "Tod und Staatsbegräbnis von Mustafa Kemal Atatürk (1938; death and state funeral of Mustafa Kemal Atatürk)",
        "year": 1938,
        "desc": "Präsidentenbegräbnis in der Türkei"
    },
    {
        "title": "Pringsheim Sale, 7. Juni 1939 bei Sotheby & Co. (London, England),",
        "year": 1939,
        "desc": "Auktion von Kunstwerken bei Sotheby's in London (italienische Majolika aus der Sammlung von Alfred Pringsheim aus München)"
    },
    {
        "title": "Evakuierung von Oslo im April 1940",
        "year": 1940,
        "desc": "Historisches Ereignis aus dem Jahr 1940."
    },
    {
        "title": "Zwangshospitalisierung in Honmyōji (1940; Forced Hospitalization at Honmyōji)",
        "year": 1940,
        "desc": "Zwangshospitalisierung von Leprapatienten in Japan"
    },
    {
        "title": "Am 20. November 1940 trat Rumänien offiziell dem Bündnis der Achsenmächte (Deutschland, Italien und Japan) bei.",
        "year": 1940,
        "desc": "Ereignis des Zweiten Weltkriegs"
    },
    {
        "title": "Im Mai 1940 ernennt Hitler Arthur Seyß-Inquart zum Reichskommissar für die besetzten Niederlande",
        "year": 1940,
        "desc": "Ereignis Zweiter Weltkrieg Mai 1940 Seyß-Inquart wird von Hitler zum Reichskommissar der besetzten Niederlande ernannt"
    },
    {
        "title": "Evakuierung des Eremitage-Museums (1941; evacuation of the Hermitage museum)",
        "year": 1941,
        "desc": "Notevakuierung von Kunst aus Leningrad während des Zweiten Weltkriegs"
    },
    {
        "title": "Untergang der SS C.F. Liljevalch",
        "year": 1942,
        "desc": "Untergang eines schwedischen Dampfschiffes"
    },
    {
        "title": "Razzia am Eleftherias-Platz 1942",
        "year": 1942,
        "desc": "antisemitische Maßnahme in Saloniki"
    },
    {
        "title": "Öffentliche Demütigung von Partisanen in Celje",
        "year": 1942,
        "desc": "Historisches Ereignis aus dem Jahr 1942."
    },
    {
        "title": "Ohrfeigen von George S. Patton (1943; George S. Patton slapping incidents)",
        "year": 1943,
        "desc": "Fälle von Ohrfeigen"
    },
    {
        "title": "Transitstreik in Philadelphia im Jahr 1944",
        "year": 1944,
        "desc": "Krankenstreik 1944"
    },
    {
        "title": "Repressalien in Herbaijum und Menaldum (1944; reprisals at Herbaijum and Menaldum)",
        "year": 1944,
        "desc": "Nazi-Repressalien im Rahmen der Besetzung der Niederlande im Zweiten Weltkrieg, bei denen sechs Menschen als Strafe für die Aktionen des Widerstands hingerichtet wurden"
    },
    {
        "title": "Militäreinsatz beim Vorfall vom 28. Februar",
        "year": 1947,
        "desc": "Historisches Ereignis aus dem Jahr 1947."
    },
    {
        "title": "Menschenrechtsverletzungen in Belutschistan (1948; Human rights violations in Balochistan)",
        "year": 1948,
        "desc": "organisierter Missbrauch grundlegender Menschenrechte in Belutschistan, Pakistan"
    },
    {
        "title": "Rundtischkonferenz, Den Haag 1948",
        "year": 1948,
        "desc": "Historisches Ereignis aus dem Jahr 1948."
    },
    {
        "title": "Die Affäre jüdischer Geisteskranker in Beit Lechem",
        "year": 1948,
        "desc": "Historisches Ereignis aus dem Jahr 1948."
    },
    {
        "title": "Rückzug der Regierung der Republik China nach Taiwan (1949; retreat of the government of Republic of China to Taiwan)",
        "year": 1949,
        "desc": "Rückzug der Republik China vom chinesischen Festland auf die Insel Taiwan"
    },
    {
        "title": "Nationalistischer Aufstand in San Juan",
        "year": 1950,
        "desc": "Aufstand gegen die Regierung der Vereinigten Staaten in Puerto Rico"
    },
    {
        "title": "U.N. protestieren gegen kommerzielle Nutzung des Namens",
        "year": 1950,
        "desc": "Nachrichtenartikel"
    },
    {
        "title": "Mord an Harry und Harriette Moore (1951; Murder of Harry and Harriette Moore)",
        "year": 1951,
        "desc": "1951 Bombenanschlag, bei dem zwei Bürgerrechtler getötet wurden"
    },
    {
        "title": "Tod und Staatsbegräbnis von Georg VI (1952; death and state funeral of George VI)",
        "year": 1952,
        "desc": "1952 Beerdigung des Königs des Vereinigten Königreichs"
    },
    {
        "title": "Begrafenis Professor Dr. Ph.A. Kohnstamm te Ermelo, 1952",
        "year": 1952,
        "desc": "Ereignis"
    },
    {
        "title": "Tod und Beerdigung von Queen Mary (1953; Death and funeral of Queen Mary)",
        "year": 1953,
        "desc": "1953 Tod und Beerdigung der Königinmutter des Vereinigten Königreichs"
    },
    {
        "title": "1954 Erschießung des Kapitols der Vereinigten Staaten",
        "year": 1954,
        "desc": "Angriff auf die US-Hauptstadt durch puertoricanische Nationalisten"
    },
    {
        "title": "Galapremiere Ciske de Rat in Rotterdam, 1955",
        "year": 1955,
        "desc": "Veranstaltung in Rotterdam"
    },
    {
        "title": "1955 Plünderung der pakistanischen Konsulate in Afghanistan",
        "year": 1955,
        "desc": "Teil des Grenzkonflikts zwischen Afghanistan und Pakistan"
    },
    {
        "title": "Bouwcentrum Rotterdam Maurerwettbewerb Gesellen, 1955",
        "year": 1955,
        "desc": "Veranstaltung im Bouwcentrum Rotterdam"
    },
    {
        "title": "Arabisierung des Kommandos der jordanischen Armee (1956; Arabization of the Jordanian Army command)",
        "year": 1956,
        "desc": "1956 Entlassung hochrangiger britischer Kommandeure der Jordanisch-Arabischen Legion"
    },
    {
        "title": "Hochzeit von Fenny ten Bosch und Jan de Soet",
        "year": 1956,
        "desc": "Veranstaltung in Voorburg"
    },
    {
        "title": "Arbeitsbesuch der Königin im Rotterdam Construction Center, 1956",
        "year": 1956,
        "desc": "Veranstaltung im Bouwcentrum Rotterdam"
    },
    {
        "title": "Demonstratives Treffen für Ungarn in der Rotterdamer Ahoy-Halle, 1956",
        "year": 1956,
        "desc": "Veranstaltung in Rotterdam"
    },
    {
        "title": "Strom Thurmond war Filibuster des Civil Rights Act von 1957",
        "year": 1957,
        "desc": "Längster Filibuster im US-Senat"
    },
    {
        "title": "Nachstellung der Erklärung des Staates Israel",
        "year": 1958,
        "desc": "Historisches Ereignis aus dem Jahr 1958."
    },
    {
        "title": "Demonstrationen von Every House Soon im Bouwcentrum Rotterdam, 1958",
        "year": 1958,
        "desc": "Veranstaltung im Bouwcentrum Rotterdam"
    },
    {
        "title": "1958 Erwerb der Malewitsch-Sammlung durch das Stedelijk Museum in Amsterdam",
        "year": 1958,
        "desc": "Ereignis"
    },
    {
        "title": "Maria Callas besucht das Bovema-Studio in Heemstede, 1959",
        "year": 1959,
        "desc": "Veranstaltung in Heemstede im Jahr 1959"
    },
    {
        "title": "Anti-Atombomben-Treffen der PvdA im Ahoyhal, 1961",
        "year": 1961,
        "desc": "Veranstaltung in Rotterdam"
    },
    {
        "title": "Mord im brasilianischen Senat",
        "year": 1963,
        "desc": "historisches Ereignis"
    },
    {
        "title": "Der 900. Jahrestag von Heemskerk",
        "year": 1963,
        "desc": "Veranstaltungen in Heemskerk"
    },
    {
        "title": "Enthüllungszeremonie von Fikkie von Joeki Simák (Rotterdam)",
        "year": 1963,
        "desc": "Veranstaltung in Rotterdam"
    },
    {
        "title": "Piet de Boer schafft den Grundstein",
        "year": 1964,
        "desc": "Event, Kreation oder Stiftung mit Kunstsammlung"
    },
    {
        "title": "Eröffnung der neuen Eisenbahnbrücke über die Maas bei Venlo, 1964",
        "year": 1964,
        "desc": "Veranstaltung in Venlo, Niederlande"
    },
    {
        "title": "Plaza de Toros El Progreso-Katastrophe",
        "year": 1965,
        "desc": "1965 Massenandrang in Mexiko"
    },
    {
        "title": "erste Amtseinführung von Ferdinand Marcos",
        "year": 1965,
        "desc": "Historisches Ereignis aus dem Jahr 1965."
    },
    {
        "title": "Dreizehnter Jahrestag der VVSL in Leiden, 1965",
        "year": 1965,
        "desc": "Veranstaltung in Leiden"
    },
    {
        "title": "Reverend Buskes überreicht dem Stadtrat von Rotterdam das erste Exemplar des Widerstandsbuchs, 1965",
        "year": 1965,
        "desc": "Veranstaltung in Rotterdam, Niederlande"
    },
    {
        "title": "Eröffnung von De Doelen (Rotterdam)",
        "year": 1966,
        "desc": "Veranstaltung im Doelen in Rotterdam, Niederlande"
    },
    {
        "title": "Der 20. Jahrestag der Schallplattenfirma N.V. Bovema, 1966",
        "year": 1966,
        "desc": "Veranstaltung in Amsterdam"
    },
    {
        "title": "Hochzeit von Prinzessin Beatrix der Niederlande und Claus van Amsberg (1966; Wedding of Princess Beatrix of the Netherlands and Claus van Amsberg)",
        "year": 1966,
        "desc": "1966 niederländische königliche Hochzeit"
    },
    {
        "title": "1966 beschließt der Deutsche Bundestag die Leihgabe von Raubkunst an Museen und Behörden",
        "year": 1966,
        "desc": "Veranstaltung 1966 Deutschland"
    },
    {
        "title": "1967 Mount McKinley-Katastrophe",
        "year": 1967,
        "desc": "Bergsteiger-Katastrophe"
    },
    {
        "title": "Das Jimi-Hendrix-Erlebnis im niederländischen Fernsehen",
        "year": 1967,
        "desc": "Veranstaltung in Bussum, Niederlande"
    },
    {
        "title": "Hochzeit von Harald, Kronprinz von Norwegen, und Sonja Haraldsen (1968; Wedding of Harald, Crown Prince of Norway, and Sonja Haraldsen)",
        "year": 1968,
        "desc": "1968 norwegische Königshochzeit"
    },
    {
        "title": "UFO-Vorfall am Labor Day 1969",
        "year": 1969,
        "desc": "1969 UFO-Vorfall in Berkshire County, Massachusetts, USA"
    },
    {
        "title": "1969 Schießerei in der äthiopischen Botschaft",
        "year": 1969,
        "desc": "Massenerschießung in Mexiko-Stadt"
    },
    {
        "title": "Eröffnungssitzung der 7. Knesset, 1969",
        "year": 1969,
        "desc": "Historisches Ereignis aus dem Jahr 1969."
    },
    {
        "title": "Verschwinden von David Leckey und Jonathan Aven",
        "year": 1969,
        "desc": "1969 Fall vermisster Kinder in Nordirland"
    },
    {
        "title": "Brand des Studio Vitus in Bussum, 1971",
        "year": 1971,
        "desc": "Veranstaltung in Bussum, Niederlande"
    },
    {
        "title": "Vorfälle mit Leyla Express und Johnny Express (1971; Leyla Express and Johnny Express incidents)",
        "year": 1971,
        "desc": "Von kubanischen Kanonenbooten beschlagnahmte Frachter."
    },
    {
        "title": "Entführung des Flugzeugs auf der Strecke Bukarest-Oradea",
        "year": 1971,
        "desc": "Historisches Ereignis aus dem Jahr 1971."
    },
    {
        "title": "Entführung von Idalgo Macchiarini",
        "year": 1972,
        "desc": "Entführung in Italien im Jahr 1972"
    },
    {
        "title": "Surrealistischer Rothschild-Ball von 1972",
        "year": 1972,
        "desc": "1972 gesellschaftliche Veranstaltung im Ferrières-Palast, Frankreich, durchgeführt von der Familie Rothschild"
    },
    {
        "title": "Beginn der Schildkrötenjagd auf der Insel Roti",
        "year": 1972,
        "desc": "Historisches Ereignis aus dem Jahr 1972."
    },
    {
        "title": "1972 Geiselnahme in der israelischen Botschaft in Bangkok",
        "year": 1972,
        "desc": "1972 palästinensischer militanter Angriff in Thailand"
    },
    {
        "title": "Eröffnung des reizenden DD-2-Entwicklungszentrums im Bouwcentrum in Rotterdam, 1972",
        "year": 1972,
        "desc": "Veranstaltung im Bouwcentrum Rotterdam"
    },
    {
        "title": "Morde an Paddy Wilson und Irene Andrews (1973; Paddy Wilson and Irene Andrews killings)",
        "year": 1973,
        "desc": "Tötungen von zwei Katholiken in Belfast während der Unruhen."
    },
    {
        "title": "Buchhaltertag im Congresgebouw Den Haag, 1973",
        "year": 1973,
        "desc": "Veranstaltung in Den Haag, Niederlande"
    },
    {
        "title": "Verschwinden von Joanne Ratcliffe und Kirste Gordon (1973; Disappearance of Joanne Ratcliffe and Kirste Gordon)",
        "year": 1973,
        "desc": "vermisste australische Mädchen seit 1973"
    },
    {
        "title": "Hissen der Flagge über Quneitra (1974; Raising the flag over Quneitra)",
        "year": 1974,
        "desc": "Ereignis vom 26. Juni 1974 in Syrien"
    },
    {
        "title": "Vertreibung von Montoneros von der Plaza de Mayo (1974; Expulsion of Montoneros from Plaza de Mayo)",
        "year": 1974,
        "desc": "Politische Situation in Argentinien"
    },
    {
        "title": "Tötung von Bernard Whitehurst",
        "year": 1975,
        "desc": "Mord an einem Amerikaner durch einen Polizisten"
    },
    {
        "title": "Verschwinden von Julie Garciacelay",
        "year": 1975,
        "desc": "Ungelöster australischer Fall des Verschwindenlassens"
    },
    {
        "title": "Besetzung von „Herdade Torre Bela“",
        "year": 1975,
        "desc": "Historisches Ereignis aus dem Jahr 1975."
    },
    {
        "title": "Neuklassifizierung von Schiffen der United States Navy 1975",
        "year": 1975,
        "desc": "Historisches Ereignis aus dem Jahr 1975."
    },
    {
        "title": "Unfall auf der Fußgängerbrücke in Gomel (1975)",
        "year": 1975,
        "desc": "Historisches Ereignis aus dem Jahr 1975."
    },
    {
        "title": "Zwangssterilisationen in Uttawar (1976; Uttawar forced sterilisations)",
        "year": 1976,
        "desc": "Zwangssterilisationsveranstaltung in Indien"
    },
    {
        "title": "Vorfall mit Süßkartoffeln in Hampyeong",
        "year": 1976,
        "desc": "Historisches Ereignis aus dem Jahr 1976."
    },
    {
        "title": "Kussengevecht op Schule, 30. April 1976",
        "year": 1976,
        "desc": "Veranstaltung in Heemskerk, Niederlande"
    },
    {
        "title": "1976 kam es zu einer Entführung durch Außerirdische in Stanford, Kentucky",
        "year": 1976,
        "desc": "Entführung von drei Frauen durch Außerirdische"
    },
    {
        "title": "Großer Bakersfield-Staubsturm von 1977",
        "year": 1977,
        "desc": "Vorkommnis"
    },
    {
        "title": "Unterbrechung der Ausstrahlung von Southern Television (1977; Southern Television broadcast interruption)",
        "year": 1977,
        "desc": "Falschmeldung vom IBA-Sender"
    },
    {
        "title": "Präsentation der LP Asian Dreams von Jack Jersey in Laren, 1977",
        "year": 1977,
        "desc": "Veranstaltung in Laren (NH)"
    },
    {
        "title": "Empfang für Maccabi Tel Aviv B.C. nach dem Gewinn der Basketball-Europameisterschaft",
        "year": 1977,
        "desc": "1977"
    },
    {
        "title": "Oranjegala in Stadsschouwburg, Haarlem 1978",
        "year": 1978,
        "desc": "Die Galavorstellung erfolgte durch Koningin Juliana"
    },
    {
        "title": "Festnahme von fünf Personen, die des Mordes an dem PJ-Agenten in Massarelos am 21. März 1978 verdächtigt werden",
        "year": 1978,
        "desc": "Festnahme am 1. April 1978 in São Pedro de Moel"
    },
    {
        "title": "Ruhollah Khomeinis Rückkehr in den Iran (1979; Ruhollah Khomeini's return to Iran)",
        "year": 1979,
        "desc": "1979 Rückkehr des iranischen Religionsführers"
    },
    {
        "title": "Neunummerierung der nationalen Strecken im Jahr 1979",
        "year": 1979,
        "desc": "Neunummerierung der Autobahn"
    },
    {
        "title": "Verschwinden von Louise und Charmian Faulkner (1980; Louise and Charmian Faulkner disappearance)",
        "year": 1980,
        "desc": "Mutter und Tochter, die verschwunden sind"
    },
    {
        "title": "Bydgoszcz politische Provokation (1981; Bydgoszcz political provocation)",
        "year": 1981,
        "desc": "politische Provokation"
    },
    {
        "title": "Unabhängigkeit von Antigua und Barbuda",
        "year": 1981,
        "desc": "Gründung des Landes Antigua und Barbuda"
    },
    {
        "title": "Angriff der Front Polisario auf das portugiesische Fischereifahrzeug „Porto Céu“ am 26. September 1981",
        "year": 1981,
        "desc": "Angriff, bei dem der Fischer Celestino Custódio getötet und drei weitere Fischer verletzt wurden"
    },
    {
        "title": "1983–1988 Terroranschläge in Kuwait",
        "year": 1983,
        "desc": "Terroranschläge in ganz Kuwait in den Jahren 1983–1988"
    },
    {
        "title": "niedrigste auf der Erde gemessene Temperatur (1983; lowest temperature recorded on Earth)",
        "year": 1983,
        "desc": "die kälteste Temperatur auf der Erde"
    },
    {
        "title": "1985 antitamilisches Pogrom in Karaitivu",
        "year": 1985,
        "desc": "Angriffe auf Zivilisten in Sri Lanka"
    },
    {
        "title": "1985 Hagelsturm im Osten von Minas Gerais",
        "year": 1985,
        "desc": "Naturkatastrophe in Minas Gerais, Brasilien"
    },
    {
        "title": "Bill Buckners Fehler bei der World Series 1986",
        "year": 1986,
        "desc": "war ein Baseballspiel, das im sechsten Spiel der World Series 1986 am 25. Oktober 1986 im Shea Stadium in Queens, New York, stattfand"
    },
    {
        "title": "Verschwinden von Mark Garvey",
        "year": 1987,
        "desc": "Ungelöster Vermisstenfall aus Großbritannien"
    },
    {
        "title": "Teilung des Moskauer Kunsttheaters (1987; Split of the Moscow Art Thetre)",
        "year": 1987,
        "desc": "Aufteilung der Theatergruppe in zwei unabhängige Unternehmen"
    },
    {
        "title": "Interne Hinrichtungen der Organisation Abu Nidal (1987; Abu Nidal Organization internal executions)",
        "year": 1987,
        "desc": "Hinrichtungen innerhalb der Abu Nidal-Organisation"
    },
    {
        "title": "Kirribilli-Abkommen von 1988",
        "year": 1988,
        "desc": "Politischer Deal in Australien"
    },
    {
        "title": "1988 Busentführung in Ordschonikidse",
        "year": 1988,
        "desc": "Flugzeugentführung in der Sowjetunion"
    },
    {
        "title": "Trombas del Río de la Plata von 1988",
        "year": 1988,
        "desc": "Historisches Ereignis aus dem Jahr 1988."
    },
    {
        "title": "1989 Angriff auf J. Jayalalithaa",
        "year": 1989,
        "desc": "politischer Vorfall"
    },
    {
        "title": "Entfernung des ungarischen Grenzzauns (1989; Removal of Hungary's border fence)",
        "year": 1989,
        "desc": "Entfernung des „Eisernen Vorhangs“ an der Grenze zwischen Österreich und Ungarn"
    },
    {
        "title": "Parade der Oktoberrevolution 1989 in Kischinew",
        "year": 1989,
        "desc": "Historisches Ereignis aus dem Jahr 1989."
    },
    {
        "title": "Die Übernahme des Präsidentenamtes im Jahr 1989",
        "year": 1989,
        "desc": "Stanford-Studenten übernehmen das Amt des Präsidenten"
    },
    {
        "title": "1989 Kontroverse um malaysische Gefängnisprivilegien",
        "year": 1989,
        "desc": "Kontroverse über die Sonderbehandlung eines Gefangenen"
    },
    {
        "title": "Fernando Collor 1990 Amtseinführung des Präsidenten",
        "year": 1990,
        "desc": "Historisches Ereignis aus dem Jahr 1990."
    },
    {
        "title": "Vorfall mit ziviler Überwachung durch das Militärische Sicherheitskommando",
        "year": 1990,
        "desc": "Vorkommen in Südkorea"
    },
    {
        "title": "1991 Geiselnahme in Sacramento",
        "year": 1991,
        "desc": "Geiselkrise 1991"
    },
    {
        "title": "Wirtschaftsliberalisierung in Indien (1991; Economic liberalisation in India)",
        "year": 1991,
        "desc": "Wirtschaftsreformen in Indien, die am 24. Juli 1991 begannen"
    },
    {
        "title": "Verschwinden von Cheryl Ann Kenney",
        "year": 1991,
        "desc": "1991 Missouri vermisste Person"
    },
    {
        "title": "1991 Cyanobakterienblüte am Darling River",
        "year": 1991,
        "desc": "Größte Algenblüte seit Beginn der Aufzeichnungen"
    },
    {
        "title": "Der Vorfall im Tunnel am Moskauer Gartenring am 21. August 1991",
        "year": 1991,
        "desc": "1991 sowjetischer Putschversuch"
    },
    {
        "title": "Sturz des Kommunismus in Albanien (1992; fall of communism in Albania)",
        "year": 1992,
        "desc": "Veranstaltung, beginnend im Dezember 1990 mit Studentenprotesten; politischer Pluralismus wurde am 11. Dezember zugelassen; Die Labour Party gewann die Wahlen 1991 (in einer Koalition mit Nichtkommunisten), verlor die Wahlen 1992 jedoch aufgrund des wirtschaftlichen Zusammenbruchs und sozialer Unruhen"
    },
    {
        "title": "Bosanski Šamac ethnische Säuberung (1992; Bosanski Šamac ethnic cleansing)",
        "year": 1992,
        "desc": "Verfolgungskampagne"
    },
    {
        "title": "Verschwinden von Rhianna Barreau",
        "year": 1992,
        "desc": "Seit 1992 vermisstes australisches Mädchen"
    },
    {
        "title": "Einstellung des Betriebs der Straßenbahnen des Typs N",
        "year": 1992,
        "desc": "Einstellung des Betriebs der Straßenbahnen Konstal N in Posen"
    },
    {
        "title": "Angriff auf die Buchmacher von James Murray",
        "year": 1992,
        "desc": "1992 Dreharbeiten in Belfast, Nordirland"
    },
    {
        "title": "1992 Liechtensteiner Verfassungskrise",
        "year": 1992,
        "desc": "1922 Verfassungs- und Diplomatiekrise in Liechtenstein"
    },
    {
        "title": "Incendio del Palacio de la Luz",
        "year": 1993,
        "desc": "Historisches Ereignis aus dem Jahr 1993."
    },
    {
        "title": "1993 Kollision mit der South Shore Line",
        "year": 1993,
        "desc": "Eisenbahnunfall in Gary, Indiana im Jahr 1993"
    },
    {
        "title": "Das FBI im Weißen Haus reicht eine Kontroverse ein (1993; White House FBI files controversy)",
        "year": 1993,
        "desc": "politischer Skandal der Clinton-Regierung"
    },
    {
        "title": "Kontroverse um das Reisebüro im Weißen Haus (1993; White House travel office controversy)",
        "year": 1993,
        "desc": "Ethik-Kontroverse der Clinton-Regierung"
    },
    {
        "title": "Verschwinden von Brian Hesketh",
        "year": 1994,
        "desc": "Ungelöster Vermisstenfall im Vereinigten Königreich"
    },
    {
        "title": "Tod und Beerdigung von Kim Il-sung (1994; Death and funeral of Kim Il-sung)",
        "year": 1994,
        "desc": "Beerdigung im Juli 1994"
    },
    {
        "title": "Trouwfeest, 20. Oktober 1995",
        "year": 1995,
        "desc": "Veranstaltung in Rotterdam"
    },
    {
        "title": "Angriff auf die Abgeordneten im Obersten Rat von Belarus (1995; assault against the deputies in the Supreme Council of Belarus)",
        "year": 1995,
        "desc": "Batterie gegen die Oppositionsabgeordneten in den Räumlichkeiten des belarussischen Parlaments"
    },
    {
        "title": "Verschwinden von René Hasée",
        "year": 1996,
        "desc": "ungelöst 1996 vermisster 6-Jähriger aus Portugal"
    },
    {
        "title": "Verschwinden von Adam, Trevor und Mitchell O'Brien",
        "year": 1996,
        "desc": "1996 Fall eines vermissten Kindes in Kanada"
    },
    {
        "title": "Schenkung des Entartete-Kunst-Inventars an die V&A National Art Libary durch Elfriede Fischer",
        "year": 1996,
        "desc": "Veranstaltung: Elfried Fischer (Witwe von Harry Fischer) schenkte dem V&A ein BLJ-Inventar der „Entarteten Kunst“ der Nazis"
    },
    {
        "title": "Verschwinden von Ethna Kelleher",
        "year": 1997,
        "desc": "ungelöstes Verschwinden im Vereinigten Königreich im Jahr 1997"
    },
    {
        "title": "Tod und Staatsbegräbnis von Kamuzu Banda (1997; Death and state funeral of Kamuzu Banda)",
        "year": 1997,
        "desc": "Staatsbegräbnis im November 1997 in Malawi"
    },
    {
        "title": "1997 Nationalkongress der Sozialistischen Linkspartei",
        "year": 1997,
        "desc": "Norwegisches politisches Ereignis"
    },
    {
        "title": "Amtseinführung von Andrés Pastrana (1998; Inauguration of Andrés Pastrana)",
        "year": 1998,
        "desc": "1998 Amtseinführung des kolumbianischen Präsidenten"
    },
    {
        "title": "Liquiditätshilfe der Bank Indonesia",
        "year": 1998,
        "desc": "Historisches Ereignis aus dem Jahr 1998."
    },
    {
        "title": "Morde an Prostituierten in Essex County",
        "year": 1998,
        "desc": "Serienmordfall in Essex County, New Jersey"
    },
    {
        "title": "Anklage und Verhaftung von Augusto Pinochet (1998; Indictment and arrest of Augusto Pinochet)",
        "year": 1998,
        "desc": "Verhaftung des Diktators wegen Verbrechen gegen die Menschlichkeit (1990er–2000er Jahre)"
    },
    {
        "title": "Morde an Lauria Bible und Ashley Freeman (1999; Murders of Lauria Bible and Ashley Freeman)",
        "year": 1999,
        "desc": "Mord an zwei amerikanischen Teenagern"
    },
    {
        "title": "Vertreibung während des Krieges 1999 in Dagestan",
        "year": 1999,
        "desc": "Historisches Ereignis aus dem Jahr 1999."
    },
    {
        "title": "Deutschland erhöht sein Angebot in Fällen von Nazi-Sklaven um 555 Millionen US-Dollar",
        "year": 1999,
        "desc": "Nachrichtenartikel"
    },
    {
        "title": "Geiselnahme in der Kinderkrippe Wasserbillig",
        "year": 2000,
        "desc": "2000 Geiselnahme in Luxemburg"
    },
    {
        "title": "Anti-Globalisierungsproteste in Prag",
        "year": 2000,
        "desc": "Historisches Ereignis aus dem Jahr 2000."
    },
    {
        "title": "Gerling Global Reinsurance gegen Quackenbuch",
        "year": 2000,
        "desc": "Klage der Versicherungsgesellschaft"
    },
    {
        "title": "Sotheby's stimmt der Zahlung einer Strafe in Höhe von 45 Millionen US-Dollar zu",
        "year": 2000,
        "desc": "Nachrichtenartikel, Veranstaltung, Pressemitteilung des DOJ"
    },
    {
        "title": "Mercator-Konferenz über audiovisuelle Übersetzung und Minderheitensprachen",
        "year": 2000,
        "desc": "Vorkommen in Aberystwyth, Wales"
    },
    {
        "title": "Restitution des Gemäldes „Frau sitzt im Gras am Rande einer Wiese und liest“ von Nicolaas van der Waay, Inv. NEIN. BRL 2210",
        "year": 2000,
        "desc": "Veranstaltung im Jahr 2000"
    },
    {
        "title": "Verschwinden von Patti Adkins",
        "year": 2001,
        "desc": "2001 Ohio vermisste Person"
    },
    {
        "title": "Politische Morde auf den Philippinen",
        "year": 2001,
        "desc": "Historisches Ereignis aus dem Jahr 2001."
    },
    {
        "title": "George W. Bush, Rede vom 20. September 2001",
        "year": 2001,
        "desc": "Historisches Ereignis aus dem Jahr 2001."
    },
    {
        "title": "11. September Grundschulbesuch von George W. Bush",
        "year": 2001,
        "desc": "2001-Ereignis in der Geschichte der USA"
    },
    {
        "title": "Historisches TV-Interview 2001: 20-minütiges Interview mit Timothy Speed auf ORF Kunststücke, nachdem Dennis Hopper seinen Flug verpasst hatte",
        "year": 2001,
        "desc": "Historisches Fernsehinterview"
    },
    {
        "title": "Verschwinden von Por Soua Her",
        "year": 2002,
        "desc": "2002 Minnesota vermisste Person"
    },
    {
        "title": "Wirtschaftskrise Uruguays 1999-2002",
        "year": 2002,
        "desc": "Historisches Ereignis aus dem Jahr 2002."
    },
    {
        "title": "Verschwinden von Christopher Thompkins",
        "year": 2002,
        "desc": "ungelöster Vermisstenfall aus dem Jahr 2002 aus Harris County, Georgia"
    },
    {
        "title": "Verschwinden von Erika Ansermin",
        "year": 2003,
        "desc": "ungelöster Vermisstenfall aus Italien aus dem Jahr 2003"
    },
    {
        "title": "Morde in Falludscha im April 2003",
        "year": 2003,
        "desc": "von Soldaten der US-Armee im Irak"
    },
    {
        "title": "Schließung von Euskaldunon Egunkaria",
        "year": 2003,
        "desc": "Veranstaltung 2003"
    },
    {
        "title": "Vorwürfe des sunnitischen Völkermords im Irak",
        "year": 2003,
        "desc": "Verbrechen gegen sunnitische Araber im Irak"
    },
    {
        "title": "Tod und Staatsbegräbnis von Heydar Aliyev (2003; Death and state funeral of Heydar Aliyev)",
        "year": 2003,
        "desc": "Tod des ehemaligen aserbaidschanischen Präsidenten"
    },
    {
        "title": "Rede von Colin Powell vor dem Sicherheitsrat der Vereinten Nationen",
        "year": 2003,
        "desc": "Rede"
    },
    {
        "title": "Entlassung von Richter Roberto Marquevich",
        "year": 2004,
        "desc": "Ereignis"
    },
    {
        "title": "Verschwinden von Louise Tume",
        "year": 2005,
        "desc": "Historisches Ereignis aus dem Jahr 2005."
    },
    {
        "title": "Der Mann mit der Schokoladenrobe",
        "year": 2005,
        "desc": "Historisches Ereignis aus dem Jahr 2005."
    },
    {
        "title": "Beirut-Damaskus-Erklärung",
        "year": 2006,
        "desc": "Historisches Ereignis aus dem Jahr 2006."
    },
    {
        "title": "Massenansturm im PhilSports-Stadion",
        "year": 2006,
        "desc": "tödlicher Ansturm, der vor einer Aufzeichnung von Wowowee im PhilSports Stadium stattfand"
    },
    {
        "title": "Kinderfest im Schloss",
        "year": 2006,
        "desc": "Veranstaltung 2006"
    },
    {
        "title": "Beschuss der Kirche St. Philip Neri",
        "year": 2006,
        "desc": "2006 Artilleriebombardierung in Allaipiddy, Sri Lanka"
    },
    {
        "title": "Zwischenfall mit der sudanesischen Ziegenheirat (2006; Sudanese goat marriage incident)",
        "year": 2006,
        "desc": "Viraler Nachrichtenbeitrag aus dem Jahr 2006"
    },
    {
        "title": "Autopsiebilder von Ngatikaura Ngati",
        "year": 2006,
        "desc": "2007 Bildverteilung in Neuseeland"
    },
    {
        "title": "zweite Amtseinführung von Álvaro Uribe",
        "year": 2006,
        "desc": "Amtseinführung des kolumbianischen Präsidenten"
    },
    {
        "title": "Internationale Reaktionen auf den Libanonkrieg 2006",
        "year": 2006,
        "desc": "Historisches Ereignis aus dem Jahr 2006."
    },
    {
        "title": "Weltmeisterschaft 2006: Zinedine Zidane gewann den Goldenen Ball",
        "year": 2006,
        "desc": "Wikinews-Artikel"
    },
    {
        "title": "April 2007: Bombenanschlag auf Charsadda",
        "year": 2007,
        "desc": "Selbstmordanschlag 2007 in Pakistan"
    },
    {
        "title": "Vorfall mit Waffendiebstahl in Ganghwado",
        "year": 2007,
        "desc": "Historisches Ereignis aus dem Jahr 2007."
    },
    {
        "title": "2007 Fußballgewalt in Catania",
        "year": 2007,
        "desc": "Italienischer Aufstand"
    },
    {
        "title": "55 let trolejbusů v Pardubicích",
        "year": 2007,
        "desc": "Historisches Ereignis aus dem Jahr 2007."
    },
    {
        "title": "Vorfall mit Sanitätern in Oslo 2007",
        "year": 2007,
        "desc": "Vorfall in Norwegen"
    },
    {
        "title": "Taser-Vorfall mit Robert Dziekański (2007; Robert Dziekański Taser incident)",
        "year": 2007,
        "desc": "Polnischer Mann am Flughafen Vancouver von der Polizei getötet"
    },
    {
        "title": "Verschwinden von Cédrika Provencher",
        "year": 2007,
        "desc": "Kanadisches Mädchen"
    },
    {
        "title": "2008 Busbombenanschläge in Sri Lanka",
        "year": 2008,
        "desc": "Teil des srilankischen Bürgerkriegs"
    },
    {
        "title": "New's Divine Nachtclub-Tragödie",
        "year": 2008,
        "desc": "Massenansturm in Mexiko-Stadt"
    },
    {
        "title": "Tourist am Berg Kumgang erschossen",
        "year": 2008,
        "desc": "Historisches Ereignis aus dem Jahr 2008."
    },
    {
        "title": "Indiana Jones Sommer der verborgenen Geheimnisse",
        "year": 2008,
        "desc": "Disneyland-Event"
    },
    {
        "title": "Nic Diederichs Technical High School wird aufgeschlitzt",
        "year": 2008,
        "desc": "2008 Massenmord an der Nic Diederichs Nic Diederichs Technical High School in Krugersdorp"
    },
    {
        "title": "2008 Angriffe auf Migranten aus Uttar Pradeshi und Bihari in Maharashtra",
        "year": 2008,
        "desc": "Rassismus gegen Nordindianer, insbesondere Biharis"
    },
    {
        "title": "Verschwinden von Nancy Moyer",
        "year": 2009,
        "desc": "Amerikanerin wird seit 2009 vermisst"
    },
    {
        "title": "Kobalt-60-Vorfall im Kreis Qi",
        "year": 2009,
        "desc": "Historisches Ereignis aus dem Jahr 2009."
    },
    {
        "title": "2009 Kindesmissbrauchsfall in Plymouth",
        "year": 2009,
        "desc": "Englischer Pädophilenring"
    },
    {
        "title": "September 2009 Unruhen in Xinjiang",
        "year": 2009,
        "desc": "Anschläge und darauffolgende Unruhen"
    },
    {
        "title": "Exkommunikation von Margaret McBride",
        "year": 2009,
        "desc": "Abtreibungskontroverse im Jahr 2009"
    },
    {
        "title": "Nach dem Angriff des Islamabad Frontier Corps 2009",
        "year": 2009,
        "desc": "Historisches Ereignis aus dem Jahr 2009."
    },
    {
        "title": "Deutscher Verlag veröffentlicht Studie zur eigenen Nazi-Vergangenheit",
        "year": 2009,
        "desc": "Historisches Ereignis aus dem Jahr 2009."
    },
    {
        "title": "2009 Inhaftierung amerikanischer Journalisten durch Nordkorea",
        "year": 2009,
        "desc": "Diplomatische Pattsituation zwischen den USA und Nordkorea"
    },
    {
        "title": "Nacht van Duivenvoorde, 2010",
        "year": 2010,
        "desc": "Veranstaltung im Kasteel Duivenvoorde"
    },
    {
        "title": "September 2010 Quetta-Bombenanschlag",
        "year": 2010,
        "desc": "2010 Bombenanschlag in Quetta, Pakistan"
    },
    {
        "title": "2010 Anschlag auf Kosovska Mitrovica",
        "year": 2010,
        "desc": "Historisches Ereignis aus dem Jahr 2010."
    },
    {
        "title": "2010 Polizeifahndung in Northumbria",
        "year": 2010,
        "desc": "Großeinsatz der Polizei im Juli 2010"
    },
    {
        "title": "Nacht der Museen 2010 in Třebíč",
        "year": 2010,
        "desc": "Historisches Ereignis aus dem Jahr 2010."
    },
    {
        "title": "Weinende Statue in Windsor, Ontario",
        "year": 2010,
        "desc": "angebliche Wunder von 2010 in Kanada"
    },
    {
        "title": "2010 Transatlantik-Flugzeugbombenanschlag",
        "year": 2010,
        "desc": "Fehlgeschlagener Terroranschlag"
    },
    {
        "title": "2010 Taiwanesische Sondergemeindereform",
        "year": 2010,
        "desc": "Historisches Ereignis aus dem Jahr 2010."
    },
    {
        "title": "Einstellung des Betriebs der Hochbodenbusse der MPK Poznań",
        "year": 2010,
        "desc": "ein Ereignis, das im Januar 2010 stattfand"
    },
    {
        "title": "Aussetzung der Grundwehrpflicht in Polen",
        "year": 2010,
        "desc": "Aussetzung des obligatorischen Grundwehrdienstes in Polen mit Wirkung vom 1. Januar 2010"
    },
    {
        "title": "2011 Zusammenstöße im Bundesstaat Ebonyi",
        "year": 2011,
        "desc": "Bundesstaat Ebonyi, Nigeria"
    },
    {
        "title": "Dezember 2011: Zusammenstöße in Nigeria",
        "year": 2011,
        "desc": "Vorfall 2011 in Nigeria"
    },
    {
        "title": "Sexueller Übergriff auf Savannah Dietrich",
        "year": 2011,
        "desc": "Verbrechen im Jahr 2011 in Kentucky, USA"
    },
    {
        "title": "Diebstahl im Montreal Museum of Fine Arts 2011",
        "year": 2011,
        "desc": "Kriminalität in Kanada"
    },
    {
        "title": "Barack Obama bei der Carrier Classic 2011",
        "year": 2011,
        "desc": "Historisches Ereignis aus dem Jahr 2011."
    },
    {
        "title": "Herabstufung der Kreditwürdigkeit der US-Bundesregierung (2011; United States federal government credit-rating downgrade)",
        "year": 2011,
        "desc": "Verschlechterungen der geschätzten Kreditwürdigkeit"
    },
    {
        "title": "Ankündigung der endgültigen Einstellung der bewaffneten Aktivitäten der ETA",
        "year": 2011,
        "desc": "historisches Ereignis der Terrororganisation ETA"
    },
    {
        "title": "2012 Chen Wei-ting-Vorfall",
        "year": 2012,
        "desc": "Vorfall in Taiwan"
    },
    {
        "title": "2012 Angriff auf den pakistanischen Flughafen",
        "year": 2012,
        "desc": "Angriff der Teherik-i-Taliban auf einen pakistanischen internationalen Flughafen und Luftwaffenstützpunkt"
    },
    {
        "title": "Tod von Wichian Klanprasert (2012; Death of Wichian Klanprasert)",
        "year": 2012,
        "desc": "Kriminalität 2012 in Thailand"
    },
    {
        "title": "Windsor Concours of Elegance",
        "year": 2012,
        "desc": "Historisches Ereignis aus dem Jahr 2012."
    },
    {
        "title": "Vorfall im Kohlebergwerk Yal Shomal",
        "year": 2012,
        "desc": "Vorfall im Iran"
    },
    {
        "title": "Han Han-Ghostwriting-Vorwurf",
        "year": 2012,
        "desc": "Historisches Ereignis aus dem Jahr 2012."
    },
    {
        "title": "Vorfall in der Bäckerei Crumb and Get It",
        "year": 2012,
        "desc": "Historisches Ereignis aus dem Jahr 2012."
    },
    {
        "title": "Federal Polytechnic, Mubi-Angriff",
        "year": 2012,
        "desc": "Schulmassaker durch Boko Haram"
    },
    {
        "title": "Staatsbegräbnis von Bingu Wa Mutharika",
        "year": 2012,
        "desc": "Feiertag anlässlich der Staatsbegräbnisfeier des ehemaligen Präsidenten Bingu Wa Mutharika"
    },
    {
        "title": "2012 Proteste gegen islamfeindliche Filme in Sydney",
        "year": 2012,
        "desc": "Protest gegen islamfeindlichen Film"
    },
    {
        "title": "Kontroverse um den Karnataka-Videoclip 2012",
        "year": 2012,
        "desc": "Politischer Skandal in Indien"
    },
    {
        "title": "Tod und Staatsbegräbnis von Meles Zenawi",
        "year": 2012,
        "desc": "2012 Tod und Beerdigung des äthiopischen Premierministers"
    },
    {
        "title": "Swami Vivekananda Jugendbeschäftigungswoche",
        "year": 2012,
        "desc": "Veranstaltung 2012 in Gujarat, Indien"
    },
    {
        "title": "2012 NIS-Skandal zur Manipulation der öffentlichen Meinung",
        "year": 2012,
        "desc": "Koreanischer politischer Skandal"
    },
    {
        "title": "Kontroverse um Fotoverbot von Dolce & Gabbana in Hongkong",
        "year": 2012,
        "desc": "Historisches Ereignis aus dem Jahr 2012."
    },
    {
        "title": "Clint Eastwood auf dem Republikanischen Nationalkonvent 2012",
        "year": 2012,
        "desc": "Rede von Clint Eastwood"
    },
    {
        "title": "Geiselnahme am Qargha-Stausee / Qara-See, Juni 2012",
        "year": 2012,
        "desc": "Geiselnahme in der Nähe von Kabul"
    },
    {
        "title": "Bill Clintons Rede auf dem Democratic National Convention 2012",
        "year": 2012,
        "desc": "Historisches Ereignis aus dem Jahr 2012."
    },
    {
        "title": "Februar 2013 Quetta-Bombenanschlag",
        "year": 2013,
        "desc": "2013 Bombenanschlag auf einen Markt in Quetta, Belutschistan, Pakistan"
    },
    {
        "title": "Xi Jinping isst Baozi-Event",
        "year": 2013,
        "desc": "Historisches Ereignis aus dem Jahr 2013."
    },
    {
        "title": "August 2013: Geiseldrama in Islamabad",
        "year": 2013,
        "desc": "Historisches Ereignis aus dem Jahr 2013."
    },
    {
        "title": "2013 Mord in South Valley, New Mexico",
        "year": 2013,
        "desc": "Massenmord in New Mexico, USA"
    },
    {
        "title": "Demontage des Lenin-Denkmals in Kiew",
        "year": 2013,
        "desc": "Veranstaltung 2013"
    },
    {
        "title": "Eröffnung der Straßenbahnlinie nach Dworzec Zachodni",
        "year": 2013,
        "desc": "offizielle Eröffnung der Verlängerung der Posener Schnellstraßenbahn nach Dworzec Zachodni in Posen (2013)"
    },
    {
        "title": "Bayerische Stadt entzieht Hitler die Staatsbürgerschaft",
        "year": 2013,
        "desc": "Ereignis – Nach anfänglichem Stillstand stimmten die Stadträte in Dietramseil dafür, Hitler die 1933 verliehene Ehrenbürgerwürde zu entziehen"
    },
    {
        "title": "All-Star-Gruß 2013 an das Oregon-Militär",
        "year": 2013,
        "desc": "Historisches Ereignis aus dem Jahr 2013."
    },
    {
        "title": "Debatten zur iranischen Präsidentschaftswahl 2013",
        "year": 2013,
        "desc": "Historisches Ereignis aus dem Jahr 2013."
    },
    {
        "title": "2013 Angriff auf das indische Konsulat in Dschalalabad",
        "year": 2013,
        "desc": "Selbstmordanschlag in Afghanistan"
    },
    {
        "title": "Palazzo Valentini, Sala Di Liegro, 2013, Rom",
        "year": 2013,
        "desc": "Conferimento O.M.R.I. di Paolo Salvati"
    },
    {
        "title": "Design Academy Eindhoven, Abschlussausstellung 2013",
        "year": 2013,
        "desc": "Design-Event in Eindhoven"
    },
    {
        "title": "Übergang zwischen König Albert II. und König Philippe von Belgien",
        "year": 2013,
        "desc": "Historisches Ereignis aus dem Jahr 2013."
    },
    {
        "title": "Oslavy 400 Einwohner der Stadt Kralice nad Oslavou",
        "year": 2013,
        "desc": "Historisches Ereignis aus dem Jahr 2013."
    },
    {
        "title": "Richter ordnet Diözese L.A. an, Dokumente über sexuellen Missbrauch freizugeben (Januar 2013)",
        "year": 2013,
        "desc": "Teil des Kindesmissbrauchsskandals der katholischen Kirche in Los Angeles"
    },
    {
        "title": "Verschwinden von Relisha Rudd",
        "year": 2014,
        "desc": "2014 Fall amerikanischer vermisster Personen in DC"
    },
    {
        "title": "2014 Anschlag auf das Serena Hotel in Kabul",
        "year": 2014,
        "desc": "Massenerschießung 2014 in Kabul, Afghanistan"
    },
    {
        "title": "2014 chemischer Angriff von Kafr Zita",
        "year": 2014,
        "desc": "Chemieangriff im syrischen Bürgerkrieg"
    },
    {
        "title": "2014 ISL Inaugural Draft",
        "year": 2014,
        "desc": "Historisches Ereignis aus dem Jahr 2014."
    },
    {
        "title": "2014: Beilangriff in New York City",
        "year": 2014,
        "desc": "Angriff auf New Yorker Polizisten"
    },
    {
        "title": "Todesfälle von John und Joyce Sheridan",
        "year": 2014,
        "desc": "2014 starb ein amerikanisches Paar in New Jersey"
    },
    {
        "title": "Olympiapark Soči - Letná 2014",
        "year": 2014,
        "desc": "Historisches Ereignis aus dem Jahr 2014."
    },
    {
        "title": "Oživené židovské město Třebíč 2014",
        "year": 2014,
        "desc": "Historisches Ereignis aus dem Jahr 2014."
    },
    {
        "title": "Projekt MÜNCHEN2014 - Mia san Giga!",
        "year": 2014,
        "desc": "Historisches Ereignis aus dem Jahr 2014."
    },
    {
        "title": "2014 ISL Inaugural International Draft",
        "year": 2014,
        "desc": "Entwurf des indischen Fußballverbandes"
    },
    {
        "title": "2014 Angriff auf das indische Konsulat in Herat",
        "year": 2014,
        "desc": "Angriff auf indisches Konsulat durch in Pakistan stationierte Militante"
    },
    {
        "title": "Anti-Prostitutionskampagne 2014 in Dongguan",
        "year": 2014,
        "desc": "Historisches Ereignis aus dem Jahr 2014."
    },
    {
        "title": "2014 Tainan-Vandalismus an der Sun Yat-Sen-Statue",
        "year": 2014,
        "desc": "Historisches Ereignis aus dem Jahr 2014."
    },
    {
        "title": "Übertriebene Ratschläge: Meedoen is de Kunst, 2014",
        "year": 2014,
        "desc": "Veranstaltung in Rotterdam, Niederlande"
    },
    {
        "title": "Krankheit, Tod und Beerdigung von Gabriel García Márquez",
        "year": 2014,
        "desc": "Er wurde in einem JuanSGuarnizo-Video erwähnt"
    },
    {
        "title": "Gurlitt vermachte Sammlung dem Kunstmuseum Bern",
        "year": 2014,
        "desc": "Nachrichtenartikel"
    },
    {
        "title": "Erschießung von Kathryn Steinle",
        "year": 2015,
        "desc": "Konto des Opfers der Schießerei"
    },
    {
        "title": "Salida von Carmen Aristegui von MVS",
        "year": 2015,
        "desc": "Historisches Ereignis aus dem Jahr 2015."
    },
    {
        "title": "Fremdenfeindliche Angriffe in Südafrika 2015",
        "year": 2015,
        "desc": "Angriff auf Ausländer in Durban und Johannesburg"
    },
    {
        "title": "Donald Trumps Rede zum Wahlkampfauftakt",
        "year": 2015,
        "desc": "Historisches Ereignis aus dem Jahr 2015."
    },
    {
        "title": "Fantoni und Nunes Betrugsvorwurf",
        "year": 2015,
        "desc": "Betrugsskandal um die Vertragsbrücke 2015"
    },
    {
        "title": "Graffiti am Stadhuisplein R'dam, 2015",
        "year": 2015,
        "desc": "Graffiti-Kunstveranstaltung in Rotterdam, Niederlande"
    },
    {
        "title": "St.-Nikolaus-Zugausstellung 2015 in Třebíč",
        "year": 2015,
        "desc": "Historisches Ereignis aus dem Jahr 2015."
    },
    {
        "title": "2015 Rosch HaSchana, Tod durch Steinwurf",
        "year": 2015,
        "desc": "Historisches Ereignis aus dem Jahr 2015."
    },
    {
        "title": "Reaktionen auf die Pariser Anschläge im November 2015",
        "year": 2015,
        "desc": "Historisches Ereignis aus dem Jahr 2015."
    },
    {
        "title": "Mobbingvorfall 2015 in Rowland Heights, Kalifornien",
        "year": 2015,
        "desc": "zwei Vorfälle von Übergriffen in Kalifornien mit chinesischen Staatsangehörigen"
    },
    {
        "title": "Ernst & Young einigt sich mit N.Y. auf 10 Millionen US-Dollar wegen Lehman-Prüfung",
        "year": 2015,
        "desc": "Nachrichtenartikel"
    },
    {
        "title": "2016 Movida Bar-Granatangriff",
        "year": 2016,
        "desc": "Angriff in Puchong, Selangor, Malaysia"
    },
    {
        "title": "Dezember 2016 Bombenanschläge in Bagdad",
        "year": 2016,
        "desc": "Ziviler Angriff in Bagdad"
    },
    {
        "title": "Vorfall in der Pizzeria in Žatec",
        "year": 2016,
        "desc": "Historisches Ereignis aus dem Jahr 2016."
    },
    {
        "title": "23. Sitzung der Volksversammlung Kasachstans",
        "year": 2016,
        "desc": "Sitzung des politischen Gremiums 2016"
    },
    {
        "title": "September 2016: Angriff auf den Hilfskonvoi von Urum al-Kubra",
        "year": 2016,
        "desc": "Angriff auf einen medizinischen Hilfskonvoi durch syrische Regierungstruppen"
    },
    {
        "title": "Benzinknappheit im Südosten der USA 2016",
        "year": 2016,
        "desc": "Historisches Ereignis aus dem Jahr 2016."
    },
    {
        "title": "EU-Klage wegen illegaler staatlicher Beihilfe gegen Apple in Irland",
        "year": 2016,
        "desc": "13 Milliarden Euro Strafe gegen Apple für 2004-2014"
    },
    {
        "title": "Undeb yr Annibynwyr Cymraeg. Cyfarfodydd Blynyddol",
        "year": 2016,
        "desc": "Vorkommen in Llanuwchllyn, Wales"
    },
    {
        "title": "2016 Angriff auf die saudischen diplomatischen Vertretungen im Iran",
        "year": 2016,
        "desc": "Historisches Ereignis aus dem Jahr 2016."
    },
    {
        "title": "Unterzeichnung des HEAR-Gesetzes (Holocaust Expropriated Art Recovery) in US-amerikanisches Recht",
        "year": 2016,
        "desc": "Ereignis im US-Recht 16. Dezember 2016"
    },
    {
        "title": "Fall der 32. Studentenvereinigung der Gangneung-Wonju National University wegen Arbitrage und Unterschlagung",
        "year": 2016,
        "desc": "Rechtsfall (2016) in Südkorea"
    },
    {
        "title": "United Express Flug 3411",
        "year": 2017,
        "desc": "Vorfall, bei dem ein Passagier gewaltsam aus einem Flugzeug entfernt wurde."
    },
    {
        "title": "Varnika Kundu-Stalking-Fall",
        "year": 2017,
        "desc": "Vorfall am 4. August 2017 in Chandigarh, Indien"
    },
    {
        "title": "Angriff auf das FSB-Büro in Chabarowsk",
        "year": 2017,
        "desc": "Historisches Ereignis aus dem Jahr 2017."
    },
    {
        "title": "Vorfall im Buckingham Palace 2017",
        "year": 2017,
        "desc": "Historisches Ereignis aus dem Jahr 2017."
    },
    {
        "title": "2017 Entlassung von US-Anwälten",
        "year": 2017,
        "desc": "Kontroverse um die Trump-Administration"
    },
    {
        "title": "Pauline Hansons Burka-Vorfälle",
        "year": 2017,
        "desc": "Vorfälle 2017 und 2025 in Australien"
    },
    {
        "title": "August 2017: Überschwemmungen in Nepal und Indien",
        "year": 2017,
        "desc": "Historisches Ereignis aus dem Jahr 2017."
    },
    {
        "title": "Hypatia-Transrassismus-Kontroverse",
        "year": 2017,
        "desc": "Streit, der im April 2017 um einen Artikel in Hypatia begann"
    },
    {
        "title": "Oživené židovské město Třebíč 2017",
        "year": 2017,
        "desc": "Historisches Ereignis aus dem Jahr 2017."
    },
    {
        "title": "Angriff auf ein Polizeifahrzeug in Peshawar 2017",
        "year": 2017,
        "desc": "Historisches Ereignis aus dem Jahr 2017."
    },
    {
        "title": "Die unerzählten Geschichten vietnamesischer Frauen",
        "year": 2017,
        "desc": "Veranstaltung 2017"
    },
    {
        "title": "Berufung des Vereinigten Königreichs auf Artikel 50 (2017; United Kingdom invocation of Article 50)",
        "year": 2017,
        "desc": "Beschwörung des EU-Austrittsprozesses für „Brexit“"
    },
    {
        "title": "Angriff auf die venezolanische Nationalversammlung 2017",
        "year": 2017,
        "desc": "Angriff auf die Nationalversammlung"
    },
    {
        "title": "Loetje Groep, Grachtenparade Amsterdam 2017",
        "year": 2017,
        "desc": "Veranstaltung in Amsterdam"
    },
    {
        "title": "Kollision zwischen USS Fitzgerald und MV ACX Crystal",
        "year": 2017,
        "desc": "Vorfall 2017"
    },
    {
        "title": "2017 wurden 107 Artikel in der Zeitschrift Tumor Biology zurückgezogen",
        "year": 2017,
        "desc": "Historisches Ereignis aus dem Jahr 2017."
    },
    {
        "title": "2017 Systemfehler der Bank of the Philippine Islands",
        "year": 2017,
        "desc": "Banking Glitch der Bank of Philippine Islands vom Juni 2017"
    },
    {
        "title": "2017 Inhaftierung von Hongkonger Demokratieaktivisten",
        "year": 2017,
        "desc": "Historisches Ereignis aus dem Jahr 2017."
    },
    {
        "title": "Amtseinführung von Iván Duque",
        "year": 2018,
        "desc": "Amtseinführung des kolumbianischen Präsidenten"
    },
    {
        "title": "2800. Jahrestag von Eriwan",
        "year": 2018,
        "desc": "Historisches Ereignis aus dem Jahr 2018."
    },
    {
        "title": "Explosion eines Straßentankers in Mbuba (2018; Mbuba road tanker explosion)",
        "year": 2018,
        "desc": "Explosion eines Tankwagens in Kongo Central, Demokratische Republik Kongo"
    },
    {
        "title": "Eingangsrede von Mats Malm",
        "year": 2018,
        "desc": "Schwedische Königliche Akademie 2018"
    },
    {
        "title": "13. Juli 2018 Bombenanschläge in Pakistan",
        "year": 2018,
        "desc": "Terroranschläge"
    },
    {
        "title": "Kontroverse um das Restaurant Red Hen",
        "year": 2018,
        "desc": "Amerikanischer politischer Vorfall mit Beteiligung eines Mitarbeiters des Weißen Hauses"
    },
    {
        "title": "2018 schwedische Regierungsbildung",
        "year": 2018,
        "desc": "Parlamentarische Regierungsbildung in Schweden"
    },
    {
        "title": "Messerangriff in Manchester Victoria",
        "year": 2018,
        "desc": "Terroranschlag 2018 in Manchester, England"
    },
    {
        "title": "Messerstecherei in einer Mittelschule des Landkreises Mizhi (2018; Mizhi County middle school stabbing)",
        "year": 2018,
        "desc": "Massenmesserattacke 2018 in der Provinz Shaanxi, China"
    },
    {
        "title": "2018 Angriff auf die iranische Botschaft in Frankreich",
        "year": 2018,
        "desc": "Historisches Ereignis aus dem Jahr 2018."
    },
    {
        "title": "Bürger- und Solidaritätsmarsch 2018 (Frankreich)",
        "year": 2018,
        "desc": "Marsch zur Unterstützung von Flüchtlingen"
    },
    {
        "title": "Menschenkette für baskische Selbstbestimmung, 2018",
        "year": 2018,
        "desc": "politische Demonstration"
    },
    {
        "title": "Einführung in Wikipedia an der Universität Teheran",
        "year": 2018,
        "desc": "Veranstaltung in Teheran, Iran"
    },
    {
        "title": "Die otevřených dveří v Brněnských komunikacích 2018",
        "year": 2018,
        "desc": "Historisches Ereignis aus dem Jahr 2018."
    },
    {
        "title": "2018 Tötung eines lettischen Freiwilligen, der die Ukraine unterstützte",
        "year": 2018,
        "desc": "Die Tötungen in Lettland im Jahr 2018 werden Quellen zufolge mit feindlichen Aktivitäten Russlands in Europa in Verbindung gebracht"
    },
    {
        "title": "Congresso Internacional de Jornalismo Investigativo (2018)",
        "year": 2018,
        "desc": "Historisches Ereignis aus dem Jahr 2018."
    }
];
