# Gehlinskis-Abenteuerwelt

Ein lokal spielbares Quiz: Ordne historische Ereignisse chronologisch ein oder Länder nach ihrer Fläche.

- Wähle vor dem Start Geschichte oder Geographie sowie eine von drei Schwierigkeitsstufen.
- Jede Geschichtsstufe enthält 500 Fragen; die drei Pools mit zusammen 1.500 unterschiedlichen Ereignissen liegen in [easy-events.js](./easy-events.js), [medium-events.js](./medium-events.js) und [events.js](./events.js) (unmögliche Stufe).
- Geographie bietet 500 unterschiedliche Sortierrunden pro Schwierigkeitsstufe. Die Länderdaten liegen in [geography-events.js](./geography-events.js); die Runden verwenden unterschiedliche Kombinationen der Länder jeder Stufe.
- Pro Runde werden zehn Einträge mit unterschiedlichen Sortierwerten zufällig ausgewählt.
- Im Geographie-Quiz ordnest du Länder von der kleinsten bis zur größten Fläche ein. Die Flächenangabe steht nur auf der Referenzkarte.
- Kartentitel und Kurzbeschreibungen sind überwiegend auf Deutsch; Eigennamen können in der Originalschreibweise stehen. Bei historischen Karten werden die Jahreszahlen nicht angezeigt.
- Negative Jahreszahlen stehen für Jahre vor Christus.
- Die historischen Ereignisdaten stammen aus Wikidata (CC0) und eigenen Einträgen; einige Texte wurden maschinell ins Deutsche übertragen. Länderflächen sind gerundete Gesamtflächen in Quadratkilometern.

Zum Spielen `index.html` im Browser öffnen. Bei Browsern, die lokale Skriptdateien blockieren, das Projekt über einen lokalen Webserver starten.
