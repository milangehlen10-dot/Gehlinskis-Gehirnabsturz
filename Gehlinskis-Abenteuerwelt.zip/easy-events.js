window.easyEventDatabase = [
    {
        "title": "Erste Olympische Spiele",
        "year": -776,
        "desc": "Wettkämpfe im antiken Griechenland, aus denen die Olympischen Spiele hervorgingen."
    },
    {
        "title": "Gründung Roms",
        "year": -753,
        "desc": "Der Sage nach gründen Romulus und Remus die Stadt Rom."
    },
    {
        "title": "Schlacht bei Marathon",
        "year": -490,
        "desc": "Die Athener besiegen das persische Heer."
    },
    {
        "title": "Ermordung Julius Cäsars",
        "year": -44,
        "desc": "Römische Senatoren ermorden den bekannten Feldherrn."
    },
    {
        "title": "Beginn des Römischen Kaiserreichs",
        "year": -27,
        "desc": "Augustus wird der erste römische Kaiser."
    },
    {
        "title": "Untergang des Weströmischen Reichs",
        "year": 476,
        "desc": "Der letzte weströmische Kaiser wird abgesetzt."
    },
    {
        "title": "Beginn der islamischen Zeitrechnung",
        "year": 622,
        "desc": "Der Prophet Mohammed zieht von Mekka nach Medina."
    },
    {
        "title": "Karl der Große wird zum Kaiser gekrönt",
        "year": 800,
        "desc": "Der Frankenkönig wird in Rom zum Kaiser gekrönt."
    },
    {
        "title": "Eroberung Englands durch die Normannen",
        "year": 1066,
        "desc": "Wilhelm der Eroberer gewinnt die Schlacht bei Hastings."
    },
    {
        "title": "Die Magna Carta wird unterzeichnet",
        "year": 1215,
        "desc": "Der englische König muss seine Macht erstmals schriftlich begrenzen."
    },
    {
        "title": "Die Pest erreicht Europa",
        "year": 1347,
        "desc": "Der Schwarze Tod breitet sich in Europa aus."
    },
    {
        "title": "Gutenbergs Buchdruck verbreitet sich",
        "year": 1450,
        "desc": "Der Buchdruck mit beweglichen Lettern macht Bücher leichter verfügbar."
    },
    {
        "title": "Eroberung Konstantinopels",
        "year": 1453,
        "desc": "Die Osmanen erobern die Hauptstadt des Byzantinischen Reichs."
    },
    {
        "title": "Kolumbus erreicht Amerika",
        "year": 1492,
        "desc": "Die Expedition aus Europa erreicht die Karibik."
    },
    {
        "title": "Beginn der Reformation",
        "year": 1517,
        "desc": "Martin Luther veröffentlicht seine 95 Thesen."
    },
    {
        "title": "Die spanische Armada wird besiegt",
        "year": 1588,
        "desc": "Englands Flotte schlägt den spanischen Angriff zurück."
    },
    {
        "title": "Galileo beobachtet den Himmel mit dem Fernrohr",
        "year": 1609,
        "desc": "Der italienische Forscher nutzt ein Fernrohr für astronomische Beobachtungen."
    },
    {
        "title": "Newton veröffentlicht sein wichtigstes Werk",
        "year": 1687,
        "desc": "Isaac Newton erklärt darin unter anderem die Bewegung der Planeten."
    },
    {
        "title": "Unabhängigkeitserklärung der USA",
        "year": 1776,
        "desc": "Die britischen Kolonien erklären ihre Unabhängigkeit."
    },
    {
        "title": "Beginn der Französischen Revolution",
        "year": 1789,
        "desc": "Der Sturm auf die Bastille wird zum Symbol des Umbruchs."
    },
    {
        "title": "Hinrichtung König Ludwigs XVI.",
        "year": 1793,
        "desc": "Der französische König wird während der Revolution hingerichtet."
    },
    {
        "title": "Napoleon wird Kaiser der Franzosen",
        "year": 1804,
        "desc": "Napoleon krönt sich in Paris zum Kaiser."
    },
    {
        "title": "Schlacht bei Waterloo",
        "year": 1815,
        "desc": "Napoleons Herrschaft endet mit seiner Niederlage."
    },
    {
        "title": "Revolutionen in Europa",
        "year": 1848,
        "desc": "In vielen europäischen Ländern fordern Menschen Freiheit und politische Rechte."
    },
    {
        "title": "Beginn des Amerikanischen Bürgerkriegs",
        "year": 1861,
        "desc": "Nord- und Südstaaten der USA beginnen ihren Krieg."
    },
    {
        "title": "Ende des Amerikanischen Bürgerkriegs",
        "year": 1865,
        "desc": "Die Nordstaaten gewinnen den Krieg; die Sklaverei wird abgeschafft."
    },
    {
        "title": "Der Suezkanal wird eröffnet",
        "year": 1869,
        "desc": "Der Kanal verbindet das Mittelmeer mit dem Roten Meer."
    },
    {
        "title": "Albert Einstein wird geboren",
        "year": 1879,
        "desc": "Der spätere Physiker wird in Ulm geboren."
    },
    {
        "title": "Der Eiffelturm wird eröffnet",
        "year": 1889,
        "desc": "Das berühmte Bauwerk wird für eine Weltausstellung in Paris errichtet."
    },
    {
        "title": "Erster Motorflug der Gebrüder Wright",
        "year": 1903,
        "desc": "Ein Flugzeug hebt erstmals mit eigenem Motor kontrolliert ab."
    },
    {
        "title": "Untergang der Titanic",
        "year": 1912,
        "desc": "Das als unsinkbar geltende Passagierschiff kollidiert mit einem Eisberg."
    },
    {
        "title": "Beginn des Ersten Weltkriegs",
        "year": 1914,
        "desc": "Nach dem Attentat von Sarajevo beginnt ein Krieg, der viele Länder erfasst."
    },
    {
        "title": "Russische Revolution",
        "year": 1917,
        "desc": "Die Monarchie in Russland wird gestürzt."
    },
    {
        "title": "Ende des Ersten Weltkriegs",
        "year": 1918,
        "desc": "Ein Waffenstillstand beendet die Kämpfe."
    },
    {
        "title": "Penicillin wird entdeckt",
        "year": 1928,
        "desc": "Alexander Fleming entdeckt ein Mittel, das Bakterien bekämpft."
    },
    {
        "title": "Weltwirtschaftskrise beginnt",
        "year": 1929,
        "desc": "Ein Börsensturz löst eine schwere Wirtschaftskrise aus."
    },
    {
        "title": "Hitler wird Reichskanzler",
        "year": 1933,
        "desc": "Adolf Hitler wird an die Spitze der deutschen Regierung berufen."
    },
    {
        "title": "Beginn des Zweiten Weltkriegs",
        "year": 1939,
        "desc": "Der deutsche Überfall auf Polen löst den Krieg in Europa aus."
    },
    {
        "title": "Ende des Zweiten Weltkriegs in Europa",
        "year": 1945,
        "desc": "Deutschland kapituliert; der Krieg in Europa ist vorbei."
    },
    {
        "title": "Indien wird unabhängig",
        "year": 1947,
        "desc": "Die britische Kolonialherrschaft in Indien endet."
    },
    {
        "title": "Erste erfolgreiche Besteigung des Mount Everest",
        "year": 1953,
        "desc": "Edmund Hillary und Tenzing Norgay erreichen den höchsten Gipfel der Erde."
    },
    {
        "title": "Sputnik wird ins All geschossen",
        "year": 1957,
        "desc": "Die Sowjetunion bringt den ersten künstlichen Satelliten in die Erdumlaufbahn."
    },
    {
        "title": "Bau der Berliner Mauer",
        "year": 1961,
        "desc": "Die Grenze zwischen Ost- und West-Berlin wird abgeriegelt."
    },
    {
        "title": "John F. Kennedy wird ermordet",
        "year": 1963,
        "desc": "Der US-Präsident wird während eines Besuchs in Dallas erschossen."
    },
    {
        "title": "Erste Mondlandung",
        "year": 1969,
        "desc": "Neil Armstrong und Buzz Aldrin betreten als erste Menschen den Mond."
    },
    {
        "title": "Fall der Berliner Mauer",
        "year": 1989,
        "desc": "Die Grenze zwischen Ost- und West-Berlin wird wieder geöffnet."
    },
    {
        "title": "Die Sowjetunion zerfällt",
        "year": 1991,
        "desc": "Die Sowjetunion löst sich auf und mehrere Staaten werden unabhängig."
    },
    {
        "title": "Anschläge vom 11. September",
        "year": 2001,
        "desc": "Terroranschläge in den USA erschüttern die Welt."
    },
    {
        "title": "Weltweite Finanzkrise",
        "year": 2008,
        "desc": "Eine Bankenkrise löst eine schwere Wirtschaftskrise aus."
    },
    {
        "title": "Der Rover Curiosity landet auf dem Mars",
        "year": 2012,
        "desc": "Ein Forschungsfahrzeug der NASA beginnt den Mars zu erkunden."
    },
    {
        "title": "Die WHO erklärt COVID-19 zur Pandemie",
        "year": 2020,
        "desc": "Das Coronavirus breitet sich weltweit aus."
    },
    {
        "title": "Erste Bilder des James-Webb-Weltraumteleskops",
        "year": 2022,
        "desc": "Ein neues Weltraumteleskop veröffentlicht seine ersten Aufnahmen."
    },
    {
        "title": "EO6",
        "year": 2011,
        "desc": "Ereignis in Malaysia (Inhaftierung von sechs Personen)"
    },
    {
        "title": "PS1-10jh",
        "year": 2012,
        "desc": "Lichtblitz aufgrund einer Supernova"
    },
    {
        "title": "Asylsagen",
        "year": 2007,
        "desc": "Ereignis in Dänemark"
    },
    {
        "title": "Niš (Boot)",
        "year": 1952,
        "desc": "am 9. September 1952 versunkenes Boot in der Donau"
    },
    {
        "title": "Noc teczek",
        "year": 1992,
        "desc": "Begriff im polnischen  Journalismus für ein politisches Ereignis (Nacht vom 4. auf den 5. Juni 1992)"
    },
    {
        "title": "Zittau–Leipzig",
        "year": 1908,
        "desc": "traditionsreiches Tages-Radrennen um 1900"
    },
    {
        "title": "Conradi-Affäre",
        "year": 1923,
        "desc": "diplomatisch-politische Affäre zwischen der Schweiz"
    },
    {
        "title": "Séralini-Affäre",
        "year": 2012,
        "desc": "Medizin-Skandal"
    },
    {
        "title": "Hochhaussinfonie",
        "year": 2006,
        "desc": "multimediale Musikinszenierung der Dresdner Sinfoniker und der Pet Shop Boys"
    },
    {
        "title": "Dan-Air-Flug 1903",
        "year": 1970,
        "desc": "Flugunfall in Spanien 1970"
    },
    {
        "title": "Eierwurf von Halle",
        "year": 1991,
        "desc": "Protestaktion auf Bundeskanzler Helmut Kohl am 10. Mai 1991 in Halle (Saale)"
    },
    {
        "title": "Stampex Herbst 2016",
        "year": 2016,
        "desc": "britische Briefmarkenausstellung im Herbst 2016"
    },
    {
        "title": "Todesfall Sammy Baker",
        "year": 2020,
        "desc": "Todesfall in Amsterdam"
    },
    {
        "title": "Arizierung Wildenstein",
        "year": 1941,
        "desc": "Arisierung in Frankreich"
    },
    {
        "title": "CONCACAF Gold Cup 2017",
        "year": 2017,
        "desc": "24. Ausspielung der Kontinentalmeisterschaft im Fußball für Nord-"
    },
    {
        "title": "Sturm auf den Reichstag",
        "year": 2020,
        "desc": "Vorfall am 29. August 2020"
    },
    {
        "title": "Mauerbach-Auktion (1996)",
        "year": 1996,
        "desc": "1996 wurde \"herrenloses Gut\" zugunsten von NS-Opfern versteigert, obwohl die Vorbesitzer teils bekannt waren"
    },
    {
        "title": "Vorfall auf der Insel Heping",
        "year": 1947,
        "desc": "Keelung-Massaker von 1947 auf Taiwan"
    },
    {
        "title": "Women's Coronation Procession",
        "year": 1911,
        "desc": "Fest-/Demonstrationszug für Frauenwahlberechtigung durch London am 17. Juni 1911"
    },
    {
        "title": "Entführung von Ylenia Lenhard",
        "year": 2007,
        "desc": "Kriminalfall"
    },
    {
        "title": "Nordkorea-Russland-Gipfel 2019",
        "year": 2019,
        "desc": "Treffen von Kim Jong-un und Wladimir Putin in Wladiwostok"
    },
    {
        "title": "Grubenunglück von Hpakant 2021",
        "year": 2021,
        "desc": "Erdrutsch bei einem Jade-Bergwerk in Hpakant 2021"
    },
    {
        "title": "Verbrechen von Zaleszczyki 1941",
        "year": 1941,
        "desc": "Massenmord von NKWD-Funktionären (1941)"
    },
    {
        "title": "Räumung des Hambacher Forsts 2018",
        "year": 2018,
        "desc": "Ereignis"
    },
    {
        "title": "Gleisabsenkung auf der Rheintalbahn",
        "year": 2017,
        "desc": "Ereignis im August 2017"
    },
    {
        "title": "31Angriffe in Kaduna und Katsina 2021",
        "year": 2021,
        "desc": "kriminelle Angriffe in Nigeria"
    },
    {
        "title": "Bombenanschlag in Kabul am 31. Mai 2017",
        "year": 2017,
        "desc": "Anschlag in Kabul"
    },
    {
        "title": "Flug der Lightning XM135 am 22. Juli 1966",
        "year": 1966,
        "desc": "unbeabsichtigter Flug eines britischen Abfangjägers"
    },
    {
        "title": "Wintereinbruch in Mitteleuropa April 2016",
        "year": 2016,
        "desc": "Starkschnee in Europa 2016"
    },
    {
        "title": "Sächsische Nationalversammlung in Mediasch",
        "year": 1919,
        "desc": "1919"
    },
    {
        "title": "Krise in der peruanischen Botschaft in Havanna 1980",
        "year": 1980,
        "desc": "Besetzung der peruanischen Botschaft in Havanna durch kubanische Ausreisewillige im April 1980"
    },
    {
        "title": "Erste Warnstreiks in der Metall- und Elektroindustrie",
        "year": 2007,
        "desc": "Artikel bei Wikinews"
    },
    {
        "title": "Black Lives Matter-Demonstration in Hof am 20.06.2020",
        "year": 2020,
        "desc": "Black-Lives-Matter-Demonstration in Hof"
    },
    {
        "title": "Beschlagnahmung \"herrenloser\" jüdischer Kunstsammlungen",
        "year": 1940,
        "desc": "Holocaust-Ereignis in Frankreich (01.09.1940-01.12.1940) Jüdische Kunstsammlungen werden per Nazi-Dekret für \"herrenlos\" erklärt und beschlagnahmt"
    },
    {
        "title": "Sturm auf die Stasi-Zentrale in der Normannenstraße 1990",
        "year": 1990,
        "desc": "Ereignis in Ost-Berlin am 15. Januar 1990"
    },
    {
        "title": "Fridays-For-Future-Demonstration in Hof (Saale) am 24.09.2021",
        "year": 2021,
        "desc": "Lokaler Teil des globalen Klimastreiks"
    },
    {
        "title": "Auseinandersetzung zwischen Königin Letizia und Königin Sophie in Palma",
        "year": 2018,
        "desc": "Ereignis im Jahr 2018 in Palma de Mallorca"
    },
    {
        "title": "Entscheid der Stiftung Kunstmuseum Bern bezüglich Rückgabeforderung der Erben nach Dr. Ismar Littmann",
        "year": 2021,
        "desc": "Stiftungsrat des Kunstmuseum Bern 5. November 2021"
    },
    {
        "title": "Hugo Helbing Lecture – Prof. Dr. Michael Kauffmann: “Hugo Helbing in London”, May 8th 2019 (7pm), NS-Dokumentationszentrum and Zentralinstitut für Kunstgeschichte, Munich",
        "year": 2019,
        "desc": "Kunstgeschichtsvortrag"
    },
    {
        "title": "Auktion bei Hans W. Lange, Eine Berline Privatsammlung: 28 Gemälde, Gouachen, Aquarelle und Handzeichnungen von Adolf von Menzel, Gemälde deutscher Meister des 19. Jahrhunderts",
        "year": 1939,
        "desc": "Kunstauktion bei Hans W. Lange, 7. Februar 1939 in Berlin"
    },
    {
        "title": "Michael Cho",
        "year": 2007,
        "desc": "2007 Erschießung eines koreanisch-amerikanischen Mannes in La Habra, Kalifornien"
    },
    {
        "title": "Yakai-Vorfall",
        "year": 1951,
        "desc": "Historisches Ereignis aus dem Jahr 1951."
    },
    {
        "title": "OpéraMorphose",
        "year": 2020,
        "desc": "Historisches Ereignis aus dem Jahr 2020."
    },
    {
        "title": "Captain Midnight",
        "year": 1986,
        "desc": "1986 Entführung von HBO durch den amerikanischen Geschäftsmann Captain Midnight"
    },
    {
        "title": "Sonderaktion Prag",
        "year": 1939,
        "desc": "Historisches Ereignis aus dem Jahr 1939."
    },
    {
        "title": "Viquitrobada 2012",
        "year": 2012,
        "desc": "Historisches Ereignis aus dem Jahr 2012."
    },
    {
        "title": "Invasion bei Luperón",
        "year": 1949,
        "desc": "Historisches Ereignis aus dem Jahr 1949."
    },
    {
        "title": "Männer des 28. Oktober",
        "year": 1918,
        "desc": "Gründung des neuen Staates Tschechoslowakei im Jahr 1918"
    },
    {
        "title": "Death of Belly Mujinga",
        "year": 2020,
        "desc": "2020 Tod einer Frau an COVID-19"
    },
    {
        "title": "Death of Robert Fuller",
        "year": 2020,
        "desc": "Tod eines Amerikaners im Jahr 2020"
    },
    {
        "title": "Luftangriffe auf Danzig",
        "year": 1940,
        "desc": "Historisches Ereignis aus dem Jahr 1940."
    },
    {
        "title": "Death of Layleen Polanco",
        "year": 2019,
        "desc": "Transgender-Frau, die im Gefängnis starb"
    },
    {
        "title": "Letecký den Třebíč (akce)",
        "year": 1931,
        "desc": "Historisches Ereignis aus dem Jahr 1931."
    },
    {
        "title": "Zwischenfall in Hochlinden",
        "year": 1939,
        "desc": "Historisches Ereignis aus dem Jahr 1939."
    },
    {
        "title": "Arisierung Kunsthaus Kende",
        "year": 1944,
        "desc": "Ereignis im Jahr 1944"
    },
    {
        "title": "Killing of Andres Guardado",
        "year": 2020,
        "desc": "Tödliche Schießerei im Jahr 2020"
    },
    {
        "title": "Rheinische Jahrtausendfeier",
        "year": 1925,
        "desc": "Historisches Ereignis aus dem Jahr 1925."
    },
    {
        "title": "Staatskrise in Ägypten 1942",
        "year": 1942,
        "desc": "versuchter britischer Putsch in Ägypten"
    },
    {
        "title": "Belvedere restituiert Munch",
        "year": 2007,
        "desc": "Nachrichtenartikel"
    },
    {
        "title": "Death of Amy Joyner-Francis",
        "year": 2016,
        "desc": "Gewaltvorfall in der Schule im Jahr 2016"
    },
    {
        "title": "Burger-Fischer v. Degussa AG",
        "year": 1999,
        "desc": "Klage wegen Holocaust"
    },
    {
        "title": "Bakuer Siegesparade von 2020",
        "year": 2020,
        "desc": "Militärische Triumphparade im Jahr 2020"
    },
    {
        "title": "Große Meteorprozession von 1913",
        "year": 1913,
        "desc": "Meteorprozession in den 1913er Jahren"
    },
    {
        "title": "Sydney Harbour fatal ferry crash",
        "year": 2007,
        "desc": "Bootsunfall in Australien"
    },
    {
        "title": "2013 New Brunswick python attack",
        "year": 2013,
        "desc": "Tötung zweier Jungen durch eine afrikanische Felsenpython"
    },
    {
        "title": "Angriff auf US-Konsulat in Herat 2013",
        "year": 2013,
        "desc": "Angriff der Taliban in Afghanistan"
    },
    {
        "title": "Angriffe in Zentralnigeria im Juni 2014",
        "year": 2014,
        "desc": "Anschlagsserie in Zentralnigeria"
    },
    {
        "title": "Sanierung des Spielplatzes in Schlatkow",
        "year": 2021,
        "desc": "Historisches Ereignis aus dem Jahr 2021."
    },
    {
        "title": "Überschwemmungen in Australien Juli 2022",
        "year": 2022,
        "desc": "Katastrophe 2022 in New South Wales"
    },
    {
        "title": "Fall des faschistischen Regimes in Italien",
        "year": 1943,
        "desc": "1943 Absetzung des italienischen Premierministers Benito Mussolini"
    },
    {
        "title": "Bombenanschlag in Kabul am 5. September 2018",
        "year": 2018,
        "desc": "Mord 2018 in Afghanistan"
    },
    {
        "title": "Selbstmordanschlag in Kabul am 21. November 2016",
        "year": 2016,
        "desc": "Historisches Ereignis aus dem Jahr 2016."
    },
    {
        "title": "Angriff auf die pakistanische Botschaft in Kabul 1995",
        "year": 1995,
        "desc": "Angriff afghanischer Demonstranten auf die pakistanische Botschaft in Kabul, Afghanistan"
    },
    {
        "title": "Angriff auf die pakistanische Botschaft in Teheran 2009",
        "year": 2009,
        "desc": "Historisches Ereignis aus dem Jahr 2009."
    },
    {
        "title": "ungarische Nationalversammlung am 22. Dezember 1918 in Klausenburg",
        "year": 1918,
        "desc": "Historisches Ereignis aus dem Jahr 1918."
    },
    {
        "title": "Rückkehr der Heiligen Krone von Ungarn von den Vereinigten Staaten von Amerika",
        "year": 1978,
        "desc": "Historisches Ereignis aus dem Jahr 1978."
    },
    {
        "title": "Irland: Eine Frau stirbt, nachdem sie an einer Abtreibung gehindert wurde (Irlande : une femme meurt après avoir été empêchée d'avorter)",
        "year": 2012,
        "desc": "Nachrichtenartikel 2012 (auf Französisch Le Monde)"
    },
    {
        "title": "Talangsari-Vorfall",
        "year": 1989,
        "desc": "Ereignis in  Indonesien 1989"
    },
    {
        "title": "Patronitenforum 2022",
        "year": 2022,
        "desc": "Artikel bei Wikinews"
    },
    {
        "title": "Osmanischer Eintritt in den Ersten Weltkrieg",
        "year": 1914,
        "desc": "Aspekt der Geschichte"
    },
    {
        "title": "Stepan Banderas Geburtstag 2019",
        "year": 2019,
        "desc": "Artikel bei Wikinews"
    },
    {
        "title": "Tod und Staatsbegräbnis von Fidel Castro (2016; death and state funeral of Fidel Castro)",
        "year": 2016,
        "desc": "Artikel bei Wikinews"
    },
    {
        "title": "Ende des britischen Mandats für Palästina (1948; End of the British Mandate for Palestine)",
        "year": 1948,
        "desc": "Aspekt der Geschichte"
    },
    {
        "title": "Transgas, poslední komentovaná prohlídka",
        "year": 2018,
        "desc": "Artikel bei Wikinews"
    },
    {
        "title": "2014 Rammangriff in Saint-Jean-sur-Richelieu",
        "year": 2014,
        "desc": "Artikel bei Wikinews"
    },
    {
        "title": "Eröffnung des Junior-Boxclubs in Tjumen, 2016",
        "year": 2016,
        "desc": "Wikimedia-Kategorie"
    },
    {
        "title": "Die ukrainische Wikipedia wurde an den Nationalarchivfonds übertragen",
        "year": 2017,
        "desc": "Artikel bei Wikinews"
    },
    {
        "title": "V-4",
        "year": 1942,
        "desc": "Historisches Ereignis aus dem Jahr 1942."
    },
    {
        "title": "AppleToo",
        "year": 2021,
        "desc": "Mitarbeiterunruhen 2021 bei Apple, Inc"
    },
    {
        "title": "NTV-Affäre (2001; NTV Affair)",
        "year": 2001,
        "desc": "2001 Übernahme von NTV durch Gazprom und die russische Regierung"
    },
    {
        "title": "Boudougate",
        "year": 2012,
        "desc": "Politischer Skandal in Argentinien um Vizepräsident Amado Boudou und die Druckerei Ciccone Calcografica."
    },
    {
        "title": "Jason-Fall",
        "year": 2018,
        "desc": "die Tötung einer Katze namens Jason"
    },
    {
        "title": "Conecta SP",
        "year": 2021,
        "desc": "Historisches Ereignis aus dem Jahr 2021."
    },
    {
        "title": "Blanchiment",
        "year": 1944,
        "desc": "Historisches Ereignis aus dem Jahr 1944."
    },
    {
        "title": "Deflategate",
        "year": 2009,
        "desc": "Skandal in der National Football League"
    },
    {
        "title": "ECFA-Debatte",
        "year": 2010,
        "desc": "Historisches Ereignis aus dem Jahr 2010."
    },
    {
        "title": "Alton Nolen",
        "year": 2014,
        "desc": "Anschlag 2014 in Moore, Oklahoma, USA"
    },
    {
        "title": "Fortel 2015",
        "year": 2015,
        "desc": "Historisches Ereignis aus dem Jahr 2015."
    },
    {
        "title": "Leichter Taktstock",
        "year": 2015,
        "desc": "Ungarische Veranstaltung im I. Internationalen Jahr des Lichts"
    },
    {
        "title": "Adpokalypse (2017; adpocalypse)",
        "year": 2017,
        "desc": "Ereignis aus dem Jahr 2017, das sich auf die Monetarisierung des YouTube-Kanals auswirkt"
    },
    {
        "title": "Pemi-Angriff",
        "year": 2020,
        "desc": "Historisches Ereignis aus dem Jahr 2020."
    },
    {
        "title": "BelgianGate",
        "year": 2022,
        "desc": "2022 politischer Korruptionsskandal rund um das Europäische Parlament"
    },
    {
        "title": "Egryn-Lichter",
        "year": 1904,
        "desc": "Historisches Ereignis aus dem Jahr 1904."
    },
    {
        "title": "Iowa-Kuhkrieg (1931; Iowa Cow War)",
        "year": 1931,
        "desc": "1931 Streit in Iowa über die Untersuchung von Kühen auf Rindertuberkulose."
    },
    {
        "title": "Aufstand der Srb (1941; Srb uprising)",
        "year": 1941,
        "desc": "1941 Aufstand in Kroatien"
    },
    {
        "title": "Yehud-Angriff (1953; Yehud attack)",
        "year": 1953,
        "desc": "1953 Angriff auf israelische Zivilisten durch palästinensisch-arabische Fedajin"
    },
    {
        "title": "Schwarzer Freitag (1987; Black Friday)",
        "year": 1987,
        "desc": "Demonstrationsunterdrückung in Panama am 10. Juli 1987"
    },
    {
        "title": "Khataba-Überfall",
        "year": 2010,
        "desc": "US-Angriff auf afghanischen Wohnsitz im Krieg in Afghanistan"
    },
    {
        "title": "Šamajim 2011",
        "year": 2011,
        "desc": "Festival der jüdischen Kultur in Třebíč, Tschechische Republik"
    },
    {
        "title": "Facebook-Börsengang",
        "year": 2012,
        "desc": "Börsengang von Facebook Inc."
    },
    {
        "title": "Letzte Schlacht",
        "year": 2015,
        "desc": "Pay-per-View-Veranstaltung Ring of Honor 2015"
    },
    {
        "title": "Astronomisch",
        "year": 2020,
        "desc": "Fortnite-Live-Event 2020"
    },
    {
        "title": "Mopti-Angriff",
        "year": 2020,
        "desc": "Eine Reihe militärischer Zwischenfälle und Massaker in Mali in den 2020er Jahren"
    },
    {
        "title": "Yle Olohuone",
        "year": 2020,
        "desc": "Reihe finnischer Online-Veranstaltungen und Fernsehprogramme, die während der Coronavirus-Pandemie von der finnischen Rundfunkgesellschaft Yle live übertragen werden"
    },
    {
        "title": "Aurora-Ereignis",
        "year": 2021,
        "desc": "Yles-Veranstaltung des finnischen Rundfunks zum Thema Gleichberechtigung und Verantwortung"
    },
    {
        "title": "Osterfrieden (2022; Easter truce)",
        "year": 2022,
        "desc": "Fehlgeschlagener Waffenstillstand bei der russischen Invasion in der Ukraine im Jahr 2022"
    },
    {
        "title": "Askeran-Zusammenstoß",
        "year": 1988,
        "desc": "1988 Aufruhr und Mord in Askeran, Aserbaidschanische SSR"
    },
    {
        "title": "Den v krojích",
        "year": 2009,
        "desc": "Historisches Ereignis aus dem Jahr 2009."
    },
    {
        "title": "Garowe-Angriff",
        "year": 2015,
        "desc": "Historisches Ereignis aus dem Jahr 2015."
    },
    {
        "title": "Raus auf Bargeld",
        "year": 2021,
        "desc": "Veranstaltung 2021 in Sioux Falls, South Dakota"
    },
    {
        "title": "Das Jungtier",
        "year": 2021,
        "desc": "fliegende Marionette"
    },
    {
        "title": "Pierce County",
        "year": 2022,
        "desc": "Angriff auf ein Umspannwerk am 25. Dezember 2022"
    },
    {
        "title": "Frauensonntag (1908; Women's Sunday)",
        "year": 1908,
        "desc": "Suffragetten-Massendemonstration, London 1908"
    },
    {
        "title": "Bychow sitzend",
        "year": 1917,
        "desc": "Historisches Ereignis aus dem Jahr 1917."
    },
    {
        "title": "Friedenstag 1919",
        "year": 1919,
        "desc": "1919 Parade in London"
    },
    {
        "title": "Linke Fehler (1941; Leftist errors)",
        "year": 1941,
        "desc": "manchmal auch „Roter Terror“ genannt, eine Zeit in Jugoslawien (1941–42) während des Zweiten Weltkriegs"
    },
    {
        "title": "Ostermassaker",
        "year": 1946,
        "desc": "Historisches Ereignis aus dem Jahr 1946."
    },
    {
        "title": "Groveland-Fall",
        "year": 1950,
        "desc": "Historisches Ereignis aus dem Jahr 1950."
    },
    {
        "title": "Schwarzer Donnerstag",
        "year": 1960,
        "desc": "das Versagen von US-Athleten, bei den Leichtathletik-Wettbewerben am 1. September 1960 bei den Olympischen Spielen in Rom gute Leistungen zu erbringen"
    },
    {
        "title": "1970 Radioverbot",
        "year": 1970,
        "desc": "Streit um die Musikindustrie in Australien"
    },
    {
        "title": "Silco-Vorfall (1985; Silco incident)",
        "year": 1985,
        "desc": "1985 Entführung einer belgisch-französischen Familie durch die libysche Regierung"
    },
    {
        "title": "Tolle Umbenennung (1987; Great Renaming)",
        "year": 1987,
        "desc": "Umstrukturierung der Usenet-Newsgroups im Jahr 1987"
    },
    {
        "title": "Guemmar-Angriff (1991; Guemmar attack)",
        "year": 1991,
        "desc": "Militanter Angriff auf einen Grenzposten in Algerien"
    },
    {
        "title": "Krushë und Madhe",
        "year": 1999,
        "desc": "Dorf im Westen Kosovos"
    },
    {
        "title": "Intercamp 2016",
        "year": 2016,
        "desc": "Historisches Ereignis aus dem Jahr 2016."
    },
    {
        "title": "Košna u snežet",
        "year": 2018,
        "desc": "Historisches Ereignis aus dem Jahr 2018."
    },
    {
        "title": "Zaoyang-Angriff",
        "year": 2019,
        "desc": "Fahrzeugrammangriff in Zaoyang, China"
    },
    {
        "title": "Kouyape-Angriff",
        "year": 2020,
        "desc": "Angriff im Jahr 2020 auf ein Flüchtlingslager in Kamerun"
    },
    {
        "title": "Kulttuurigaala",
        "year": 2021,
        "desc": "eine Preisgala für den finnischen Kultursektor"
    },
    {
        "title": "Novara rammt",
        "year": 2021,
        "desc": "Historisches Ereignis aus dem Jahr 2021."
    },
    {
        "title": "Epynt-Freigabe",
        "year": 1940,
        "desc": "1940 Zwangsräumung in Powys, Wales"
    },
    {
        "title": "Sibelius-viikko",
        "year": 1951,
        "desc": "Das Festival für klassische Musik, das dem Helsingin juhlaviikot vorausgeht und zwischen 1951 und 1965 organisiert wurde"
    },
    {
        "title": "Gwadar-Kauf",
        "year": 1958,
        "desc": "1958 Übernahme von Gwadar durch Pakistan"
    },
    {
        "title": "Einnahme von Pando (1969; Taking of Pando)",
        "year": 1969,
        "desc": "1969 Schlacht in Uruguay"
    },
    {
        "title": "Enpetrol-Angriff",
        "year": 1987,
        "desc": "Historisches Ereignis aus dem Jahr 1987."
    },
    {
        "title": "Vergewaltigung in Glen Ridge (1989; Glen Ridge rape)",
        "year": 1989,
        "desc": "1989 Vergewaltigung eines Mädchens in Glen Ridge, New Jersey"
    },
    {
        "title": "Llogara-Tragödie (1989; Llogara Tragedy)",
        "year": 1989,
        "desc": "1989 Busunfall und Hubschrauberabsturz in Albanien"
    },
    {
        "title": "Marlboro Freitag (1993; Marlboro Friday)",
        "year": 1993,
        "desc": "Preisverfall bei Marlboro-Zigaretten am 2. April 1993"
    },
    {
        "title": "1997 Lego-Katastrophe",
        "year": 1997,
        "desc": "Seeunfall in Cornwall, England"
    },
    {
        "title": "Ghulja-Vorfall (1997; Ghulja Incident)",
        "year": 1997,
        "desc": "1997 gewaltsames Ereignis im Uiguren-Han-Konflikt in Xinjiang"
    },
    {
        "title": "Vorfall in Rjasan",
        "year": 1999,
        "desc": "Entdeckung von platziertem Sprengstoff"
    },
    {
        "title": "Pogrom in Miass",
        "year": 2010,
        "desc": "Historisches Ereignis aus dem Jahr 2010."
    },
    {
        "title": "Montreal-Bolide",
        "year": 2013,
        "desc": "Historisches Ereignis aus dem Jahr 2013."
    },
    {
        "title": "Tod von Frau Dhu (2014; Death of Ms Dhu)",
        "year": 2014,
        "desc": "Tod einer australischen Aborigine-Frau in Polizeigewahrsam"
    },
    {
        "title": "Nadschran-Beschuss",
        "year": 2015,
        "desc": "Historisches Ereignis aus dem Jahr 2015."
    },
    {
        "title": "Chaos von 499 NT$",
        "year": 2018,
        "desc": "Historisches Ereignis aus dem Jahr 2018."
    },
    {
        "title": "Feministisches Quadrat",
        "year": 2019,
        "desc": "Straßendemonstrationstaktik, die bei den algerischen Hirak-Protesten 2009 zu einer wöchentlichen Veranstaltung wurde"
    },
    {
        "title": "JNU-Angriff 2020",
        "year": 2020,
        "desc": "Angriff auf einen Universitätscampus in Indien"
    },
    {
        "title": "Agbudu-Schießerei (2020; Agbudu shooting)",
        "year": 2020,
        "desc": "Massenerschießung 2020 in Nigeria"
    },
    {
        "title": "Baakline-Angriff",
        "year": 2020,
        "desc": "Gewalttätiger Angriff im Libanon"
    },
    {
        "title": "Schillernder Tag",
        "year": 2020,
        "desc": "Die Veranstaltung wurde im Februar 2021 organisiert, um die Iris zu verlassen"
    },
    {
        "title": "Seydibesir-Ereignis",
        "year": 1918,
        "desc": "Historisches Ereignis aus dem Jahr 1918."
    },
    {
        "title": "Kunming-Vorfall",
        "year": 1945,
        "desc": "Historisches Ereignis aus dem Jahr 1945."
    },
    {
        "title": "Troja-Axtmorde (1964; Troy axe murders)",
        "year": 1964,
        "desc": "1964 Massenmord in Michigan"
    },
    {
        "title": "Den Damm fegen",
        "year": 1970,
        "desc": "Historisches Ereignis aus dem Jahr 1970."
    },
    {
        "title": "Der Calhoun-Schuss (1993; The Calhoun Shot)",
        "year": 1993,
        "desc": "Basketballschuss, der im Rahmen einer Werbeaktion während eines NBA-Spiels im Jahr 1993 gemacht wurde"
    },
    {
        "title": "Peshkëpi-Tötung",
        "year": 1994,
        "desc": "Historisches Ereignis aus dem Jahr 1994."
    },
    {
        "title": "Bullhorn-Adresse (2001; Bullhorn Address)",
        "year": 2001,
        "desc": "Rede von Präsident George W. Bush nach den Anschlägen vom 11. September 2001"
    },
    {
        "title": "Miss Schweden 2003",
        "year": 2003,
        "desc": "Historisches Ereignis aus dem Jahr 2003."
    },
    {
        "title": "Leggheit-Angriff (2005; Lemgheity attack)",
        "year": 2005,
        "desc": "Islamistischer Angriff auf eine mauretanische Kaserne"
    },
    {
        "title": "Bihar-Überschwemmung 2008",
        "year": 2008,
        "desc": "verheerende Überschwemmung in Bihar, Indien"
    },
    {
        "title": "Geocoinfest 2013",
        "year": 2013,
        "desc": "Historisches Ereignis aus dem Jahr 2013."
    },
    {
        "title": "Angriff auf den Tschadsee",
        "year": 2014,
        "desc": "Historisches Ereignis aus dem Jahr 2014."
    },
    {
        "title": "Befreiung Mosuls",
        "year": 2017,
        "desc": "Militärkampagne 2017"
    },
    {
        "title": "Angriff auf Adabda",
        "year": 2021,
        "desc": "Kampf 2021"
    },
    {
        "title": "Luftangriff in Togoga (2021; Togoga airstrike)",
        "year": 2021,
        "desc": "Am 22. Juni 2021 kam es in Togoga, Region Tigray, zu einem Luftangriff"
    },
    {
        "title": "Otomabere-Angriff",
        "year": 2022,
        "desc": "Anschlag 2022 in Bwanasura, Demokratische Republik Kongo"
    },
    {
        "title": "Miss-Stone-Affäre (1901; Miss Stone Affair)",
        "year": 1901,
        "desc": "die Entführung von Ellen Maria Stone und Katerina Cilko durch die Interne Mazedonische Revolutionäre Organisation"
    },
    {
        "title": "¡Cu-Cut! Vorfall",
        "year": 1905,
        "desc": "Angriff spanischer Offiziere aufgrund einer satirischen Karikatur"
    },
    {
        "title": "Der Fall Frank Giroux",
        "year": 1907,
        "desc": "US-Asylvorfall 1907"
    },
    {
        "title": "Spring Creek-Überfall (1909; Spring Creek Raid)",
        "year": 1909,
        "desc": "1909 Konflikt zwischen Viehzüchtern und Schafhirten in Wyoming"
    },
    {
        "title": "Zweite Revolution (1913; Second Revolution)",
        "year": 1913,
        "desc": "1913 Aufstand der südlichen Provinzen"
    },
    {
        "title": "Nakamura-Vorfall",
        "year": 1931,
        "desc": "Historisches Ereignis aus dem Jahr 1931."
    },
    {
        "title": "Kuramoto-Vorfall",
        "year": 1934,
        "desc": "Historisches Ereignis aus dem Jahr 1934."
    },
    {
        "title": "Familie Lubkiewicz",
        "year": 1943,
        "desc": "Historisches Ereignis aus dem Jahr 1943."
    },
    {
        "title": "Acre-Gefängnisausbruch (1947; Acre Prison break)",
        "year": 1947,
        "desc": "Gefängnisausbruch in Palästina 1947"
    },
    {
        "title": "Angriff auf Beit Hanan",
        "year": 1955,
        "desc": "Historisches Ereignis aus dem Jahr 1955."
    },
    {
        "title": "Amityville-Affäre (1974; Amityville affair)",
        "year": 1974,
        "desc": "Ereignisse, die die Grundlage eines Buches bildeten"
    },
    {
        "title": "Angriff auf Ramble Inn (1976; Ramble Inn attack)",
        "year": 1976,
        "desc": "Schießerei der UVF in der Nähe von Antrim"
    },
    {
        "title": "Tragedia de Tacoa",
        "year": 1982,
        "desc": "1982 Öltankbrand in Venezuela"
    },
    {
        "title": "Brücke der Blumen (1990; Bridge of Flowers)",
        "year": 1990,
        "desc": "Veranstaltung im Jahr 1990 von Demonstranten, die sich für die Vereinigung Rumäniens und Moldawiens einsetzten"
    },
    {
        "title": "1998 Alma-Amoklauf",
        "year": 1998,
        "desc": "Mord und Fahrzeugangriff auf die Stadt"
    },
    {
        "title": "Muthanga-Vorfall",
        "year": 2003,
        "desc": "2003 schießt die Polizei auf Demonstranten in Kerala, Indien"
    },
    {
        "title": "Operation D-Elite",
        "year": 2005,
        "desc": "Bundesoperation gegen Torrent-Tracker-Site"
    },
    {
        "title": "Hamdania-Vorfall (2006; Hamdania incident)",
        "year": 2006,
        "desc": "Ermordung eines Irakers durch US-Marine"
    },
    {
        "title": "Es steht auf dem Messgerät",
        "year": 2011,
        "desc": "Autoreise um die Welt 2011"
    },
    {
        "title": "Kano-Bombenanschlag 2014",
        "year": 2014,
        "desc": "2014 islamistischer Terroranschlag in Kano, Nigeria"
    },
    {
        "title": "Morde in Beitunia",
        "year": 2014,
        "desc": "Böse Morde an zwei unschuldigen Teenagern"
    },
    {
        "title": "Kogi-Gefängnisausbruch",
        "year": 2014,
        "desc": "2014 Gefängnisausbruch im nigerianischen Gefängnis"
    },
    {
        "title": "Atmeh-Angriff 2016",
        "year": 2016,
        "desc": "Selbstmordattentat"
    },
    {
        "title": "Unfall im Erasmus-Bus (2016; Erasmus bus crash)",
        "year": 2016,
        "desc": "Busunfall in Spanien am 20. März 2016"
    },
    {
        "title": "Gandhi-Marsch 2019",
        "year": 2019,
        "desc": "Historisches Ereignis aus dem Jahr 2019."
    },
    {
        "title": "Überschwemmungen in Nepal 2020",
        "year": 2020,
        "desc": "Überschwemmungen 2020 in Nepal"
    },
    {
        "title": "Nguetchewe-Angriff",
        "year": 2020,
        "desc": "2020 Boko-Haram-Anschlag in Kamerun"
    },
    {
        "title": "Kaduna-Entführung (2021; Kaduna kidnapping)",
        "year": 2021,
        "desc": "Entführungsereignis 2021 im Norden Nigerias"
    },
    {
        "title": "Kagara-Entführung (2021; Kagara kidnapping)",
        "year": 2021,
        "desc": "2021 Ziviler Angriff in Nigeria"
    },
    {
        "title": "ML Rabit Al Hasan",
        "year": 2021,
        "desc": "Seeunfall 2021 in Bangladesch"
    },
    {
        "title": "Angriff von Petel Kole",
        "year": 2022,
        "desc": "2022 Massenmord in Niger"
    },
    {
        "title": "Haidbauer-Vorfall",
        "year": 1926,
        "desc": "Körperlicher Angriff auf ein Kind von Ludwig Wittgenstein"
    },
    {
        "title": "Italienische Befreiung",
        "year": 1945,
        "desc": "Befreiung Italiens vom Nazifaschismus"
    },
    {
        "title": "Heißer Sommer 1975",
        "year": 1975,
        "desc": "Veranstaltung aus Portugal im Jahr 1975"
    },
    {
        "title": "Patti Starr-Affäre",
        "year": 1989,
        "desc": "Kanadische politische Kontroverse"
    },
    {
        "title": "Gniezno-Kongresse",
        "year": 1997,
        "desc": "Dialog zwischen verschiedenen Kulturen, Konfessionen und Religionen; Die Veranstaltung bezieht sich auf die Tradition des Gniezno-Kongresses aus dem Jahr 1000"
    },
    {
        "title": "Mord an einer Rolex-Uhr (1998; Rolex watch murder)",
        "year": 1998,
        "desc": "1998 Raubmord in Singapur"
    },
    {
        "title": "Kufa-Beschuss 2004",
        "year": 2004,
        "desc": "Teil des Irak-Krieges"
    },
    {
        "title": "Der Fall Howard Morgan",
        "year": 2005,
        "desc": "Vorfall, der sich am 21. Februar 2005 in Chicago, Illinois, USA, ereignete"
    },
    {
        "title": "Horácká-Rallye 2010",
        "year": 2010,
        "desc": "Historisches Ereignis aus dem Jahr 2010."
    },
    {
        "title": "Anschläge von Paris 2013",
        "year": 2013,
        "desc": "15. und 18. November 2013"
    },
    {
        "title": "2013 Ricin-Attacken",
        "year": 2013,
        "desc": "Der Versuch, Ricin zu verbreiten und als Waffe einzusetzen"
    },
    {
        "title": "Anschlag von Nantes 2014",
        "year": 2014,
        "desc": "Fahrzeugrammangriff in Nantes, Frankreich"
    },
    {
        "title": "Garowe-Angriff 2015",
        "year": 2015,
        "desc": "Historisches Ereignis aus dem Jahr 2015."
    },
    {
        "title": "Syed Hamid Hussain",
        "year": 2016,
        "desc": "Historisches Ereignis aus dem Jahr 2016."
    },
    {
        "title": "Corinaldo-Ansturm (2018; Corinaldo stampede)",
        "year": 2018,
        "desc": "Im Jahr 2018 ereignete sich in Corinaldo, Italien, eine Tragödie"
    },
    {
        "title": "Überschwemmungen in Kerala 2020",
        "year": 2020,
        "desc": "Indische Flut"
    },
    {
        "title": "Kundgebung gegen Hass",
        "year": 2021,
        "desc": "Anti-Rassismus-Demonstration 2021 in New York"
    },
    {
        "title": "TEDxDelthorneWomen",
        "year": 2021,
        "desc": "unabhängige Veranstaltungsreihe"
    },
    {
        "title": "Wakefield-Kontrolle",
        "year": 2021,
        "desc": "2021 Interstate 95-Milizkonflikt in Massachusetts, USA"
    },
    {
        "title": "2022 Brinks Diebstahl",
        "year": 2022,
        "desc": "Schmuckdiebstahl 2022"
    },
    {
        "title": "Ngar Shan-Morde",
        "year": 2022,
        "desc": "2022 Morde in der Region Sagaing, Myanmar"
    },
    {
        "title": "Spaltung zwischen Nanjing und Wuhan (1927; Nanjing–Wuhan split)",
        "year": 1927,
        "desc": "1927 kam es zu einer politischen Spaltung zwischen der linken KMT-Regierung in Wuhan und der rechten KMT-Regierung in Nanjing"
    },
    {
        "title": "Jahilnyzja-Tragödie",
        "year": 1942,
        "desc": "Historisches Ereignis aus dem Jahr 1942."
    },
    {
        "title": "Erste Bayeux-Rede",
        "year": 1944,
        "desc": "Rede von Charles de Gaulle im Jahr 1944"
    },
    {
        "title": "Kreuzfahrt der Könige",
        "year": 1954,
        "desc": "Königliche Kreuzfahrt 1954"
    },
    {
        "title": "Morde an Ein Ofarim (1956; Ein Ofarim killings)",
        "year": 1956,
        "desc": "1956 Angriff palästinensischer Fedajin auf drusische Zivilisten in Israel"
    },
    {
        "title": "1965 Bombenanschlag auf Saigon",
        "year": 1965,
        "desc": "Bombenanschlag, bei dem 42 Menschen getötet wurden"
    },
    {
        "title": "Verlust von MV Darlwyne (1966; Loss of MV Darlwyne)",
        "year": 1966,
        "desc": "Vergnügungskreuzer, der 1966 vor der Küste Cornwalls sank"
    },
    {
        "title": "1971 Kimpo-Morde",
        "year": 1971,
        "desc": "Historisches Ereignis aus dem Jahr 1971."
    },
    {
        "title": "1981 Allen-Schießerei",
        "year": 1981,
        "desc": "Massenerschießung in Kentucky, USA"
    },
    {
        "title": "Tesco-Bombenkampagne",
        "year": 2001,
        "desc": "Erpressungsversuch gegen die britische Supermarktkette Tesco in Bournemouth, England"
    },
    {
        "title": "2006 UNC-SUV-Angriff",
        "year": 2006,
        "desc": "Fahrzeugangriff"
    },
    {
        "title": "Tod von Kaja Ballo",
        "year": 2008,
        "desc": "Norwegischer Student"
    },
    {
        "title": "Bauchi-Gefängnisausbruch",
        "year": 2010,
        "desc": "Gefängnisausbruch durch Boko Haram"
    },
    {
        "title": "Untergang Bulgariens",
        "year": 2011,
        "desc": "2011 Untergang an der Wolga in Russland"
    },
    {
        "title": "Gewalt in Assam 2012",
        "year": 2012,
        "desc": "Gewalt 2012 in Indien"
    },
    {
        "title": "Ruhm im Herrenhaus",
        "year": 2012,
        "desc": "Historisches Ereignis aus dem Jahr 2012."
    },
    {
        "title": "Flammende Nächte 2012",
        "year": 2012,
        "desc": "Historisches Ereignis aus dem Jahr 2012."
    },
    {
        "title": "Vorfall mit Wang Lijun (2012; Wang Lijun incident)",
        "year": 2012,
        "desc": "Skandal in der chinesischen Politik"
    },
    {
        "title": "Angriff auf den Zion-Platz",
        "year": 2012,
        "desc": "Angriff israelischer Jugendlicher auf vier palästinensische Jugendliche am 16. und 17. August 2012 auf dem Zion-Platz in Jerusalem"
    },
    {
        "title": "Flammende Nächte 2013",
        "year": 2013,
        "desc": "Historisches Ereignis aus dem Jahr 2013."
    },
    {
        "title": "Steylpromotion 2013",
        "year": 2013,
        "desc": "Veranstaltung in Steyl im Jahr 2013, Niederlande"
    },
    {
        "title": "Tod von Aftab Alam",
        "year": 2015,
        "desc": "Historisches Ereignis aus dem Jahr 2015."
    },
    {
        "title": "Bombenanschlag auf Lashio 2018",
        "year": 2018,
        "desc": "Bombenexplosion in der Nähe zweier Banken in Lashio, Myanmar"
    },
    {
        "title": "VCDL-Lobbytag 2020",
        "year": 2020,
        "desc": "Waffenrechtskundgebung 2020 in Richmond, Virginia"
    },
    {
        "title": "Merdeka-Basar 2020",
        "year": 2020,
        "desc": "Veranstaltung in Johor Bahru, Johor, Malaysia"
    },
    {
        "title": "Zusammenstöße in Darfur 2021",
        "year": 2021,
        "desc": "tödlicher Unruhe"
    },
    {
        "title": "2022 Mandera-Angriff",
        "year": 2022,
        "desc": "Morde im Mandera County, Kenia"
    },
    {
        "title": "Silchar-Überschwemmungen 2022",
        "year": 2022,
        "desc": "Naturkatastrophe in Assam, Indien"
    },
    {
        "title": "Tipton-Zeppelin-Überfall",
        "year": 1916,
        "desc": "Historisches Ereignis aus dem Jahr 1916."
    },
    {
        "title": "NKWD-Bestellnummer 00485",
        "year": 1937,
        "desc": "1937–38 Sowjetische ethnische Säuberung der Polen"
    },
    {
        "title": "1940 Galați-Massaker",
        "year": 1940,
        "desc": "1940 Massentötung von Zivilisten in Rumänien"
    },
    {
        "title": "Zweite Bayeux-Rede",
        "year": 1946,
        "desc": "Rede von General Charles de Gaulle"
    },
    {
        "title": "Karlino-Ölausbruch (1980; Karlino oil eruption)",
        "year": 1980,
        "desc": "Ölquellenausbruch in Karlino, Polen"
    },
    {
        "title": "1991 Punjab-Morde",
        "year": 1991,
        "desc": "Ermordung durch die Militanten"
    },
    {
        "title": "Tod von Salman Shah",
        "year": 1996,
        "desc": "1996 Tod des bangladeschischen Schauspielers Salman Shah"
    },
    {
        "title": "Simpang KKA-Vorfall (1999; Simpang KKA incident)",
        "year": 1999,
        "desc": "Erschießung von Demonstranten in Indonesien"
    },
    {
        "title": "Überfall auf den Millennium Dome",
        "year": 2000,
        "desc": "Versuchter Raub einer Diamantenausstellung"
    },
    {
        "title": "2003 India Gate-Grundstück",
        "year": 2003,
        "desc": "Historisches Ereignis aus dem Jahr 2003."
    },
    {
        "title": "Tragödie der Avenida Suba",
        "year": 2004,
        "desc": "In Bogotá, Kolumbien, ereignete sich ein Verkehrsunfall"
    },
    {
        "title": "Hunters Brooke Brandstiftung",
        "year": 2004,
        "desc": "Brandstiftung 2004 in Maryland, USA"
    },
    {
        "title": "2006 Malegaon-Explosionen",
        "year": 2006,
        "desc": "Bombenanschläge in Malegaon, Bundesstaat Maharashtra, Indien"
    },
    {
        "title": "Vorfall in Nangar Khel (2007; Nangar Khel incident)",
        "year": 2007,
        "desc": "Massaker an afghanischen Zivilisten durch polnische Soldaten"
    },
    {
        "title": "Tod von Zahra Baker",
        "year": 2010,
        "desc": "2010 Mord in Australien"
    },
    {
        "title": "Fall der Sklaverei in Lambeth",
        "year": 2013,
        "desc": "Fall der modernen Sklaverei"
    },
    {
        "title": "Changsha-Angriff 2014",
        "year": 2014,
        "desc": "Historisches Ereignis aus dem Jahr 2014."
    },
    {
        "title": "Route Nazionale 2014",
        "year": 2014,
        "desc": "Historisches Ereignis aus dem Jahr 2014."
    },
    {
        "title": "Koboldökonomie",
        "year": 2016,
        "desc": "Auswirkungen der irischen Steuerstruktur von Apple"
    },
    {
        "title": "Hurghada-Anschlag 2017",
        "year": 2017,
        "desc": "Details zum Terroranschlag in Hurghada im Jahr 2017"
    },
    {
        "title": "Nationaler Pride-Marsch",
        "year": 2017,
        "desc": "Protestveranstaltung im Juni 2017"
    },
    {
        "title": "Das letzte Experiment (2017; The Final Experiment)",
        "year": 2017,
        "desc": "Antarktisexpedition 2024, um die Gültigkeit des modernen Glaubens an eine flache Erde zu testen"
    },
    {
        "title": "Bombenanschläge auf Sittwe 2018",
        "year": 2018,
        "desc": "Drei Bombenanschläge in Sittwe, Bundesstaat Rakhine, Myanmar"
    },
    {
        "title": "2020 Snowbirds-Absturz",
        "year": 2020,
        "desc": "Unfall der kanadischen Luftwaffe"
    },
    {
        "title": "Tag ohne Kunst 2020",
        "year": 2020,
        "desc": "begann 1989 als Reaktion auf die AIDS-Krise und viele Künstler verloren durch AIDS. Der Tag fällt mit dem Welt-Aids-Tag zusammen"
    },
    {
        "title": "Cyberangriff auf JBS S.A",
        "year": 2021,
        "desc": "Cyberangriff 2021"
    },
    {
        "title": "Moghbazar-Explosion 2021",
        "year": 2021,
        "desc": "Historisches Ereignis aus dem Jahr 2021."
    },
    {
        "title": "2022 Timika-Morde",
        "year": 2022,
        "desc": "Massenmord in West-Papua, Indonesien"
    },
    {
        "title": "Eliyahu Shlomi-Affäre",
        "year": 1940,
        "desc": "1940 gewaltsamer Zusammenstoß in Herzliya, Mandatsgebiet Palästina"
    },
    {
        "title": "Lutetia-Hotel im Jahr 1945",
        "year": 1945,
        "desc": "Historisches Ereignis aus dem Jahr 1945."
    },
    {
        "title": "Hoggs Hollow-Katastrophe",
        "year": 1960,
        "desc": "Historisches Ereignis aus dem Jahr 1960."
    },
    {
        "title": "Jerusalem März 1970",
        "year": 1970,
        "desc": "Historisches Ereignis aus dem Jahr 1970."
    },
    {
        "title": "Tod von Kevin Gately (1974; Death of Kevin Gately)",
        "year": 1974,
        "desc": "Todesopfer bei öffentlicher Demonstration in London"
    },
    {
        "title": "Tod von Helen Bailey",
        "year": 1975,
        "desc": "Der ungelöste Mord an einer achtjährigen Schülerin im Jahr 1975 in Birmingham, England, ist ungeklärt"
    },
    {
        "title": "Gasanstieg in East Boston",
        "year": 1983,
        "desc": "Brandunfall"
    },
    {
        "title": "Kurdischer Exodus (1991)",
        "year": 1991,
        "desc": "Historisches Ereignis aus dem Jahr 1991."
    },
    {
        "title": "1994 Ain Allah-Anschlag",
        "year": 1994,
        "desc": "Militäroffensive während des algerischen Bürgerkriegs 1994"
    },
    {
        "title": "Tragedia de San Román",
        "year": 1995,
        "desc": "Geiselnahme in Venezuela"
    },
    {
        "title": "Grangegorman-Morde",
        "year": 1997,
        "desc": "Mordserie"
    },
    {
        "title": "Beschuss der Madhu-Kirche",
        "year": 1999,
        "desc": "Kirchenmassaker Bürgerkrieg in Sri Lanka"
    },
    {
        "title": "Opa, du bist zurück",
        "year": 2005,
        "desc": "2005 sogar in Xi'an, Shaanxi, China"
    },
    {
        "title": "2008 Jodhpur-Ansturm",
        "year": 2008,
        "desc": "Menschenansturm in Rajasthan, Indien"
    },
    {
        "title": "Katastrophe in der Petrila-Mine",
        "year": 2008,
        "desc": "Kohlengrubenkatastrophe in Rumänien"
    },
    {
        "title": "2009 Makeen-Luftangriff",
        "year": 2009,
        "desc": "2009 Drohnenangriff in Pakistan"
    },
    {
        "title": "Angriff der Mohmand Agency (2010; Mohmand Agency attack)",
        "year": 2010,
        "desc": "Selbstmordanschlag 2010 in Pakistan"
    },
    {
        "title": "Damaturus Gefängnisausbruch",
        "year": 2012,
        "desc": "Vorkommen in Nigeria"
    },
    {
        "title": "Jalpaiguri-Explosion 2013",
        "year": 2013,
        "desc": "Historisches Ereignis aus dem Jahr 2013."
    },
    {
        "title": "Vorfall in Abu Musallam",
        "year": 2013,
        "desc": "Historisches Ereignis aus dem Jahr 2013."
    },
    {
        "title": "Daniel-Galván-Skandal (2013; Daniel Galván scandal)",
        "year": 2013,
        "desc": "Marokkanischer politischer Skandal"
    },
    {
        "title": "Kindermorde in Cairns (2014; Cairns child killings)",
        "year": 2014,
        "desc": "Vorfall in Australien, bei dem acht Kinder aufgrund von Stichwunden tot auf einem Grundstück aufgefunden wurden."
    },
    {
        "title": "Ruhm und Philanthropie",
        "year": 2014,
        "desc": "Wohltätigkeitsveranstaltung 2014 bei den 86. Academy Awards"
    },
    {
        "title": "Reihe von Leichen in Unnao",
        "year": 2015,
        "desc": "Leichen wurden im Ganges gefunden"
    },
    {
        "title": "Baramulla-Angriff 2016",
        "year": 2016,
        "desc": "2016 militanter Angriff in Baramulla, Jammu und Kaschmir, Indien"
    },
    {
        "title": "Bombenanschläge in Bagdad 2017",
        "year": 2017,
        "desc": "Serie von Selbstmordanschlägen auf Autos"
    },
    {
        "title": "Tod von Yassar Yaqub",
        "year": 2017,
        "desc": "2017 Tod in Huddersfield, England"
    },
    {
        "title": "Tod von Vikram Joshi",
        "year": 2020,
        "desc": "Kriminalität im Jahr 2020 in Uttar Pradesh, Indien"
    },
    {
        "title": "Tod von Eric Richins",
        "year": 2022,
        "desc": "Mord im Jahr 2022 in Utah, USA"
    },
    {
        "title": "Bestattungsanschlag in Gondar",
        "year": 2022,
        "desc": "Vorfall im Jahr 2022 in Äthiopien"
    },
    {
        "title": "Tragödie auf der Insel Tiburón (1905; Tiburón Island Tragedy)",
        "year": 1905,
        "desc": "Vermisste Goldsuchexpedition im Jahr 1905"
    },
    {
        "title": "Vorfall in Paris Jangseo",
        "year": 1919,
        "desc": "Ereignis (1919)"
    },
    {
        "title": "Der Tod von Boris III",
        "year": 1943,
        "desc": "Historisches Ereignis aus dem Jahr 1943."
    },
    {
        "title": "Einführung des Bikinis",
        "year": 1946,
        "desc": "historisches Ereignis"
    },
    {
        "title": "UFO-Vorfall in Malmström (1967; Malmstrom UFO incident)",
        "year": 1967,
        "desc": "angebliches paranormales Ereignis"
    },
    {
        "title": "Kampagne im Baliem-Tal",
        "year": 1977,
        "desc": "Reihe von Kampagnen im Baliem-Tal"
    },
    {
        "title": "Autobahnkatastrophe in Nervi",
        "year": 1983,
        "desc": "tödlicher Verkehrsunfall in Italien im Dezember 1983"
    },
    {
        "title": "1990 Vergewaltigungsfall in Bantala",
        "year": 1990,
        "desc": "Vergewaltigungsfall"
    },
    {
        "title": "1992 Stürme in Queensland",
        "year": 1992,
        "desc": "Gewitterserie in Queensland"
    },
    {
        "title": "Carmela Buchbuts Fall",
        "year": 1994,
        "desc": "Vorfall, bei dem eine geschlagene Frau ihren Ehemann tötete"
    },
    {
        "title": "Yeh Yung-chih-Vorfall (2000; Yeh Yung-chih Incident)",
        "year": 2000,
        "desc": "Taiwans Multi-Gender-Themenveranstaltung"
    },
    {
        "title": "Tod von Mark Saunders",
        "year": 2008,
        "desc": "Todesfall im Mai 2008 in London"
    },
    {
        "title": "2009 gabunische Proteste",
        "year": 2009,
        "desc": "Historisches Ereignis aus dem Jahr 2009."
    },
    {
        "title": "Graffiti Rock Jam 2009",
        "year": 2009,
        "desc": "Historisches Ereignis aus dem Jahr 2009."
    },
    {
        "title": "2011 Belagerung von Hectorville",
        "year": 2011,
        "desc": "Veranstaltung in Adelaide, Südaustralien"
    },
    {
        "title": "Tour zur Wiederherstellung des Mutes",
        "year": 2011,
        "desc": "Historisches Ereignis aus dem Jahr 2011."
    },
    {
        "title": "Parachinar-Angriff 2013",
        "year": 2013,
        "desc": "2013 Bombenanschlag in Parachinar, Pakistan"
    },
    {
        "title": "Juni 2017 Medan-Angriff",
        "year": 2017,
        "desc": "Historisches Ereignis aus dem Jahr 2017."
    },
    {
        "title": "Zahro-Express-Katastrophe",
        "year": 2017,
        "desc": "Fährkatastrophe 2017 in Indonesien"
    },
    {
        "title": "Wikidata-Workshop 2018",
        "year": 2018,
        "desc": "Historisches Ereignis aus dem Jahr 2018."
    },
    {
        "title": "Überschwemmung in Afghanistan 2020",
        "year": 2020,
        "desc": "Überschwemmungen in Afghanistan"
    },
    {
        "title": "Tod von Maria Fuertes",
        "year": 2020,
        "desc": "Mord im Jahr 2020 in New York City"
    },
    {
        "title": "La República im Zentrum",
        "year": 2020,
        "desc": "Historisches Ereignis aus dem Jahr 2020."
    },
    {
        "title": "Muerte de Mabel Monroy",
        "year": 2020,
        "desc": "Fallecimiento von Mabel Monroy Fragoso"
    },
    {
        "title": "2021 Banco de Oro-Hack",
        "year": 2021,
        "desc": "Bankbetrug"
    },
    {
        "title": "Tötung von Lily Peters",
        "year": 2022,
        "desc": "2022 Mord an amerikanischem Kind"
    },
    {
        "title": "Tötung von Naomi Irion",
        "year": 2022,
        "desc": "2022 Mord durch Schießerei in Fernley, Nevada, USA"
    },
    {
        "title": "Tötung von Saw Tun Moe",
        "year": 2022,
        "desc": "2022 Tötung in Myanmar"
    },
    {
        "title": "Kuichou meldet eine Katastrophe (1913; Kuichou report disaster)",
        "year": 1913,
        "desc": "1913 Katastrophe in China"
    },
    {
        "title": "Babe Ruth ist die richtige Wahl",
        "year": 1932,
        "desc": "Homerun-Hit von Babe Ruth in der World Series 1932, den Ruth angeblich vorhergesagt hatte"
    },
    {
        "title": "Tod von Elza Fernandes",
        "year": 1936,
        "desc": "Historisches Ereignis aus dem Jahr 1936."
    },
    {
        "title": "Befreiung von Ljubljana",
        "year": 1945,
        "desc": "Historisches Ereignis aus dem Jahr 1945."
    },
    {
        "title": "Rengasdengklok-Vorfall",
        "year": 1945,
        "desc": "1945 indonesische Entführung"
    },
    {
        "title": "1975 Jubiläumsweihe",
        "year": 1975,
        "desc": "1975 religiöses Ritual in der Vatikanstadt"
    },
    {
        "title": "Kumudini tekne katliamı",
        "year": 1985,
        "desc": "15. Mai 1985, Geburtsort"
    },
    {
        "title": "1989 De Meer Nagelbomben",
        "year": 1989,
        "desc": "Fußball-Hooligan-Vorfall in den Niederlanden"
    },
    {
        "title": "1992 Bombenanschlag auf Manchester",
        "year": 1992,
        "desc": "Angriff der Provisorischen Irischen Republikanischen Armee am 3. Dezember 1992 mit zwei Bomben, bei dem 64 Menschen verletzt und mehrere Gebäude in Manchester, England, beschädigt wurden"
    },
    {
        "title": "1993 Panzer-Amoklauf in Perth",
        "year": 1993,
        "desc": "1993 Panzer-Amoklauf"
    },
    {
        "title": "Vorkommen des Bazhang-Flusses",
        "year": 2000,
        "desc": "2000-Katastrophe in Taiwan"
    },
    {
        "title": "Murwillumbah-Sumpfbier (2001; Murwillumbah Swamp Beer)",
        "year": 2001,
        "desc": "ein Ereignis im Jahr 2001 in Murwillumbah, New South Wales, bei dem 40.000 Flaschen Bier in den Tweed River fielen"
    },
    {
        "title": "Vorfall in der Nong'an-Straße",
        "year": 2004,
        "desc": "Vorfall in Taiwan im Jahr 2004"
    },
    {
        "title": "Esfondrament del Carmel",
        "year": 2005,
        "desc": "Historisches Ereignis aus dem Jahr 2005."
    },
    {
        "title": "Bombenanschläge in Mogadischu 2008",
        "year": 2008,
        "desc": "Am 3. August 2008 tötete eine Bombe am Straßenrand 21 Frauen und verletzte weitere 46 Menschen"
    },
    {
        "title": "Tötung von Kevin McDaid",
        "year": 2009,
        "desc": "Britisches Mordopfer"
    },
    {
        "title": "2010 Jama Masjid-Angriff",
        "year": 2010,
        "desc": "Islamischer Angriff in Delhi, Indien"
    },
    {
        "title": "2012 LKW-Unfall in Riad",
        "year": 2012,
        "desc": "Unfall und Explosion eines Tankwagens"
    },
    {
        "title": "2012 Ansturm auf Pingo Doce",
        "year": 2012,
        "desc": "Historisches Ereignis aus dem Jahr 2012."
    },
    {
        "title": "Alexis Murphy-Entführung",
        "year": 2013,
        "desc": "Mordfall"
    },
    {
        "title": "Tragödie am Beas River 2014",
        "year": 2014,
        "desc": "2014 Massenertrinken in Himachal Pradesh, Indien"
    },
    {
        "title": "Gujranwala-Anschläge 2014",
        "year": 2014,
        "desc": "Historisches Ereignis aus dem Jahr 2014."
    },
    {
        "title": "Slavnosti tří kápí 2015",
        "year": 2015,
        "desc": "Historisches Ereignis aus dem Jahr 2015."
    },
    {
        "title": "Vorfall in Reed Bank 2019",
        "year": 2019,
        "desc": "Rammen eines chinesischen Schiffes auf ein philippinisches Fischerboot, das zum Untergang führte"
    },
    {
        "title": "Ermordung von Ahmad Erekat",
        "year": 2020,
        "desc": "2020 Tötung im israelisch-palästinensischen Konflikt"
    },
    {
        "title": "Verbot von Quim Torra",
        "year": 2020,
        "desc": "Historisches Ereignis aus dem Jahr 2020."
    },
    {
        "title": "Salvatierra-Massengräber",
        "year": 2020,
        "desc": "Historisches Ereignis aus dem Jahr 2020."
    },
    {
        "title": "2021 Antilla-Bombenangst",
        "year": 2021,
        "desc": "Bombenangst 2021 in Mumbai"
    },
    {
        "title": "Explosion in Masbate City 2021",
        "year": 2021,
        "desc": "2021 Morde in Masbate City, Philippinen"
    },
    {
        "title": "Assuan-Skorpion-Invasion",
        "year": 2021,
        "desc": "Skorpioninvasion 2021 in Assuan, Ägypten"
    },
    {
        "title": "Coatepec Harinas-Angriff",
        "year": 2021,
        "desc": "Hinterhalt gegen Polizeikräfte in Coatepec Harinas, Mexiko"
    },
    {
        "title": "Luftangriffe auf die Wehda-Straße (2021; Wehda Street airstrikes)",
        "year": 2021,
        "desc": "Vorfall während der israelisch-palästinensischen Krise 2021"
    },
    {
        "title": "Große Musi-Flut von 1908",
        "year": 1908,
        "desc": "1908 Naturkatastrophe in Indien"
    },
    {
        "title": "Ukrainisches Todesdreieck (1919; Ukrainian Death Triangle)",
        "year": 1919,
        "desc": "Militärische Situation in der Ukraine am Ende des Ersten Weltkriegs"
    },
    {
        "title": "Doppelte Sieben-Tage-Rauferei",
        "year": 1963,
        "desc": "1963 Auseinandersetzung zwischen Polizei und Journalisten in Saigon, Südvietnam"
    },
    {
        "title": "1968 Aufstand im Senegal",
        "year": 1968,
        "desc": "1968 Protest im Senegal"
    },
    {
        "title": "Vorfall mit Hund von Mitt Romney",
        "year": 1983,
        "desc": "Vorfall mit Hund"
    },
    {
        "title": "Morde an der Familie Dardeen (1987; Dardeen family homicides)",
        "year": 1987,
        "desc": "Ungelöste Familienmorde"
    },
    {
        "title": "Nacht der langen Messer (1992; Night of the Long Knives)",
        "year": 1992,
        "desc": "1992 IRA-Aktion in Belfast"
    },
    {
        "title": "Massengrab Mrkonjić Grad (1995; Mrkonjić Grad mass grave)",
        "year": 1995,
        "desc": "Gräueltat im Bosnienkrieg"
    },
    {
        "title": "2001 Trooping the Colour",
        "year": 2001,
        "desc": "Parade zum offiziellen Geburtstag der Königin"
    },
    {
        "title": "Tod von Melinda Duckett",
        "year": 2006,
        "desc": "Mutter des vermissten Kleinkindes Trenton Duckett"
    },
    {
        "title": "Renationalisierung von YPF",
        "year": 2012,
        "desc": "Gesetz von Cristina Fernández de Kirchner im Jahr 2012"
    },
    {
        "title": "2013 maoistischer Angriff in Bihar",
        "year": 2013,
        "desc": "Historisches Ereignis aus dem Jahr 2013."
    },
    {
        "title": "Juni 2013 Quetta-Angriffe",
        "year": 2013,
        "desc": "Bombenanschlagsserie in Quetta, Pakistan"
    },
    {
        "title": "Kindesmissbrauchsfall Ayeesha",
        "year": 2015,
        "desc": "Historisches Ereignis aus dem Jahr 2015."
    },
    {
        "title": "August 2016 Anschlag in Kabul",
        "year": 2016,
        "desc": "Historisches Ereignis aus dem Jahr 2016."
    },
    {
        "title": "Krise am Oroville-Staudamm 2017",
        "year": 2017,
        "desc": "Staudammkrise"
    },
    {
        "title": "2017 Umm al-Hiran-Angriff",
        "year": 2017,
        "desc": "Tötung eines israelischen Arabers durch israelische Polizei"
    },
    {
        "title": "Boston-Kundgebung zur freien Meinungsäußerung",
        "year": 2017,
        "desc": "Kundgebung in Boston im Jahr 2017"
    },
    {
        "title": "Der Fall von Lara Alqasem",
        "year": 2018,
        "desc": "Historisches Ereignis aus dem Jahr 2018."
    },
    {
        "title": "Einfärben des Posters von Xi Jinping",
        "year": 2018,
        "desc": "Politische Ereignisse, die 2018 auf den Generalsekretär der Kommunistischen Partei Chinas, Xi Jinping, abzielten"
    },
    {
        "title": "Busanschlag in Äthiopien 2020",
        "year": 2020,
        "desc": "Massenerschießungen in Äthiopien"
    },
    {
        "title": "Tod von Michael Hickson",
        "year": 2020,
        "desc": "Medizinische Kontroverse 2020 in Austin, Texas"
    },
    {
        "title": "Ermordung von Angelo Quinto",
        "year": 2020,
        "desc": "Mord im Jahr 2020 in Antioch, Kalifornien, USA"
    },
    {
        "title": "Tötung von Casey Goodson",
        "year": 2020,
        "desc": "Polizeischießerei 2020 in Columbus, Ohio"
    },
    {
        "title": "Anschläge in Afghanistan 2021",
        "year": 2021,
        "desc": "Liste der Anschläge im Jahr 2021 in Afghanistan"
    },
    {
        "title": "Tötung von Lindani Myeni",
        "year": 2021,
        "desc": "2021 Ermordung eines Schwarzen durch Polizeibeamte aus Honolulu"
    },
    {
        "title": "Gruppenvergewaltigung in Hyderabad 2022",
        "year": 2022,
        "desc": "Gruppenvergewaltigung eines 17-jährigen Mädchens in Jubilee Hills, Hyderabad"
    },
    {
        "title": "Ermordung von Nahid Hossain",
        "year": 2022,
        "desc": "Mord im Jahr 2022 in Dhaka, Bangladesch"
    },
    {
        "title": "2003 Brandstiftung in Columbus, Ohio",
        "year": 2003,
        "desc": "2003 Brandstiftung in Ohio"
    },
    {
        "title": "Prügel gegen Frank Jude Jr.",
        "year": 2004,
        "desc": "Vorfall mit Polizeibrutalität im Jahr 2004 in Milwaukee, Wisconsin"
    },
    {
        "title": "26. Generalversammlung der IAU",
        "year": 2006,
        "desc": "Historisches Ereignis aus dem Jahr 2006."
    },
    {
        "title": "Anschlagsplan von Fort Dix 2007",
        "year": 2007,
        "desc": "Verschwörung von sechs muslimischen Männern zum Angriff auf US-Militärangehörige in Fort Dix, New Jersey, USA"
    },
    {
        "title": "Verschwinden von Nannup Four",
        "year": 2007,
        "desc": "2007 Verschwinden von vier Menschen in Australien"
    },
    {
        "title": "Joseph und Melissa Batten",
        "year": 2008,
        "desc": "Mord-Selbstmord in Redmond, Washington, USA"
    },
    {
        "title": "2010 Südostasiatischer Dunst",
        "year": 2010,
        "desc": "Dunst über der Region Südostasien Mitte 2010"
    },
    {
        "title": "2011 Schießerei im Mastung-Bus",
        "year": 2011,
        "desc": "Massenmord im 21. Jahrhundert in Pakistan"
    },
    {
        "title": "Überfall auf Carlton Cannes 2013",
        "year": 2013,
        "desc": "Bewaffneter Raubüberfall an der französischen Riviera"
    },
    {
        "title": "Messerangriff auf Kevin Lau",
        "year": 2014,
        "desc": "2014 Messerangriff in Hongkong"
    },
    {
        "title": "Brandanschlag im Dorf Duma (2015; Duma village arson attack)",
        "year": 2015,
        "desc": "Brandanschlag auf ein palästinensisches Haus im Jahr 2015"
    },
    {
        "title": "Belagerung des Kidapawan-Gefängnisses 2017",
        "year": 2017,
        "desc": "Vorkommnis 2017"
    },
    {
        "title": "Tod von Chaiyaphum Pasae",
        "year": 2017,
        "desc": "Historisches Ereignis aus dem Jahr 2017."
    },
    {
        "title": "Januar 2017 Azaz-Bombenanschlag",
        "year": 2017,
        "desc": "Selbstmordanschlag während des syrischen Bürgerkriegs"
    },
    {
        "title": "Schuldenkrise im Landkreis Dushan",
        "year": 2018,
        "desc": "Historisches Ereignis aus dem Jahr 2018."
    },
    {
        "title": "Wikipedia:Treffen/Melaka 1",
        "year": 2018,
        "desc": "Wikipedia Melaka Meetup 1"
    },
    {
        "title": "Flugverbot für Boeing 737 MAX",
        "year": 2019,
        "desc": "Flugverbot für Boeing 737 MAX aus Sicherheitsgründen, nachdem innerhalb von fünf Monaten zwei neue Flugzeuge abgestürzt waren"
    },
    {
        "title": "Boykotte von Facebook-Anzeigen im Jahr 2020",
        "year": 2020,
        "desc": "Boykottgruppe im Juli 2020"
    },
    {
        "title": "Ermordung von Christian Hall",
        "year": 2020,
        "desc": "Tötung eines asiatisch-amerikanischen Mannes durch die Polizei im Jahr 2021"
    },
    {
        "title": "Ermordung von Kaylea Titford",
        "year": 2020,
        "desc": "2020 Tod in Wales"
    },
    {
        "title": "Vorfälle in Kilmarnock 2021",
        "year": 2021,
        "desc": "Ähnliche Messerstechereien in Kilmarnock, Schottland im Februar 2021"
    },
    {
        "title": "Tod von Christine Dacera (2021; death of Christine Dacera)",
        "year": 2021,
        "desc": "Vorfall 2021 auf den Philippinen"
    },
    {
        "title": "Autounfall im Imperial County",
        "year": 2021,
        "desc": "Unfall 2021 in Südkalifornien, bei dem 13 Menschen ums Leben kamen"
    },
    {
        "title": "Medininikai-Vorfall 2021",
        "year": 2021,
        "desc": "Historisches Ereignis aus dem Jahr 2021."
    },
    {
        "title": "Börsenrückgang 2022",
        "year": 2022,
        "desc": "weltweites Wirtschaftsereignis"
    },
    {
        "title": "Tötung von Cassius Turvey",
        "year": 2022,
        "desc": "Tod in Perth, Westaustralien im Jahr 2022"
    },
    {
        "title": "Ermordung von Earl Moore Jr.",
        "year": 2022,
        "desc": "2022 Tötung eines Mannes durch Sanitäter in Springfield, Illinois"
    },
    {
        "title": "Tötung von Jared Bridegan",
        "year": 2022,
        "desc": "Mord im Jahr 2022 in Jacksonville Beach, Florida"
    },
    {
        "title": "Mai 2022 Bakura-Massaker",
        "year": 2022,
        "desc": "2022 Massaker an Zivilisten in Nigeria"
    },
    {
        "title": "Angriffe von Skye und Lochalsh",
        "year": 2022,
        "desc": "2022 Schießereien und Messerstechereien in Skye und Lochalsh"
    },
    {
        "title": "Massengräber auf der Insel Balalae",
        "year": 1943,
        "desc": "1943 Massaker an Kriegsgefangenen durch Japan"
    },
    {
        "title": "Auflösung von Osa-Kosa 30",
        "year": 1943,
        "desc": "Juni 1943 Verhaftung der polnischen Osa–Kosa 30 durch die Gestapo"
    },
    {
        "title": "Tod von June Anne Devaney (1948; Death of June Anne Devaney)",
        "year": 1948,
        "desc": "1948 Kindermord in London, England"
    },
    {
        "title": "Cruzeiro do Sul Flug 114",
        "year": 1970,
        "desc": "1970 Flugzeugentführung"
    },
    {
        "title": "Erster NYC Pride März 1970",
        "year": 1970,
        "desc": "erste New York City Pride-Parade"
    },
    {
        "title": "Cruzeiro do Sul Flug 302",
        "year": 1984,
        "desc": "1984 Flugzeugentführung"
    },
    {
        "title": "Rassistischer Angriff in Howard Beach",
        "year": 1986,
        "desc": "1986 rassistisch motivierter Mord in Queens, New York, USA"
    },
    {
        "title": "Verschwinden von Troy Cook",
        "year": 1998,
        "desc": "1998 in Truro, Nova Scotia vermisst."
    },
    {
        "title": "2003 Bombenanschlag auf die Quetta-Moschee",
        "year": 2003,
        "desc": "Terroranschlag in Quetta, Pakistan"
    },
    {
        "title": "Februar 2010 Anschlag in Kabul",
        "year": 2010,
        "desc": "Selbstmordanschläge und Schießereien in Kabul"
    },
    {
        "title": "Aufenthaltsort der älteren Menschen",
        "year": 2010,
        "desc": "Soziales Problem, das in Japan seit 2010 aufgetreten ist, als festgestellt wurde, dass eine große Anzahl älterer Menschen in offiziellen Familienregistern aufgeführt ist, deren tatsächliches Geburtsdatum, Sterbedatum oder Wohnort jedoch nicht bestätigt werden konnte"
    },
    {
        "title": "Drogentote in Amsterdam 2014",
        "year": 2014,
        "desc": "Todesfälle britischer Touristen in den Niederlanden"
    },
    {
        "title": "Angriff auf den Larkana-Tempel 2014",
        "year": 2014,
        "desc": "Angriffe auf einen Hindu-Tempel in Larkana, Pakistan"
    },
    {
        "title": "Juni 2017: Anschlag in Melbourne",
        "year": 2017,
        "desc": "Terror-Geiselnahme 2017 in Melbourne, Australien"
    },
    {
        "title": "Mord an Pradyuman Thakur",
        "year": 2017,
        "desc": "Mordfall in Indien"
    }
];
