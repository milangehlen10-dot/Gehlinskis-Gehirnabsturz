window.eventDatabase = [
    {
        "title": "Entdeckung Amerikas",
        "year": 1492,
        "desc": "Christoph Kolumbus erreicht die Karibik im Auftrag der spanischen Krone."
    },
    {
        "title": "Bau der Pyramiden von Gizeh",
        "year": -2560,
        "desc": "Die Großen Pyramiden werden für Pharao Cheops errichtet."
    },
    {
        "title": "Untergang des Römischen Reichs",
        "year": 476,
        "desc": "Das Weströmische Reich endet mit dem Sturz von Romulus Augustulus."
    },
    {
        "title": "Erfindung des Buchdrucks",
        "year": 1440,
        "desc": "Johannes Gutenberg revolutioniert die Massenproduktion von Büchern."
    },
    {
        "title": "Geburt von Leonardo da Vinci",
        "year": 1452,
        "desc": "Der Maler, Erfinder und Universalgelehrte wird geboren."
    },
    {
        "title": "Geburt von Wolfgang Mozart",
        "year": 1756,
        "desc": "Das Wunderkind der Musik kommt auf die Welt."
    },
    {
        "title": "Geburt von Charles Darwin",
        "year": 1809,
        "desc": "Der Naturforscher und Begründer der Evolutionstheorie wird geboren."
    },
    {
        "title": "Einführung des iPhones",
        "year": 2007,
        "desc": "Apple stellt das erste iPhone vor und verändert die Mobilfunkwelt."
    },
    {
        "title": "Geburt von Marie Curie",
        "year": 1867,
        "desc": "Die Physikerin und Nobelpreisträgerin wird geboren."
    },
    {
        "title": "Geburt von Albert Einstein",
        "year": 1879,
        "desc": "Der Physiker mit den größten wissenschaftlichen Ideen wird geboren."
    },
    {
        "title": "Geburt von Greta Thunberg",
        "year": 2003,
        "desc": "Die Klimaaktivistin wird geboren."
    },
    {
        "title": "Geburt von Emma Watson",
        "year": 1990,
        "desc": "Die Schauspielerin und Aktivistin wird geboren."
    },
    {
        "title": "Schmuggel von Seidenraupeneiern ins Byzantinisches Reich",
        "year": 552,
        "desc": "historische Industrie- bzw. Wirtschaftsspionage in der Spätantike"
    },
    {
        "title": "Ghaiba",
        "year": 813,
        "desc": "Verborgenheit im schiitischen Islam"
    },
    {
        "title": "Niu-Li-Fraktionskämpfe",
        "year": 900,
        "desc": "Auseinandersetzung in der Tang-Dynastie"
    },
    {
        "title": "Plünderung von St. Davids durch die Wikinger",
        "year": 933,
        "desc": "historisches Ereignis in Wales"
    },
    {
        "title": "Dichterprozess auf der Terrasse der Krähen",
        "year": 1079,
        "desc": "Hochverratsprozess gegen Su Shi und andere"
    },
    {
        "title": "Fragmentierung der Kiewer Rus",
        "year": 1200,
        "desc": "Die Kiewer Rus zerfiel in mehrere eigenständige Fürstentümer."
    },
    {
        "title": "Quaden Maendach",
        "year": 1345,
        "desc": "Konflikt in Gent"
    },
    {
        "title": "Kolumbus kehrt nach La Navidad zurück",
        "year": 1493,
        "desc": "Kolumbus kehrt zurück und findet La Navidad zerstört vor"
    },
    {
        "title": "Der Wandschreibvorfall am Yangjae-Bahnhof",
        "year": 1547,
        "desc": "Politische Säuberung in Korea (Joseon)"
    },
    {
        "title": "Magdeburger Bekenntnis",
        "year": 1550,
        "desc": "Lutherisches Glaubensbekenntnis"
    },
    {
        "title": "Vorübergehende schwedische Zölle im Öresund",
        "year": 1565,
        "desc": "Episode im Siebenjährigen Krieg"
    },
    {
        "title": "Geonjeo-Problem",
        "year": 1591,
        "desc": "politischer Vorfall in der Geschichte von Joseon"
    },
    {
        "title": "Åbo Blutbad",
        "year": 1599,
        "desc": "öffentliche Hinrichtung in Turku (Åbo), Finnland"
    },
    {
        "title": "Eine private Unterhaltung des Königs und der Königin",
        "year": 1604,
        "desc": "Höfisches Maskenspiel von Ben Jonson"
    },
    {
        "title": "Die Besessenen von Aix-en-Provence",
        "year": 1611,
        "desc": "Reihe mutmaßlicher Fälle dämonischer Besessenheit in Aix-en-Provence"
    },
    {
        "title": "Einnahme von Salvador",
        "year": 1624,
        "desc": "militärischer Konflikt"
    },
    {
        "title": "Rückeroberung Salvadors",
        "year": 1625,
        "desc": "Schlacht des Achtzigjährigen Krieges"
    },
    {
        "title": "Übergabe von Quebec",
        "year": 1628,
        "desc": "die Einnahme von Quebec (ohne Kampf) durch englische Freibeuter unter der Führung von David Kirke während des Dreißigjährigen Krieges"
    },
    {
        "title": "Belagerung von Salvador",
        "year": 1638,
        "desc": "holländische Belagerung von Salvador, Bahia"
    },
    {
        "title": "Das große Gewitter",
        "year": 1638,
        "desc": "Wetterereignis in Dartmoor, England"
    },
    {
        "title": "Plünderungszeit",
        "year": 1644,
        "desc": "Zeit der Gesetzlosigkeit im kolonialen Maryland"
    },
    {
        "title": "Westliche Protestanz",
        "year": 1650,
        "desc": "Schottisches historisches Ereignis"
    },
    {
        "title": "Krönung Karls II. von England",
        "year": 1661,
        "desc": "Veranstaltung am, Westminster Abbey"
    },
    {
        "title": "Toller Auswurf",
        "year": 1662,
        "desc": "folgte dem Act of Uniformity in England"
    },
    {
        "title": "Gisa Hwanguk",
        "year": 1689,
        "desc": "Politische Säuberung in Korea"
    },
    {
        "title": "zweite Südreise des Kaisers Kangxi",
        "year": 1689,
        "desc": "Inspektionstour durch Kaiser Kangxi"
    },
    {
        "title": "Musin-Aufstand",
        "year": 1728,
        "desc": "Aufstand in Korea"
    },
    {
        "title": "Mitternachtsritt von Paul Revere",
        "year": 1755,
        "desc": "Alarmierung der amerikanischen Kolonialmiliz"
    },
    {
        "title": "Vertreibung der Jesuiten aus Portugal",
        "year": 1759,
        "desc": "Veranstaltung, die in Portugal stattfand"
    },
    {
        "title": "Wunder des Hauses Brandenburg",
        "year": 1762,
        "desc": "Ereignis während des Siebenjährigen Krieges"
    },
    {
        "title": "Vertreibung der Jesuiten aus Frankreich",
        "year": 1763,
        "desc": "Ereignis, das in Frankreich stattfand"
    },
    {
        "title": "Friedensfest in Jena",
        "year": 1763,
        "desc": "Friedensfest am aus Anlass des Hubertusburger Friedens"
    },
    {
        "title": "Vertreibung der Jesuiten aus Spanien",
        "year": 1767,
        "desc": "Veranstaltung, die in Spanien stattfand"
    },
    {
        "title": "Belagerung von Warwick Lane",
        "year": 1767,
        "desc": "Protestveranstaltung in London."
    },
    {
        "title": "Gründung der ersten jüdischen Gemeinde in Wales",
        "year": 1768,
        "desc": "Gründung einer jüdischen Gemeinde in Swansea"
    },
    {
        "title": "Gefangennahme und Rettung von Jemima Boone",
        "year": 1776,
        "desc": "Vorfall in der Kolonialgeschichte von Kentucky"
    },
    {
        "title": "McCollochs Sprung",
        "year": 1777,
        "desc": "Ein berittener US-Kavallerist springt von einer Klippe und überlebt"
    },
    {
        "title": "George Washingtons Abschied von seinen Offizieren",
        "year": 1783,
        "desc": "historisches Ereignis am Ende des Amerikanischen Unabhängigkeitskrieges"
    },
    {
        "title": "Rücktritt von George Washington als Oberbefehlshaber",
        "year": 1783,
        "desc": "George Washington tritt als Oberbefehlshaber der Kontinentalarmee zurück"
    },
    {
        "title": "Empfang von George Washington in Trenton",
        "year": 1789,
        "desc": "Empfang des designierten Präsidenten George Washington in Trenton, New Jersey"
    },
    {
        "title": "Erster europäischer Astronomenkongress",
        "year": 1798,
        "desc": "Astronomiekonferenz in Gotha, Deutschland"
    },
    {
        "title": "Fries-Aufstand",
        "year": 1799,
        "desc": "Steueraufstand von Bauern in Pennsylvania gegen die staatliche Steuererhebung."
    },
    {
        "title": "Stadtbrand von Linz",
        "year": 1800,
        "desc": "Marke in der oberösterreichischen Landeshauptstadt Linz"
    },
    {
        "title": "Marke im Stift Melk",
        "year": 1805,
        "desc": "Brandkatastrophe"
    },
    {
        "title": "Jujuy-Exodus",
        "year": 1812,
        "desc": "die massive Evakuierung von Menschen aus der argentinischen Provinz Jujuy während des argentinischen Unabhängigkeitskrieges"
    },
    {
        "title": "Schlägerei zwischen Jackson und Benton",
        "year": 1813,
        "desc": "Amerikanischer Waffen- und Messerkampf"
    },
    {
        "title": "Drei-Monarchen-Treffen",
        "year": 1813,
        "desc": "Treffen am in Dornheim in Thüringen"
    },
    {
        "title": "Landung des Prinzen",
        "year": 1813,
        "desc": "Rückkehr von Prinz William in die Niederlande"
    },
    {
        "title": "Erste Schlacht von Talca",
        "year": 1814,
        "desc": "battle occured in the chilean war of independence"
    },
    {
        "title": "Mikhail Lermontov in Chechnya",
        "year": 1818,
        "desc": "drei Episoden der Biographie des Dichters"
    },
    {
        "title": "Clay–Randolph duel",
        "year": 1826,
        "desc": "pistol duel in Virginia, US"
    },
    {
        "title": "Aufstand irischer und deutscher Söldner",
        "year": 1828,
        "desc": "Militäraufstand in Brasilien durch irische und deutsche Söldner"
    },
    {
        "title": "Aufstand der Conic Sections",
        "year": 1830,
        "desc": "Bildungsveranstaltung gegen Prüfungspolitik"
    },
    {
        "title": "Göttinger Revolution",
        "year": 1831,
        "desc": "Konflikt in Göttingen, ausgelöst durch politische Umwälzungen in Frankreich."
    },
    {
        "title": "Hofdamenaffäre",
        "year": 1839,
        "desc": "Britische Regierungskrise"
    },
    {
        "title": "Vorfall auf dem Gebiet der Cockstock",
        "year": 1844,
        "desc": "Historische Auseinandersetzung im Gebiet des heutigen Oregon."
    },
    {
        "title": "Leipziger Gemetzel",
        "year": 1845,
        "desc": "Konflikt während eines Besuchs des sächsischen Prinzen Johann in Leipzig."
    },
    {
        "title": "Neuenburger Revolution",
        "year": 1848,
        "desc": "Volkserhebung gegen König Friedrich Wilhelm IV. von Preußen."
    },
    {
        "title": "Wiederherstellung der katholischen Hierarchie in England",
        "year": 1850,
        "desc": "Wiedererrichtung des römisch-katholischen Diözesansystems für England und Wales"
    },
    {
        "title": "Hungersnot der Firma Obleukhov",
        "year": 1856,
        "desc": "Hungersnot während der russischen Kolonisierung von Amur"
    },
    {
        "title": "Viehtötung der Xhosa",
        "year": 1857,
        "desc": "Krisenkult der Xhosa"
    },
    {
        "title": "Großer Meteor",
        "year": 1860,
        "desc": "Meteoritenprozession, die die Erde streift und in den gesamten Vereinigten Staaten beobachtet wird"
    },
    {
        "title": "Aufstand von Jinju",
        "year": 1862,
        "desc": "Aufstand gegen die Herrschaft der Joseon-Dynastie in Korea."
    },
    {
        "title": "Bauernaufstand von Iksan",
        "year": 1862,
        "desc": "Aufstand in Korea."
    },
    {
        "title": "Evakuierung der Festung Fredericia",
        "year": 1864,
        "desc": "Ereignis im Deutsch-Dänischen Krieg"
    },
    {
        "title": "Übergang über die Schlei",
        "year": 1864,
        "desc": "erfolgreiche Umgehung des Danewerks am im Rahmen des Deutsch-Dänischen Krieges"
    },
    {
        "title": "Fort Smith Council",
        "year": 1865,
        "desc": "Treffen zwischen der US-Regierung und Indianerstämmen"
    },
    {
        "title": "Die ersten walisischen Siedler segeln auf der Mimosa nach Patagonien",
        "year": 1865,
        "desc": "Kolonisationsereignis"
    },
    {
        "title": "Northwestern Sanitary Fair",
        "year": 1865,
        "desc": "Spendenaktion der United States Sanitary Commission (USSC) in Chicago, Illinois"
    },
    {
        "title": "Andrew Johnson's drunken vice-presidential inaugural address",
        "year": 1865,
        "desc": "in Washington, D.C"
    },
    {
        "title": "Ruf von Yara",
        "year": 1868,
        "desc": "Beginn des Unabhängigkeitskampfes Kubas"
    },
    {
        "title": "Durbar",
        "year": 1870,
        "desc": "Regierungsveranstaltung in Britisch-Indien"
    },
    {
        "title": "Bonnet Carré Crevasse",
        "year": 1871,
        "desc": "Deichversagen am Mississippi und damit verbundene Überschwemmung"
    },
    {
        "title": "Aufstand der Muckers",
        "year": 1874,
        "desc": "Konflikt zwischen zwei Gruppen in Südbrasilien."
    },
    {
        "title": "Louis-Mailloux-Affäre",
        "year": 1875,
        "desc": "violent events in New Brunswick, Canada"
    },
    {
        "title": "Dumojin-Haekwan-Vorfall",
        "year": 1878,
        "desc": "Zusammenstoß zwischen koreanischen und japanischen Kaufleuten in Busan"
    },
    {
        "title": "Vertreibung der Jesuiten aus Frankreich (Ereignis, das in Frankreich stattfand)",
        "year": 1880,
        "desc": "Ereignis, das in Frankreich stattfand"
    },
    {
        "title": "Die Weltreise von König Kalākaua",
        "year": 1881,
        "desc": "Tour durch König Kalākaua vom hawaiianischen Königreich"
    },
    {
        "title": "Rachefeldzug der Earps",
        "year": 1882,
        "desc": "Suche des stellvertretenden US-Marschalls Wyatt Earp nach Outlaw Cowboys"
    },
    {
        "title": "Most-Grottkau-Debatte",
        "year": 1884,
        "desc": "politische Debatte"
    },
    {
        "title": "Vorstadtkatastrophe",
        "year": 1887,
        "desc": "Ein Ereignis, bei dem das Ufer des Zugersees einstürzte und einen Großteil der Zuger Vororte ins Wasser des Zugersees spülte"
    },
    {
        "title": "Badeunfall am Seebad Reinickendorf",
        "year": 1888,
        "desc": "Ereignis in Reinickendorf"
    },
    {
        "title": "Schlacht von Cimarron",
        "year": 1889,
        "desc": "Schießerei in Gray County, Kansas, USA"
    },
    {
        "title": "Verschüttung in den Granatenbergen in Reinickendorf",
        "year": 1890,
        "desc": "Ereignis in Reinickendorf"
    },
    {
        "title": "Vorfall mit dem Vampir Mercy Brown",
        "year": 1892,
        "desc": "Veranstaltung in Rhode Island, USA"
    },
    {
        "title": "Verunglückung eines Passanten auf der Baustelle in der Gesellschaftstraße",
        "year": 1892,
        "desc": "Ereignis in Reinickendorf"
    },
    {
        "title": "Yaqui-Aufstand",
        "year": 1896,
        "desc": "bewaffneter Konflikt in Sonora und Arizona"
    },
    {
        "title": "Angriff gegen Porfirio Díaz",
        "year": 1897,
        "desc": "Versuch, den mexikanischen Präsidenten zu töten"
    },
    {
        "title": "Untergang der SS La Bourgogne",
        "year": 1898,
        "desc": "maritime disaster"
    },
    {
        "title": "Schrei von Santa Barbara",
        "year": 1898,
        "desc": "Ereignis während der philippinischen Revolution"
    },
    {
        "title": "Hot Springs Gunfight",
        "year": 1899,
        "desc": "gunfight in Arkansas, United States"
    },
    {
        "title": "Vorfall am Padre Canyon",
        "year": 1899,
        "desc": "Scharmützel zwischen Navajo-Jägern und Gesetzeshütern aus Arizona"
    },
    {
        "title": "Sturz des faschistischen Regimes in Italien",
        "year": 1943,
        "desc": "Absetzung des italienischen Ministerpräsidenten Benito Mussolini."
    },
    {
        "title": "Tintenflagge",
        "year": 1949,
        "desc": "improvisierte Flagge Israels im Palästinakrieg und Medienikone"
    },
    {
        "title": "Sonnenwunder",
        "year": 1917,
        "desc": "Wunder und Marienerscheinung in Portugal"
    },
    {
        "title": "Rückzug der Regierung der Republik China nach Taiwan",
        "year": 1949,
        "desc": "Rückzug der Republik China vom chinesischen Festland auf die Insel Taiwan"
    },
    {
        "title": "Zweite Revolution",
        "year": 1913,
        "desc": "Aufstand der südlichen Provinzen"
    },
    {
        "title": "Tod und Staatsbegräbnis von Mustafa Kemal Atatürk",
        "year": 1938,
        "desc": "Präsidentenbegräbnis in der Türkei"
    },
    {
        "title": "Ohrfeigen von George S. Patton",
        "year": 1943,
        "desc": "Fälle von Ohrfeigen"
    },
    {
        "title": "Miss-Stone-Affäre",
        "year": 1901,
        "desc": "die Entführung von Ellen Maria Stone und Katerina Cilko durch die Interne Mazedonische Revolutionäre Organisation"
    },
    {
        "title": "Acre-Gefängnisausbruch",
        "year": 1947,
        "desc": "Gefängnisausbruch in Palästina"
    },
    {
        "title": "Frauensonntag",
        "year": 1908,
        "desc": "Suffragetten-Massendemonstration, London"
    },
    {
        "title": "höchste auf der Erde gemessene Temperatur",
        "year": 1913,
        "desc": "die weltweit höchste jemals gemessene Temperatur"
    },
    {
        "title": "NKWD-Befehl Nr. 5",
        "year": 1937,
        "desc": "Sowjetische ethnische Säuberungsaktion gegen Polen."
    },
    {
        "title": "Internationale Ärztekommission von Katyn",
        "year": 1943,
        "desc": "Gruppe von Medizinern"
    },
    {
        "title": "Staatskrise in Ägypten",
        "year": 1942,
        "desc": "Gescheiterter britischer Putschversuch in Ägypten."
    },
    {
        "title": "Große Volksversammlung der Serben, Bunjevci und anderen Slawen im Banat, Bačka und Baranja......",
        "year": 1918,
        "desc": "eine Versammlung in Novi Sad"
    },
    {
        "title": "Große Meteorprozession",
        "year": 1913,
        "desc": "Himmelserscheinung, die in weiten Teilen der Welt beobachtet wurde."
    },
    {
        "title": "Menemen-Ereignis",
        "year": 1930,
        "desc": "Aufstand der Islamisten gegen die Säkularisierung in der Türkei"
    },
    {
        "title": "Gründung der Tschechoslowakei",
        "year": 1918,
        "desc": "Gründung des neuen Staates Tschechoslowakei"
    },
    {
        "title": "Osmanischer Kriegseintritt im Ersten Weltkrieg",
        "year": 1914,
        "desc": "Aspekt der Geschichte"
    },
    {
        "title": "Japanische Eroberung der Gilbertinseln",
        "year": 1941,
        "desc": "Periode in der Geschichte Kiribatis"
    },
    {
        "title": "¡Cu-Cut!-Zwischenfall",
        "year": 1905,
        "desc": "Angriff spanischer Offiziere aufgrund einer satirischen Karikatur"
    },
    {
        "title": "Aufstand der Hinterbänkler der Social-Credit-Partei",
        "year": 1937,
        "desc": "Parlamentarischer Aufstand in Kanada."
    },
    {
        "title": "Razzia am Eleftherias-Platz",
        "year": 1942,
        "desc": "Antisemitische Maßnahme in Thessaloniki."
    },
    {
        "title": "Große Flut am Musi",
        "year": 1908,
        "desc": "Überschwemmung in Hyderabad nach dem Übertreten des Musi-Flusses."
    },
    {
        "title": "Linke Fehler",
        "year": 1941,
        "desc": "Als „Roter Terror“ bezeichnete Gewalt in Jugoslawien während des Zweiten Weltkriegs."
    },
    {
        "title": "Ende des britischen Mandats für Palästina",
        "year": 1948,
        "desc": "Aspekt der Geschichte"
    },
    {
        "title": "Aufstand der Srb",
        "year": 1941,
        "desc": "Aufstand in Kroatien"
    },
    {
        "title": "Verbrechen von Zaleszczyki",
        "year": 1941,
        "desc": "Massenmord von NKWD-Funktionären"
    },
    {
        "title": "Flugkreuzfahrt zum zehnjährigen Jubiläum",
        "year": 1933,
        "desc": "Transatlantikflug"
    },
    {
        "title": "Erster feministischer Kongress von Yucatán",
        "year": 1916,
        "desc": "Erster feministischer Kongress in Yucatán, Mexiko"
    },
    {
        "title": "Zwangshospitalisierung in Honmyōji",
        "year": 1940,
        "desc": "Zwangshospitalisierung von Leprapatienten in Japan"
    },
    {
        "title": "Menschenrechtsverletzungen in Belutschistan",
        "year": 1948,
        "desc": "organisierter Missbrauch grundlegender Menschenrechte in Belutschistan, Pakistan"
    },
    {
        "title": "Spaltung zwischen Nanjing und Wuhan",
        "year": 1927,
        "desc": "politische Spaltung zwischen der linken KMT-Regierung in Wuhan und der rechten KMT-Regierung in Nanjing"
    },
    {
        "title": "Twin Falls saucer hoax",
        "year": 1947,
        "desc": "Flying saucer hoax"
    },
    {
        "title": "Ukrainisches Todesdreieck",
        "year": 1919,
        "desc": "Militärische Situation in der Ukraine am Ende des Ersten Weltkriegs"
    },
    {
        "title": "Krönungsprozession der Frauen",
        "year": 1911,
        "desc": "Fest-/Demonstrationszug für Frauenwahlberechtigung durch London"
    },
    {
        "title": "Carlton-Club-Treffen",
        "year": 1922,
        "desc": "Treffen der Parlamentsabgeordneten der britischen Conservative Party"
    },
    {
        "title": "Tod und Beerdigung von Königin Alexandra",
        "year": 1925,
        "desc": "Tod und Beerdigung der Königinmutter des Vereinigten Königreichs"
    },
    {
        "title": "Tod von June Anne Devaney",
        "year": 1948,
        "desc": "Kindermord in London, England"
    },
    {
        "title": "Estnische Operation des NKWD",
        "year": 1937,
        "desc": "Massenverhaftungen und Hinrichtungen von Esten in der UdSSR"
    },
    {
        "title": "Futian-Zwischenfall",
        "year": 1930,
        "desc": "Der Futian Zwischenfall war, Kommunisten kamen ums leben."
    },
    {
        "title": "Internationale Ausstellung",
        "year": 1906,
        "desc": "Weltausstellung in Christchurch, Neuseeland."
    },
    {
        "title": "Zwischenfall von Rengasdengklok",
        "year": 1945,
        "desc": "Indonesische Entführung"
    },
    {
        "title": "Revolution von Trujillo",
        "year": 1932,
        "desc": "Aufstand in Peru"
    },
    {
        "title": "Shimpeitai-Zwischenfall",
        "year": 1933,
        "desc": "Versuch, in Japan durch einen Umsturz ein nationalistisch-militärisches Regime zu errichten"
    },
    {
        "title": "Stuttgarter Kabelattentat",
        "year": 1933,
        "desc": "Straftat, die sich in Deutschland ereignete; kommunistischer Widerstand gegen den Nationalsozialismus"
    },
    {
        "title": "Abgebrochene Krönung von Edward VIII.",
        "year": 1937,
        "desc": "abgesagte Krönung im Vereinigten Königreich"
    },
    {
        "title": "Babe Ruths vorhergesagter Homerun",
        "year": 1932,
        "desc": "Homerun-Hit von Babe Ruth in der World Series, den Ruth angeblich vorhergesagt hatte"
    },
    {
        "title": "Brand in der Munitionsfabrik Wöllersdorf",
        "year": 1918,
        "desc": "Großbrand einer Halle in der Munitionsfabrik vor Ende des Ersten Weltkrieges am in Wöllersdorf"
    },
    {
        "title": "Cannock Chase murders",
        "year": 1929,
        "desc": "Mord an drei jungen Mädchen"
    },
    {
        "title": "Auflösung der polnischen Widerstandsorganisation Osa-Kosa",
        "year": 1943,
        "desc": "Verhaftung von Mitgliedern der polnischen Widerstandsorganisation durch die Gestapo."
    },
    {
        "title": "Zwangsräumung in Epynt",
        "year": 1940,
        "desc": "forced eviction in Powys, Wales"
    },
    {
        "title": "Eucharistischer Kongress von Dublin",
        "year": 1932,
        "desc": "Christliche Veranstaltung in Dublin, Irland"
    },
    {
        "title": "Evakuierung des Eremitage-Museums",
        "year": 1941,
        "desc": "emergency evacuation of art from Leningrad during World War II"
    },
    {
        "title": "George V's hunting trip in Nepal",
        "year": 1911,
        "desc": "hunting trip in Nepal"
    },
    {
        "title": "Kinsmen Coaster Classic",
        "year": 1938,
        "desc": "Canadian kid's gravity-powered racing program"
    },
    {
        "title": "La-Spezia-Affäre",
        "year": 1946,
        "desc": "Ereignis während der Alija Bet, in deren Folge Juden legal nach Palästina einwandern konnten"
    },
    {
        "title": "Lev Casso Case",
        "year": 1911,
        "desc": "Massenentlassung liberaler Professoren der Moskauer Universität"
    },
    {
        "title": "Marianna Coal Mine Disaster",
        "year": 1908,
        "desc": "Marianna-Minenkatastrophe in Pennsylvania"
    },
    {
        "title": "Friedenstag",
        "year": 1919,
        "desc": "parade in London"
    },
    {
        "title": "FAVAG-Skandal",
        "year": 1929,
        "desc": "Zusammenbruch der Frankfurter Allgemeinen Versicherungs-AG (FAVAG)."
    },
    {
        "title": "erster Tag der Fernsehprogramme",
        "year": 1936,
        "desc": "Beginn regelmäßiger Fernsehausstrahlungen in hoher Auflösung über einen eigenen Kanal."
    },
    {
        "title": "Haidbauer-Zwischenfall",
        "year": 1926,
        "desc": "Körperlicher Angriff auf ein Kind von Ludwig Wittgenstein"
    },
    {
        "title": "Iowa-Kuhkrieg",
        "year": 1931,
        "desc": "Streit in Iowa über die Untersuchung von Kühen auf Rindertuberkulose."
    },
    {
        "title": "Kuichou meldet eine Katastrophe",
        "year": 1913,
        "desc": "Katastrophe in China"
    },
    {
        "title": "Repressalien in Herbaijum und Menaldum",
        "year": 1944,
        "desc": "Nazi-Repressalien im Rahmen der Besetzung der Niederlande im Zweiten Weltkrieg, bei denen sechs Menschen als Strafe für die Aktionen des Widerstands hingerichtet wurden"
    },
    {
        "title": "Rückeroberung des tschechischen Grenzgebiets",
        "year": 1918,
        "desc": "Rückeroberung des tschechischen Grenzgebiets durch die tschechoslowakische Armee."
    },
    {
        "title": "Slaughter's Mad Dash",
        "year": 1946,
        "desc": "Veranstaltung der World Series"
    },
    {
        "title": "Spring Creek-Überfall",
        "year": 1909,
        "desc": "Konflikt zwischen Viehzüchtern und Schafhirten in Wyoming"
    },
    {
        "title": "Tragödie auf der Insel Tiburón",
        "year": 1905,
        "desc": "Fehlende Goldsuchexpedition"
    },
    {
        "title": "Sturz des Kommunismus in Albanien",
        "year": 1992,
        "desc": "Studentische Proteste leiteten den politischen Wandel ein; später wurde der politische Pluralismus zugelassen."
    },
    {
        "title": "Runder Tisch in Polen",
        "year": 1989,
        "desc": "Gespräche am Runden Tisch in Polen"
    },
    {
        "title": "Brücke der Blumen",
        "year": 1990,
        "desc": "Veranstaltung von Demonstranten, die sich für die Vereinigung Rumäniens und Moldawiens einsetzten"
    },
    {
        "title": "Wirtschaftsliberalisierung in Indien",
        "year": 1991,
        "desc": "Wirtschaftsreformen in Indien, die am begannen"
    },
    {
        "title": "Dan-Air-Flug",
        "year": 1970,
        "desc": "Flugunfall in Spanien"
    },
    {
        "title": "Tod und Beerdigung von Kim Il-sung",
        "year": 1994,
        "desc": "Staatsbegräbnis in Nordkorea."
    },
    {
        "title": "Ghulja-Vorfall",
        "year": 1997,
        "desc": "gewalttätiges Ereignis im Uiguren-Han-Konflikt in Xinjiang"
    },
    {
        "title": "Unterbrechung der Ausstrahlung von Southern Television",
        "year": 1977,
        "desc": "Falschmeldung vom IBA-Sender"
    },
    {
        "title": "Morde im Punjab",
        "year": 1991,
        "desc": "Ermordung durch die Militanten"
    },
    {
        "title": "Kings-Bay-Affäre",
        "year": 1963,
        "desc": "Politischer Skandal in Norwegen"
    },
    {
        "title": "niedrigste auf der Erde gemessene Temperatur",
        "year": 1983,
        "desc": "die kälteste Temperatur auf der Erde"
    },
    {
        "title": "Kapitän Mitternacht",
        "year": 1986,
        "desc": "Entführung von HBO durch den amerikanischen Geschäftsmann Captain Midnight"
    },
    {
        "title": "Geiselnahme in der israelischen Botschaft in Bangkok",
        "year": 1972,
        "desc": "Palästinensischer Angriff in Thailand"
    },
    {
        "title": "Affen von Silver Spring",
        "year": 1981,
        "desc": "Gruppe von Versuchsaffen, die Tierschutzgeschichte schrieben"
    },
    {
        "title": "Zusammenstoß in Askeran",
        "year": 1988,
        "desc": "Aufruhr und Mord in Askeran, Aserbaidschanische SSR"
    },
    {
        "title": "Entfernung des ungarischen Grenzzauns",
        "year": 1989,
        "desc": "Entfernung des „Eisernen Vorhangs“ an der Grenze zwischen Österreich und Ungarn"
    },
    {
        "title": "Strom Thurmond verstößt gegen das Civil Rights Act",
        "year": 1957,
        "desc": "Längste Blockaderede in der Geschichte des US-Senats."
    },
    {
        "title": "Schüsse im Kapitol der Vereinigten Staaten",
        "year": 1954,
        "desc": "Angriff auf die US-Hauptstadt durch puertoricanische Nationalisten"
    },
    {
        "title": "Ruhollah Khomeinis Rückkehr in den Iran",
        "year": 1979,
        "desc": "Rückkehr des iranischen Religionsführers"
    },
    {
        "title": "Zusammenstoß am Siebten Tag des siebten Monats",
        "year": 1963,
        "desc": "Auseinandersetzung zwischen Polizei und Journalisten in Saigon, Südvietnam"
    },
    {
        "title": "Kauf von Gwadar",
        "year": 1958,
        "desc": "Übernahme von Gwadar durch Pakistan"
    },
    {
        "title": "Hands Across America",
        "year": 1986,
        "desc": "Amerikanische Spendenaktion"
    },
    {
        "title": "Überlaufen von Martin und Mitchell",
        "year": 1960,
        "desc": "Überlaufen von zwei Kryptologen der U.S. National Security Agency zur Sowjetunion"
    },
    {
        "title": "– Terroranschläge in Kuwait",
        "year": 1983,
        "desc": "Terroranschläge in ganz Kuwait –"
    },
    {
        "title": "Tod und Staatsbegräbnis von Georg VI",
        "year": 1952,
        "desc": "Beerdigung des Königs des Vereinigten Königreichs"
    },
    {
        "title": "Verschwinden von Joanne Ratcliffe und Kirste Gordon",
        "year": 1973,
        "desc": "vermisste australische Mädchen seitdem"
    },
    {
        "title": "Marlboro Freitag",
        "year": 1993,
        "desc": "Preisverfall bei Marlboro-Zigaretten weiter"
    },
    {
        "title": "Pueblo-Zwischenfall",
        "year": 1968,
        "desc": "Beschlagnahmung eines Schiffes der US-Marine durch Nordkorea"
    },
    {
        "title": "Toussaint Rouge",
        "year": 1954,
        "desc": "eine Reihe von Terroranschlägen algerischer Separatisten"
    },
    {
        "title": "Yehud-Angriff",
        "year": 1953,
        "desc": "Angriff auf israelische Zivilisten durch palästinensisch-arabische Fedajin"
    },
    {
        "title": "Bombenanschlag auf Saigon",
        "year": 1965,
        "desc": "Bombenanschlag, bei dem 42 Menschen getötet wurden"
    },
    {
        "title": "Ain Allah-Angriff",
        "year": 1994,
        "desc": "Militäroffensive Algerien Bürgerkrieg"
    },
    {
        "title": "Interne Hinrichtungen der Organisation Abu Nidal",
        "year": 1987,
        "desc": "Hinrichtungen innerhalb der Abu Nidal-Organisation"
    },
    {
        "title": "Angriff auf die Abgeordneten im Obersten Rat von Belarus",
        "year": 1995,
        "desc": "Batterie gegen die Oppositionsabgeordneten in den Räumlichkeiten des belarussischen Parlaments"
    },
    {
        "title": "Tod von Kevin Gately",
        "year": 1974,
        "desc": "fatality in London public demonstration"
    },
    {
        "title": "Flug der Lightning XM135",
        "year": 1966,
        "desc": "unbeabsichtigter Flug eines britischen Abfangjägers"
    },
    {
        "title": "Handschlag von Verdun",
        "year": 1984,
        "desc": "symbolischer Moment der deutsch-französischen Versöhnung"
    },
    {
        "title": "Anklage und Verhaftung von Augusto Pinochet",
        "year": 1998,
        "desc": "Verhaftung des Diktators wegen Verbrechen gegen die Menschlichkeit."
    },
    {
        "title": "Krise in der peruanischen Botschaft in Havanna",
        "year": 1980,
        "desc": "Besetzung der peruanischen Botschaft in Havanna durch Kubaner, die das Land verlassen wollten."
    },
    {
        "title": "Massaker auf der Fähre Kumudini",
        "year": 1985,
        "desc": "Angriff auf ein Fährschiff."
    },
    {
        "title": "Mord an einer Rolex-Uhr",
        "year": 1998,
        "desc": "Raubmord in Singapur"
    },
    {
        "title": "Einnahme von Pando",
        "year": 1969,
        "desc": "Schlacht in Uruguay"
    },
    {
        "title": "Zwischenfall von Talangsari",
        "year": 1989,
        "desc": "Ereignis in Indonesien"
    },
    {
        "title": "Hochzeit von Prinzessin Beatrix der Niederlande und Claus van Amsberg",
        "year": 1966,
        "desc": "Niederländische königliche Hochzeit"
    },
    {
        "title": "Das FBI im Weißen Haus reicht eine Kontroverse ein",
        "year": 1993,
        "desc": "politischer Skandal der Clinton-Regierung"
    },
    {
        "title": "Kontroverse um das Reisebüro im Weißen Haus",
        "year": 1993,
        "desc": "Ethik-Kontroverse der Clinton-Regierung"
    },
    {
        "title": "Busentführung in Ordschonikidse",
        "year": 1988,
        "desc": "Flugzeugentführung in der Sowjetunion"
    },
    {
        "title": "Bombenanschlag auf Manchester",
        "year": 1992,
        "desc": "Angriff der Provisorischen Irisch-Republikanischen Armee mit zwei Bomben, bei dem 64 Menschen verletzt und mehrere Gebäude in Manchester, England, beschädigt wurden"
    },
    {
        "title": "Lego verschüttet",
        "year": 1997,
        "desc": "Seeunfall in Cornwall, England"
    },
    {
        "title": "Angriff auf die ägyptische Botschaft in Pakistan",
        "year": 1995,
        "desc": "Militanter Angriff in Islamabad, Pakistan"
    },
    {
        "title": "Bydgoszcz politische Provokation",
        "year": 1981,
        "desc": "politische Provokation"
    },
    {
        "title": "Cruzeiro do Sul Flug",
        "year": 1970,
        "desc": "Flugzeugentführung"
    },
    {
        "title": "Cruzeiro do Sul Flug (Flugzeugentführung)",
        "year": 1984,
        "desc": "Flugzeugentführung"
    },
    {
        "title": "Morde an der Familie Dardeen",
        "year": 1987,
        "desc": "Ungelöste Familienmorde"
    },
    {
        "title": "Morde an Ein Ofarim",
        "year": 1956,
        "desc": "Angriff auf israelische drusische Zivilisten durch palästinensische Fedajin"
    },
    {
        "title": "Heißer Sommer",
        "year": 1975,
        "desc": "Veranstaltung aus Portugal"
    },
    {
        "title": "Karlino-Ölausbruch",
        "year": 1980,
        "desc": "Ölquellenausbruch in Karlino, Polen"
    },
    {
        "title": "Vorfälle mit Leyla Express und Johnny Express",
        "year": 1971,
        "desc": "Von kubanischen Kanonenbooten beschlagnahmte Frachter."
    },
    {
        "title": "Verlust von MV Darlwyne",
        "year": 1966,
        "desc": "Vergnügungskreuzer sinkt vor der Küste Cornwalls"
    },
    {
        "title": "UFO-Vorfall in Malmström",
        "year": 1967,
        "desc": "angebliches paranormales Ereignis"
    },
    {
        "title": "Mord an Harry und Harriette Moore",
        "year": 1951,
        "desc": "Bombenanschlag, bei dem zwei Bürgerrechtler getötet wurden"
    },
    {
        "title": "Morde an Lauria Bible und Ashley Freeman",
        "year": 1999,
        "desc": "Mord an zwei amerikanischen Teenagern"
    },
    {
        "title": "Hissen der Flagge über Quneitra",
        "year": 1974,
        "desc": "Veranstaltung in Syrien"
    },
    {
        "title": "Aufstand der Nationalisten in San Juan",
        "year": 1950,
        "desc": "Aufstand gegen die Regierung der Vereinigten Staaten in Puerto Rico"
    },
    {
        "title": "Hochzeit von Harald, Kronprinz von Norwegen, und Sonja Haraldsen",
        "year": 1968,
        "desc": "Norwegische königliche Hochzeit"
    },
    {
        "title": "Aufstand im Senegal",
        "year": 1968,
        "desc": "Protestveranstaltung im Senegal."
    },
    {
        "title": "Radioboykott",
        "year": 1970,
        "desc": "Konflikt in der australischen Musikindustrie."
    },
    {
        "title": "Jubiläumsweihe",
        "year": 1975,
        "desc": "Religiöse Zeremonie im Vatikan."
    },
    {
        "title": "Pogrom gegen Tamilen in Karaitivu",
        "year": 1985,
        "desc": "Angriffe auf Zivilisten in Sri Lanka."
    },
    {
        "title": "Hagelsturm im östlichen Minas Gerais",
        "year": 1985,
        "desc": "Naturkatastrophe im brasilianischen Bundesstaat Minas Gerais."
    },
    {
        "title": "Nagelbombenanschläge in De Meer",
        "year": 1989,
        "desc": "Fußball-Hooligan-Vorfall in den Niederlanden"
    },
    {
        "title": "Aktion Rose",
        "year": 1953,
        "desc": "Aktion der DDR-Regierung zur Verstaatlichung von Hotels, Erholungsheimen, Taxi- und Dienstleistungsunternehmen."
    },
    {
        "title": "Amityville-Affäre",
        "year": 1974,
        "desc": "Ereignisse, die die Grundlage eines Buches bildeten"
    },
    {
        "title": "Arabisierung des Kommandos der jordanischen Armee",
        "year": 1956,
        "desc": "Entlassung hochrangiger britischer Kommandeure der Jordanisch-Arabischen Legion"
    },
    {
        "title": "Schwarzer Freitag",
        "year": 1987,
        "desc": "Demonstrationsunterdrückung in Panama"
    },
    {
        "title": "Bosanski Šamac ethnische Säuberung",
        "year": 1992,
        "desc": "Verfolgungskampagne"
    },
    {
        "title": "Castro Sweep",
        "year": 1989,
        "desc": "Polizeiaufstand in San Francisco"
    },
    {
        "title": "Tod und Beerdigung von Queen Mary",
        "year": 1953,
        "desc": "Tod und Beerdigung der Königinmutter des Vereinigten Königreichs"
    },
    {
        "title": "Tod und Staatsbegräbnis von Kamuzu Banda",
        "year": 1997,
        "desc": "Staatsbegräbnis in Malawi."
    },
    {
        "title": "Vertreibung von Montoneros von der Plaza de Mayo",
        "year": 1974,
        "desc": "Politische Situation in Argentinien"
    },
    {
        "title": "Gerüsteinsturz von Willow Island",
        "year": 1978,
        "desc": "Bauwerkseinstruktur in West Virginia, USA"
    },
    {
        "title": "Vergewaltigung in Glen Ridge",
        "year": 1989,
        "desc": "Vergewaltigung eines Mädchens in Glen Ridge, New Jersey"
    },
    {
        "title": "Tolle Umbenennung",
        "year": 1987,
        "desc": "Umstrukturierung der Usenet-Newsgroups"
    },
    {
        "title": "Guemmar-Angriff",
        "year": 1991,
        "desc": "Militanter Angriff auf einen Grenzposten in Algerien"
    },
    {
        "title": "Amtseinführung von Andrés Pastrana",
        "year": 1998,
        "desc": "Amtseinführung des kolumbianischen Präsidenten"
    },
    {
        "title": "UFO-Vorfall am Labor Day",
        "year": 1969,
        "desc": "UFO-Vorfall in Berkshire County, Massachusetts, USA"
    },
    {
        "title": "Llogara-Tragödie",
        "year": 1989,
        "desc": "Busunfall und Hubschrauberabsturz in Albanien"
    },
    {
        "title": "Massengrab Mrkonjić Grad",
        "year": 1995,
        "desc": "Gräueltat im Bosnienkrieg"
    },
    {
        "title": "Nacht der langen Messer",
        "year": 1992,
        "desc": "IRA-Aktion in Belfast"
    },
    {
        "title": "Niš (Stiefel)",
        "year": 1952,
        "desc": "Am versunkenes Boot in der Donau"
    },
    {
        "title": "Operation Gardel",
        "year": 1975,
        "desc": "Flugzeugbombenanschlag in Argentinien"
    },
    {
        "title": "Katastrophe in der Stierkampfarena El Progreso",
        "year": 1965,
        "desc": "Massenandrang in Mexiko"
    },
    {
        "title": "Angriff auf Ramble Inn",
        "year": 1976,
        "desc": "Schießerei der UVF in der Nähe von Antrim"
    },
    {
        "title": "Silco-Vorfall",
        "year": 1985,
        "desc": "Entführung einer belgisch-französischen Familie durch die libysche Regierung"
    },
    {
        "title": "Simpang KKA-Vorfall",
        "year": 1999,
        "desc": "Erschießung von Demonstranten in Indonesien"
    },
    {
        "title": "Der Vorfall im Tunnel am Moskauer Gartenring geht weiter",
        "year": 1991,
        "desc": "Sowjetischer Putschversuch"
    },
    {
        "title": "Torfall von Madrid",
        "year": 1998,
        "desc": "Der Torfall vor dem Champions-League-Halbfinale in Madrid"
    },
    {
        "title": "Tragödie von Tacoa",
        "year": 1982,
        "desc": "Öltankbrand in Venezuela"
    },
    {
        "title": "Troja-Axtmorde",
        "year": 1964,
        "desc": "Massenmord in Michigan"
    },
    {
        "title": "Zwangssterilisationen in Uttawar",
        "year": 1976,
        "desc": "Zwangssterilisationsveranstaltung in Indien"
    },
    {
        "title": "Mount McKinley-Katastrophe",
        "year": 1967,
        "desc": "Bergsteiger-Katastrophe"
    },
    {
        "title": "Cyanobakterienblüte am Darling River",
        "year": 1991,
        "desc": "Größte Algenblüte seit Beginn der Aufzeichnungen"
    },
    {
        "title": "Stürme in Queensland",
        "year": 1992,
        "desc": "Gewitterserie in Queensland"
    },
    {
        "title": "Socialist Left Party national convention",
        "year": 1997,
        "desc": "Norwegisches politisches Ereignis"
    },
    {
        "title": "Accountantsdag in Congresgebouw Den Haag",
        "year": 1973,
        "desc": "Besuch der Königin im Bouwcentrum in Rotterdam."
    },
    {
        "title": "Angriff auf die pakistanische Botschaft in Kabul",
        "year": 1995,
        "desc": "Angriff afghanischer Demonstranten auf die pakistanische Botschaft in Kabul, Afghanistan"
    },
    {
        "title": "Bill Buckners Fehler in der World Series",
        "year": 1986,
        "desc": "Entscheidender Fehler in einem Baseballspiel der World Series im Shea Stadium in New York."
    },
    {
        "title": "Maurerwettbewerb im Bouwcentrum Rotterdam",
        "year": 1955,
        "desc": "Veranstaltung im Bouwcentrum Rotterdam"
    },
    {
        "title": "Demonstration der Ausstellung „Jedes Haus bald“ im Bouwcentrum Rotterdam",
        "year": 1958,
        "desc": "Veranstaltung im Bouwcentrum Rotterdam"
    },
    {
        "title": "Kongresse von Gniezno",
        "year": 1997,
        "desc": "Dialog zwischen verschiedenen Kulturen, Konfessionen und Religionen in Anknüpfung an die Tradition der Gniezno-Kongresse."
    },
    {
        "title": "Goldener Sonntag",
        "year": 1972,
        "desc": "Bezeichnung für einen besonderen Tag in der Sportgeschichte der Bundesrepublik Deutschland."
    },
    {
        "title": "Kirribilli-Abkommen",
        "year": 1988,
        "desc": "Politische Vereinbarung in Australien."
    },
    {
        "title": "Verschwinden von Louise und Charmian Faulkner",
        "year": 1980,
        "desc": "Mutter und Tochter, die verschwunden sind"
    },
    {
        "title": "Beschuss der Kirche von Madhu",
        "year": 1999,
        "desc": "Massaker in einer Kirche während des Bürgerkriegs in Sri Lanka."
    },
    {
        "title": "Maria Callas besucht das Bovema-Studio in Heemstede",
        "year": 1959,
        "desc": "Veranstaltung in Heemstede"
    },
    {
        "title": "Nacht der Akten",
        "year": 1992,
        "desc": "Begriff im polnischen Journalismus für ein politisches Ereignis (Nacht vom 4. auf den )"
    },
    {
        "title": "Eröffnung des mobilen Empfangszentrums DD-2 im Bouwcentrum Rotterdam",
        "year": 1972,
        "desc": "Veranstaltung im Bouwcentrum Rotterdam"
    },
    {
        "title": "Morde an Paddy Wilson und Irene Andrews",
        "year": 1973,
        "desc": "Tötungen von zwei Katholiken in Belfast während der Unruhen."
    },
    {
        "title": "Rückführung der Bestände aus Polen",
        "year": 1965,
        "desc": "Rückführung von im Zweiten Weltkrieg nach Polen ausgelagerten deutschen Bibliotheksbeständen in die DDR"
    },
    {
        "title": "Teilung des Moskauer Kunsttheaters",
        "year": 1987,
        "desc": "Aufteilung der Theatergruppe in zwei unabhängige Unternehmen"
    },
    {
        "title": "Der Calhoun-Schuss",
        "year": 1993,
        "desc": "Basketballschuss, der im Rahmen einer Werbeaktion während eines NBA-Spiels gemacht wurde"
    },
    {
        "title": "Besuch der Königin im Bouwcentrum Rotterdam",
        "year": 1956,
        "desc": "Veranstaltung im Bouwcentrum Rotterdam"
    },
    {
        "title": "Winterthurer Ereignisse",
        "year": 1984,
        "desc": "Jugendunruhen in Winterthur."
    },
    {
        "title": "Stromausfall in Spanien, Portugal und Frankreich",
        "year": 2025,
        "desc": "Ereignis auf der Iberischen Halbinsel und in Südfrankreich"
    },
    {
        "title": "CONCACAF Gold Cup",
        "year": 2017,
        "desc": "24. Ausspielung der Kontinentalmeisterschaft im Fußball für Nord"
    },
    {
        "title": "Tod und Staatsbegräbnis von Fidel Castro",
        "year": 2016,
        "desc": "Artikel bei Wikinews"
    },
    {
        "title": "Selbstmordattentat in Islamabad",
        "year": 2025,
        "desc": "suicide bombing in Islamabad, Pakistan"
    },
    {
        "title": "Wiedereröffnung der Kathedrale Notre-Dame",
        "year": 2024,
        "desc": "Prominenz aus aller Welt eingeladen, Treffen von Trump und Selenskyj, Scholz abwesend"
    },
    {
        "title": "Boeing MAX groundings",
        "year": 2019,
        "desc": "Boeing MAX groundings due to safety concerns, after two new airplanes crashed within five months"
    },
    {
        "title": "Koranverbrennungen in Schweden",
        "year": 2023,
        "desc": "Verbrennung des Korans als Protest in Schweden"
    },
    {
        "title": "salmon chaos",
        "year": 2021,
        "desc": "Vorfall in Taiwan."
    },
    {
        "title": "Parlamentswahl in Myanmar",
        "year": 2020,
        "desc": "Parlamentswahlen in Myanmar"
    },
    {
        "title": "Siegesparade in Baku",
        "year": 2020,
        "desc": "Military Triumph Parade"
    },
    {
        "title": "Megxit",
        "year": 2020,
        "desc": "Verzicht des Herzogs und der Herzogin von Sussex auf den „hochrangigen“ königlichen Status"
    },
    {
        "title": "Überschwemmungen in Kinshasa",
        "year": 2022,
        "desc": "Überschwemmung in Kinshasa, Demokratische Republik Kongo"
    },
    {
        "title": "Raketenangriffe in Erbil",
        "year": 2021,
        "desc": "Raketenangriffe auf Erbil, Region Kurdistan, Irak"
    },
    {
        "title": "Regierungskrise im Vereinigten Königreich",
        "year": 2022,
        "desc": "Krise, die zum Ende der Amtszeit von Liz Truss führte"
    },
    {
        "title": "United Express-Flug",
        "year": 2017,
        "desc": "Vorfall, bei dem ein Passagier gewaltsam aus einem Flugzeug entfernt wurde."
    },
    {
        "title": "Vergewaltigungsvorwürfe an der Cornell University",
        "year": 2024,
        "desc": "Ehemalige Studentin wirft Verbindungsmitgliedern eine Gruppenvergewaltigung vor"
    },
    {
        "title": "Politische Krise in Bolivien",
        "year": 2019,
        "desc": "Eine Reihe von Rücktritten der höchsten politischen Führer Boliviens nach umstrittenen Wahlergebnissen"
    },
    {
        "title": "Raketenangriffe in Erbil (Raketenangriffe auf Erbil, Region Kurdistan, Irak)",
        "year": 2022,
        "desc": "Raketenangriffe auf Erbil, Region Kurdistan, Irak"
    },
    {
        "title": "Untersuchung zur Wahlmanipulation durch Mnet",
        "year": 2019,
        "desc": "Skandal um K-Pop-TV-Show mit Wahlbetrug"
    },
    {
        "title": "Sarina Esmailzadeh",
        "year": 2022,
        "desc": "Wurde während der Proteste im Iran getötet."
    },
    {
        "title": "Verhaftung von Yoon Suk Yeol",
        "year": 2025,
        "desc": "Festnahme des suspendierten Präsidenten Südkoreas"
    },
    {
        "title": "Corinaldo-Ansturm",
        "year": 2018,
        "desc": "In Corinaldo, Italien, ereignete sich eine Tragödie"
    },
    {
        "title": "Hongkong 47",
        "year": 2021,
        "desc": "Massenverhaftung von Hongkonger Demokratiebefürwortern"
    },
    {
        "title": "Nordkorea-Russland-Gipfel",
        "year": 2019,
        "desc": "Treffen von Kim Jong-un und Wladimir Putin in Wladiwostok"
    },
    {
        "title": "Bombenanschlag auf Kano",
        "year": 2014,
        "desc": "Islamistischer Terroranschlag in Kano, Nigeria"
    },
    {
        "title": "Bamako-Angriffe",
        "year": 2024,
        "desc": "Mali-Angriff durch dschihadistische Aufständische"
    },
    {
        "title": "Tod und Staatsbegräbnis von Heydar Aliyev",
        "year": 2003,
        "desc": "Tod des ehemaligen aserbaidschanischen Präsidenten"
    },
    {
        "title": "Emeritierter Papst Benedikt XVI. gestorben",
        "year": 2022,
        "desc": "Tod von Papst Benedikt XVI"
    },
    {
        "title": "Internationales Jahr der Grundlagenwissenschaften für nachhaltige Entwicklung",
        "year": 2022,
        "desc": "Einhaltung durch die Vereinten Nationen"
    },
    {
        "title": "LKW-Angriff in London, Ontario",
        "year": 2021,
        "desc": "Tötung in Kanada"
    },
    {
        "title": "Untergang des Wundermeeres",
        "year": 2025,
        "desc": "Bootsuntergang in der Hạ Long Bay, Vietnam"
    },
    {
        "title": "Malegaon-Explosionen",
        "year": 2006,
        "desc": "Bombenanschläge in Malegaon, Bundesstaat Maharashtra, Indien"
    },
    {
        "title": "Anschlag auf das Serena Hotel in Kabul",
        "year": 2014,
        "desc": "Massenerschießung in Kabul, Afghanistan"
    },
    {
        "title": "Autobombenanschläge in Bagdad",
        "year": 2017,
        "desc": "Serie von Selbstmordanschlägen auf Autos"
    },
    {
        "title": "Auszählung des Electoral College zur Präsidentschaftswahl in den Vereinigten Staaten",
        "year": 2021,
        "desc": "Auszählung der vom Wahlkollegium offiziell abgegebenen Stimmzettel im US-Kongress"
    },
    {
        "title": "Silchar-Überschwemmungen",
        "year": 2022,
        "desc": "Naturkatastrophe in Assam, Indien"
    },
    {
        "title": "Überschwemmungen und Erdrutsche in São Paulo",
        "year": 2023,
        "desc": "Naturkatastrophe in Brasilien"
    },
    {
        "title": "Angriffe auf Journalisten während des Konflikts zwischen Israel und der Hisbollah (seit )",
        "year": 2023,
        "desc": "Serie von Angriffen auf Journalisten"
    },
    {
        "title": "Politische Gewalt in Bangladesch",
        "year": 2025,
        "desc": "politische Gewalt nach dem Tod von Osman Hadi"
    },
    {
        "title": "Brandanschlag im Dorf Duma",
        "year": 2015,
        "desc": "Brandanschlag auf ein palästinensisches Haus"
    },
    {
        "title": "Exhumierung von Francisco Franco",
        "year": 2019,
        "desc": "Überführung der Leiche des Diktators Francisco Franco aus Valle de los Caídos"
    },
    {
        "title": "Kagara-Entführung",
        "year": 2021,
        "desc": "Ziviler Angriff in Nigeria"
    },
    {
        "title": "Raketenangriff auf Wohnheime in Charkiw",
        "year": 2022,
        "desc": "Russischer Raketenangriff in der Ukraine"
    },
    {
        "title": "Massengräber im Nasser-Krankenhaus",
        "year": 2024,
        "desc": "Massengrabstätte in Khan Yunis"
    },
    {
        "title": "Unruhen in Xinjiang",
        "year": 2009,
        "desc": "Anschläge und darauffolgende Unruhen"
    },
    {
        "title": "Stand News Razzien und Verhaftungen",
        "year": 2021,
        "desc": "Razzia der Polizei bei einem demokratiefreundlichen Medienunternehmen in Hongkong"
    },
    {
        "title": "Berufung des Vereinigten Königreichs auf Artikel 50",
        "year": 2017,
        "desc": "Beschwörung des EU-Austrittsprozesses für „Brexit“"
    },
    {
        "title": "Überschwemmungen in Australien",
        "year": 2022,
        "desc": "Katastrophe in New South Wales"
    },
    {
        "title": "Jodhpur-Ansturm",
        "year": 2008,
        "desc": "Menschenansturm in Rajasthan, Indien"
    },
    {
        "title": "Südostasiatischer Dunst",
        "year": 2010,
        "desc": "Dunst über der Region Südostasien Mitte"
    },
    {
        "title": "Assam violence",
        "year": 2012,
        "desc": "violence in India"
    },
    {
        "title": "NIS public opinion manipulation scandal",
        "year": 2012,
        "desc": "Korean political scandal"
    },
    {
        "title": "Rede von Joe Biden vor einer gemeinsamen Sitzung des Kongresses",
        "year": 2021,
        "desc": "Rede von Präsident Biden vor dem Kongress"
    },
    {
        "title": "Manipur landslide",
        "year": 2022,
        "desc": "landslide in Manipur, northeast India"
    },
    {
        "title": "Ticketmaster controversy",
        "year": 2022,
        "desc": "Kontroverse um Ticketmaster und Taylor Swift"
    },
    {
        "title": "Bengaluru crowd crush",
        "year": 2025,
        "desc": "stampede in Bengaluru, India"
    },
    {
        "title": "Bahrain Bloody Thursday",
        "year": 2011,
        "desc": "Name des vierten Tages der Proteste in Bahrain"
    },
    {
        "title": "Gefängnisausbruch in Bauchi",
        "year": 2010,
        "desc": "Gefängnisausbruch durch Boko Haram"
    },
    {
        "title": "Dritte Amtseinführung von Luiz Inácio Lula da Silva",
        "year": 2023,
        "desc": "Amtseinführung des brasilianischen Präsidenten"
    },
    {
        "title": "Explosion in der Nähe des Dorfes Susuzluq",
        "year": 2021,
        "desc": "explosion in Azerbaijan"
    },
    {
        "title": "Bombenanschlag auf einen Markt in Quetta",
        "year": 2013,
        "desc": "Bombenanschlag auf einen Markt in Quetta, Belutschistan, Pakistan"
    },
    {
        "title": "Angriff im Südlibanon",
        "year": 2025,
        "desc": "Israelische Tötung von Zivilisten"
    },
    {
        "title": "Luftangriff in Togoga",
        "year": 2021,
        "desc": "In Togoga, Region Tigray, kam es zu einem Luftangriff"
    },
    {
        "title": "Vorfall mit Wang Lijun",
        "year": 2012,
        "desc": "Skandal in der chinesischen Politik"
    },
    {
        "title": "Yeh Yung-chih-Vorfall",
        "year": 2000,
        "desc": "Taiwans Multi-Gender-Themenveranstaltung"
    },
    {
        "title": "Bombenanschlag auf die Quetta-Moschee",
        "year": 2003,
        "desc": "Terroranschlag in Quetta, Pakistan"
    },
    {
        "title": "Bombenanschläge in Mogadischu",
        "year": 2008,
        "desc": "Am Straßenrand tötete eine Bombe 21 Frauen und verletzte weitere 46 Menschen"
    },
    {
        "title": "Inhaftierung amerikanischer Journalisten durch Nordkorea",
        "year": 2009,
        "desc": "Diplomatische Pattsituation zwischen den USA und Nordkorea"
    },
    {
        "title": "Masseninvasion russischer Eisbären",
        "year": 2019,
        "desc": "Ereignis, bei dem Eisbären das Stadtgebiet betraten"
    },
    {
        "title": "Internationale Konferenz über Imam al-Maturidi",
        "year": 2020,
        "desc": "Islamische Konferenz in Samarkand, Usbekistan"
    },
    {
        "title": "Tablighi Jamaat Coronavirus-Hotspot in Delhi",
        "year": 2020,
        "desc": "Virus-Super-Spreader-Ereignis"
    },
    {
        "title": "Gruppenvergewaltigung in Hyderabad",
        "year": 2022,
        "desc": "Gruppenvergewaltigung eines 17-jährigen Mädchens in Jubilee Hills, Hyderabad"
    },
    {
        "title": "Sambhal-Gewalt",
        "year": 2024,
        "desc": "Religiöse Spannungen wegen einer Moschee-Umfrage in Uttar Pradesh, Indien"
    },
    {
        "title": "Indische Wahlkontroverse",
        "year": 2025,
        "desc": "Wahlkampf"
    },
    {
        "title": "Sino-Metals Leach-Staudammkatastrophe in Sambia",
        "year": 2025,
        "desc": "Umweltkatastrophe in Sambia"
    },
    {
        "title": "Einsturz des Arbaat-Staudamms",
        "year": 2024,
        "desc": "Dammbruch und daraus resultierende Überschwemmungen im Sudan"
    },
    {
        "title": "Rede zum Kampf um die Seele der Nation",
        "year": 2022,
        "desc": "Rede von Präsident Joe Biden"
    },
    {
        "title": "Bombenanschlag in Kabul",
        "year": 2018,
        "desc": "Mord in Afghanistan"
    },
    {
        "title": "Daniel-Galván-Skandal",
        "year": 2013,
        "desc": "Marokkanischer politischer Skandal"
    },
    {
        "title": "Einsturz der Schnellstraßenbrücke Dao Khanong",
        "year": 2025,
        "desc": "Brückeneinsturz in Bangkok, Thailand"
    },
    {
        "title": "Tod von Christine Dacera",
        "year": 2021,
        "desc": "Vorfall auf den Philippinen"
    },
    {
        "title": "Tod von Frau Dhu",
        "year": 2014,
        "desc": "Tod einer australischen Aborigine-Frau in Polizeigewahrsam"
    },
    {
        "title": "Hamdania-Vorfall",
        "year": 2006,
        "desc": "Ermordung eines Irakers durch US-Marine"
    },
    {
        "title": "Luftangriffe auf Damaskus",
        "year": 2025,
        "desc": "Von Israel durchgeführte Luftangriffe"
    },
    {
        "title": "Kaduna-Entführung",
        "year": 2021,
        "desc": "Entführungsereignis im Norden Nigerias"
    },
    {
        "title": "Tötung von Awdah Hathaleen",
        "year": 2025,
        "desc": "Schießerei in den Hebron Hills"
    },
    {
        "title": "Vorfall in Nangar Khel",
        "year": 2007,
        "desc": "Massaker an afghanischen Zivilisten durch polnische Soldaten"
    },
    {
        "title": "Angriff auf Ariel",
        "year": 2022,
        "desc": "Terroranschlag im besetzten Westjordanland"
    },
    {
        "title": "Herabstufung der Kreditwürdigkeit der US-Bundesregierung",
        "year": 2011,
        "desc": "Verschlechterungen der geschätzten Kreditwürdigkeit"
    },
    {
        "title": "Luftangriffe auf die Wehda-Straße",
        "year": 2021,
        "desc": "Vorfall während der israelisch-palästinensischen Krise"
    },
    {
        "title": "Bombenanschlag auf Bagdad",
        "year": 2021,
        "desc": "Selbstmordattentäter-Anschlag, Sadr City, Bagdad"
    },
    {
        "title": "Anschlagsplan für Fort Dix",
        "year": 2007,
        "desc": "Verschwörung von sechs muslimischen Männern zum Angriff auf US-Militärangehörige in Fort Dix, New Jersey, USA"
    },
    {
        "title": "Überschwemmung in Bihar",
        "year": 2008,
        "desc": "verheerende Überschwemmung in Bihar, Indien"
    },
    {
        "title": "Rammangriff auf Saint-Jean-sur-Richelieu",
        "year": 2014,
        "desc": "Artikel bei Wikinews"
    },
    {
        "title": "Angriff auf die venezolanische Nationalversammlung",
        "year": 2017,
        "desc": "Angriff auf die Nationalversammlung"
    },
    {
        "title": "Überschwemmung in Afghanistan",
        "year": 2020,
        "desc": "Überschwemmungen in Afghanistan"
    },
    {
        "title": "Boykott von Facebook-Anzeigen",
        "year": 2020,
        "desc": "Boykottaufrufe gegen Werbeanzeigen auf der Plattform."
    },
    {
        "title": "JNU-Angriff",
        "year": 2020,
        "desc": "Angriff auf einen Universitätscampus in Indien"
    },
    {
        "title": "Croix-des-Bouquets-Jailbreak",
        "year": 2021,
        "desc": "Gefängnisflucht in Haiti"
    },
    {
        "title": "Proteste in Jordanien",
        "year": 2022,
        "desc": "Gaspreisproteste in Jordanien"
    },
    {
        "title": "Bombenanschlag auf eine Schule in Kabul",
        "year": 2022,
        "desc": "Bombenanschlag in Kabul, Afghanistan"
    },
    {
        "title": "Angriff auf das Gefängnis von Ciudad Juárez",
        "year": 2023,
        "desc": "Massenmord in Chihuahua, Mexiko"
    },
    {
        "title": "Hama-Angriff",
        "year": 2023,
        "desc": "Massaker des Islamischen Staates in Syrien"
    },
    {
        "title": "IIT-BHU-Gruppenvergewaltigung",
        "year": 2023,
        "desc": "Folter und Gruppenvergewaltigung in Indien"
    },
    {
        "title": "Angriff auf die Assistant High Commission von Bangladesch in Indien",
        "year": 2024,
        "desc": "Hindu-Extremismus in Tripura, Indien"
    },
    {
        "title": "Das Erdloch von Kuala Lumpur",
        "year": 2024,
        "desc": "Doline in Malaysia"
    },
    {
        "title": "Luftangriff auf Palmyra",
        "year": 2024,
        "desc": "Luftangriff der israelischen Luftwaffe in Syrien"
    },
    {
        "title": "Schneesturmkatastrophe in Uttarakhand",
        "year": 2024,
        "desc": "Tod von neun indischen Bergsteigern bei Schneesturm im Himalaya"
    },
    {
        "title": "Gush Etzion-Angriff",
        "year": 2025,
        "desc": "Anschlag im Westjordanland"
    },
    {
        "title": "Hinrichtungen der Hamas",
        "year": 2025,
        "desc": "Tötungen durch die Hamas im Gazastreifen"
    },
    {
        "title": "IndiGo-Störung",
        "year": 2025,
        "desc": "Störung des Flugbetriebs"
    },
    {
        "title": "Palmyra-Angriff",
        "year": 2025,
        "desc": "ISIS-Angriff auf US-amerikanische und syrische Truppen in Syrien"
    },
    {
        "title": "Sidon-Luftangriff",
        "year": 2025,
        "desc": "Angriff israelischer Streitkräfte im Libanon"
    },
    {
        "title": "Agbudu-Schießerei",
        "year": 2020,
        "desc": "Massenerschießungen in Nigeria"
    },
    {
        "title": "Bullhorn-Adresse",
        "year": 2001,
        "desc": "Rede von Präsident George W. Bush nach den Anschlägen"
    },
    {
        "title": "Vogelbeobachtungsvorfall im Central Park",
        "year": 2020,
        "desc": "rassistisch aufgeladene verbale Konfrontation im New Yorker Central Park"
    },
    {
        "title": "Angriff auf die FBI-Außenstelle in Cincinnati",
        "year": 2022,
        "desc": "Schießerei in Cincinnati, Ohio, USA"
    },
    {
        "title": "Tod von Wichian Klanprasert",
        "year": 2012,
        "desc": "Kriminalität in Thailand"
    },
    {
        "title": "Zusammenstöße in Nigeria",
        "year": 2011,
        "desc": "Vorfall in Nigeria"
    },
    {
        "title": "Bombenanschläge in Bagdad",
        "year": 2016,
        "desc": "Ziviler Angriff in Bagdad"
    },
    {
        "title": "Angriff auf das Flüchtlingslager Nuseirat",
        "year": 2024,
        "desc": "Israelischer Angriff auf ein Flüchtlingslager im Gazastreifen."
    },
    {
        "title": "Osterfrieden",
        "year": 2022,
        "desc": "Fehlgeschlagener Waffenstillstand bei der russischen Invasion in der Ukraine"
    },
    {
        "title": "Unfall im Erasmus-Bus",
        "year": 2016,
        "desc": "Busunfall in Spanien"
    },
    {
        "title": "Morde in Falludscha",
        "year": 2003,
        "desc": "Tötungen durch Soldaten der US-Armee im Irak."
    },
    {
        "title": "Goldenes Jubiläum von Carl XVI. Gustaf",
        "year": 2023,
        "desc": "50. Jahrestag der Himmelfahrt von König Carl XVI. Gustaf"
    },
    {
        "title": "Entführung der Greenfield University",
        "year": 2021,
        "desc": "Entführung von Studenten der Greenfield University im Bundesstaat Kaduna, Nigeria"
    },
    {
        "title": "Gewalt in der Hazari Lane",
        "year": 2024,
        "desc": "Gewalt in Chittagong"
    },
    {
        "title": "Menschenkette für baskische Selbstbestimmung",
        "year": 2018,
        "desc": "politische Demonstration"
    },
    {
        "title": "Bombenanschlag in Azaz",
        "year": 2017,
        "desc": "Selbstmordanschlag während des syrischen Bürgerkriegs"
    },
    {
        "title": "Historisches Ereignis",
        "year": 2024,
        "desc": "Ein im gregorianischen Kalender nicht existierendes Datum prägte die Bewegung zur Quotenreform in Bangladesch"
    },
    {
        "title": "Ermordung von Benjamin Achimeir",
        "year": 2024,
        "desc": "Tötung eines 14-jährigen Israelis"
    },
    {
        "title": "Gefängnisausbruch in Kogi",
        "year": 2014,
        "desc": "Ausbruch aus einem Gefängnis in Nigeria."
    },
    {
        "title": "Streumunitionsangriff in Charkiw",
        "year": 2022,
        "desc": "Vorfall während der russischen Invasion in der Ukraine"
    },
    {
        "title": "Marsch auf Washington für Gaza",
        "year": 2024,
        "desc": "Protestveranstaltung in Washington zur Unterstützung Gazas."
    },
    {
        "title": "Messerangriff in Mülhausen",
        "year": 2025,
        "desc": "Messerangriff am in der französischen Stadt Mülhausen"
    },
    {
        "title": "Angriff der Mohmand Agency",
        "year": 2010,
        "desc": "Selbstmordanschlag in Pakistan"
    },
    {
        "title": "Mordanschlag von La Défense",
        "year": 2013,
        "desc": "Angriff nahe Paris."
    },
    {
        "title": "Mord an Reagan Simmons-Hancock",
        "year": 2020,
        "desc": "Fall von Mord und Kindesentführung in Texas"
    },
    {
        "title": "Tragödie im Nachtclub New's Divine",
        "year": 2008,
        "desc": "human stampede in Mexico City"
    },
    {
        "title": "Brazil storm",
        "year": 2023,
        "desc": "severe weather in Southeastern Brazil"
    },
    {
        "title": "NTV-Affäre",
        "year": 2001,
        "desc": "Übernahme von NTV durch Gazprom und die russische Regierung"
    },
    {
        "title": "Anschlag in Kabul",
        "year": 2020,
        "desc": "Anschlag in Afghanistan"
    },
    {
        "title": "Streichung Indonesiens als Gastgeber der FIFA U-20-Weltmeisterschaft",
        "year": 2023,
        "desc": "Die Entscheidung der FIFA, das Turnier aus Indonesien zu entfernen"
    },
    {
        "title": "Taser-Vorfall mit Robert Dziekański",
        "year": 2007,
        "desc": "Polnischer Mann am Flughafen Vancouver von der Polizei getötet"
    },
    {
        "title": "Bombenanschlag in Quetta",
        "year": 2010,
        "desc": "Bombenanschlag in Quetta, Pakistan"
    },
    {
        "title": "Angriff auf den Hilfskonvoi von Urum al-Kubra",
        "year": 2016,
        "desc": "Angriff auf einen medizinischen Hilfskonvoi durch syrische Regierungstruppen"
    },
    {
        "title": "Ereignisse auf dem US-Repo-Markt",
        "year": 2019,
        "desc": "Finanzereignis, das sich auf die Zinssätze auswirkt"
    },
    {
        "title": "Zwischenfall mit der sudanesischen Ziegenheirat",
        "year": 2006,
        "desc": "virale Nachrichtengeschichte"
    },
    {
        "title": "Angriffe auf Migranten aus Uttar Pradeshi und Bihari in Maharashtra",
        "year": 2008,
        "desc": "Rassismus gegen Nordindianer, insbesondere Biharis"
    },
    {
        "title": "Bombenanschläge auf Busse in Sri Lanka",
        "year": 2008,
        "desc": "Teil des srilankischen Bürgerkriegs"
    },
    {
        "title": "Kindesmissbrauchsfall in Plymouth",
        "year": 2009,
        "desc": "Englischer Pädophilenring"
    },
    {
        "title": "Transatlantischer Flugzeugbombenanschlag",
        "year": 2010,
        "desc": "Fehlgeschlagener Terroranschlag"
    },
    {
        "title": "Angriff auf den pakistanischen Flughafen",
        "year": 2012,
        "desc": "Angriff der Teherik-i-Taliban auf einen pakistanischen internationalen Flughafen und Luftwaffenstützpunkt"
    },
    {
        "title": "Überfall auf Carlton Cannes",
        "year": 2013,
        "desc": "Bewaffneter Raubüberfall an der französischen Riviera"
    },
    {
        "title": "Parachinar-Angriff",
        "year": 2013,
        "desc": "Bombenanschlag in Parachinar, Pakistan"
    },
    {
        "title": "Ricin-Attacken",
        "year": 2013,
        "desc": "Der Versuch, Ricin zu verbreiten und als Waffe einzusetzen"
    },
    {
        "title": "Angriff auf indisches Konsulat in Herat",
        "year": 2014,
        "desc": "Angriff auf indisches Konsulat durch in Pakistan stationierte Militante"
    },
    {
        "title": "Chemieangriff auf Kafr Zita",
        "year": 2014,
        "desc": "Chemieangriff im syrischen Bürgerkrieg"
    },
    {
        "title": "Angriff auf den Larkana-Tempel",
        "year": 2014,
        "desc": "Angriffe auf einen Hindu-Tempel in Larkana, Pakistan"
    },
    {
        "title": "Baramulla-Angriff",
        "year": 2016,
        "desc": "Militanter Angriff in Baramulla, Jammu und Kaschmir, Indien"
    },
    {
        "title": "Movida Bar-Granatangriff",
        "year": 2016,
        "desc": "Angriff in Puchong, Selangor, Malaysia"
    },
    {
        "title": "Angriff in Hurghada",
        "year": 2017,
        "desc": "Details zum Terroranschlag in Hurghada"
    },
    {
        "title": "Angriff auf Umm al-Hiran",
        "year": 2017,
        "desc": "Tötung eines israelischen Arabers durch israelische Polizei"
    },
    {
        "title": "Bombenanschlag auf Lashio",
        "year": 2018,
        "desc": "Bombenexplosion in der Nähe zweier Banken in Lashio, Myanmar"
    },
    {
        "title": "Bildung der schwedischen Regierung",
        "year": 2018,
        "desc": "Parlamentarische Regierungsbildung in Schweden"
    },
    {
        "title": "Superspreader-Ereignis der Tablighi Jamaat in Malaysia",
        "year": 2020,
        "desc": "Großer COVID-19-Ausbruch bei einer Versammlung in Kuala Lumpur."
    },
    {
        "title": "VCDL-Lobbytag",
        "year": 2020,
        "desc": "Kundgebung für Waffenrechte in Richmond, Virginia"
    },
    {
        "title": "Anschläge in Afghanistan",
        "year": 2021,
        "desc": "Liste der Angriffe in Afghanistan"
    },
    {
        "title": "Angst vor der Antilla-Bombe",
        "year": 2021,
        "desc": "Bombenangst in Mumbai"
    },
    {
        "title": "Konservative politische Aktionskonferenz",
        "year": 2021,
        "desc": "Politisches Treffen in den USA"
    },
    {
        "title": "Cyberangriffe auf Sri Lanka",
        "year": 2021,
        "desc": "Angriffe auf nationale Websites Sri Lankas"
    },
    {
        "title": "Zusammenstöße in Darfur",
        "year": 2021,
        "desc": "tödlicher Unruhe"
    },
    {
        "title": "Stadioneinsturz in Kolumbien",
        "year": 2022,
        "desc": "Struktureinsturz in El Espinal, Tolima, Kolumbien"
    },
    {
        "title": "Angriff auf den Kontrollpunkt El Qantara",
        "year": 2022,
        "desc": "Terroranschlag in Ägypten"
    },
    {
        "title": "Angriff auf Kirjat Arba",
        "year": 2022,
        "desc": "Schießerei im Westjordanland"
    },
    {
        "title": "Bombenanschlag auf Beledweyne",
        "year": 2023,
        "desc": "Massenmord in Somalia"
    },
    {
        "title": "Spaltung der Nationalistischen Kongresspartei",
        "year": 2023,
        "desc": "Indischer politischer Vorfall"
    },
    {
        "title": "Einsturz eines Parkhauses in New York City",
        "year": 2023,
        "desc": "Einsturz eines Parkhauses in New York City"
    },
    {
        "title": "Angriffe im Bundesstaat Yobe",
        "year": 2023,
        "desc": "Anschläge von Boko Haram in Nigeria"
    },
    {
        "title": "Angriff auf die Polizeistation Baniachong",
        "year": 2024,
        "desc": "Massaker in Habiganj."
    },
    {
        "title": "Anklage und Verhaftung von Julian Assange",
        "year": 2019,
        "desc": "Reihe von Ereignissen im Zusammenhang mit Gerichtsverfahren des Vereinigten Königreichs, Schwedens und der Vereinigten Staaten von Amerika gegen Julian Assange"
    },
    {
        "title": "Kindermorde in Cairns",
        "year": 2014,
        "desc": "Vorfall in Australien, bei dem acht Kinder aufgrund von Stichwunden tot auf einem Grundstück aufgefunden wurden."
    },
    {
        "title": "Murwillumbah-Sumpfbier",
        "year": 2001,
        "desc": "ein Ereignis in Murwillumbah, New South Wales, bei dem 40 Flaschen Bier in den Tweed River fielen"
    },
    {
        "title": "Die Platin-Jubiläumsfeuer der Königin",
        "year": 2022,
        "desc": "Das Anzünden von Leuchtfeuern im gesamten Commonwealth zur Feier des Platin-Jubiläums von Königin Elizabeth II"
    },
    {
        "title": "Besuch von Ma Ying-jeou auf dem chinesischen Festland",
        "year": 2024,
        "desc": "Der ehemalige Präsident der Republik China, Ma Ying-jeou, besuchte das chinesische Festland"
    },
    {
        "title": "Das letzte Experiment",
        "year": 2017,
        "desc": "Antarktisexpedition, um die Gültigkeit des modernen Glaubens an eine flache Erde zu testen"
    },
    {
        "title": "Baku-Sicherheitsforum",
        "year": 2025,
        "desc": "Internationale Plattform für globale und regionale Sicherheitsfragen"
    },
    {
        "title": "Iranische Operationen in Australien",
        "year": 2024,
        "desc": "Iranische Geheimoperationen in Australien"
    },
    {
        "title": "Anschlag in Melbourne",
        "year": 2017,
        "desc": "Terror-Geiselnahme in Melbourne, Australien"
    },
    {
        "title": "Adpokalypse",
        "year": 2017,
        "desc": "Ereignis, das sich auf die Monetarisierung des YouTube-Kanals auswirkt"
    },
    {
        "title": "Afrika und darüber hinaus...",
        "year": 2025,
        "desc": "Telefonkonferenz zwischen Simferopol und Murmansk"
    },
    {
        "title": "Chinesische Elefantenexpedition",
        "year": 2020,
        "desc": "Migration und Rückkehr asiatischer Elefanten in China"
    },
    {
        "title": "Anschlag in Burkina Faso",
        "year": 2021,
        "desc": "Teil des dschihadistischen Aufstands in Burkina Faso"
    },
    {
        "title": "Operation Bawaria",
        "year": 2005,
        "desc": "Thema eines südindischen Films namens „Theeran“"
    },
    {
        "title": "Rücktritt von Justin Trudeau",
        "year": 2025,
        "desc": "Rücktritt des kanadischen Premierministers"
    },
    {
        "title": "Leggheit-Angriff",
        "year": 2005,
        "desc": "Islamistischer Angriff auf eine mauretanische Kaserne"
    },
    {
        "title": "Messerstecherei in einer Mittelschule des Landkreises Mizhi",
        "year": 2018,
        "desc": "Massenmord in der chinesischen Provinz Shaanxi"
    },
    {
        "title": "Einweihung von Prabowo Subianto",
        "year": 2024,
        "desc": "Amtseinführung des Präsidenten in Indonesien"
    },
    {
        "title": "Angriff auf US-Konsulat in Herat",
        "year": 2013,
        "desc": "Angriff der Taliban in Afghanistan"
    },
    {
        "title": "Explosion eines Straßentankers in Mbuba",
        "year": 2018,
        "desc": "Explosion eines Tankwagens in Kongo Central, Demokratische Republik Kongo"
    },
    {
        "title": "Der polnische Präsident unterzeichnet das umstrittene Holocaust-Gesetz",
        "year": 2018,
        "desc": "Bei einer Veranstaltung im Februar 2018 in Polen wurde ein umstrittenes Verleumdungsgesetz erlassen, das jede Erwähnung einer polnischen Mitschuld am Holocaust unter Strafe stellt"
    },
    {
        "title": "2018 Wahl des Präsidenten der National Taiwan University",
        "year": 2018,
        "desc": "Kontroverse über die Einmischung politischer Kräfte in die akademische Unabhängigkeit"
    },
    {
        "title": "2018 Angriff auf die Hohe Nationale Wahlkommission in Tripolis, Libyen",
        "year": 2018,
        "desc": "Historisches Ereignis aus dem Jahr 2018."
    }
];
